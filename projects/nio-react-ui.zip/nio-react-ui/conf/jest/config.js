const path = require('path');

module.exports = {
    rootDir: path.resolve(__dirname, '../../'),

    // 是否收集测试时的覆盖率信息
    collectCoverage: true,

    // 主要用于与webpack的resolve.alias匹配，注意正则写法
    moduleNameMapper: {
        '^~utils(.*)$': '<rootDir>/src/utils$1',
        '^~storybook(.*)$': '<rootDir>/storybook$1',
        '^~lib(.*)$': '<rootDir>/src/lib$1',
        '\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$': '<rootDir>/jest/__mocks__/fileMock.js',
        '\\.(css|scss)$': 'identity-obj-proxy',
    },

    // 匹配的测试文件
    testMatch: [
        '<rootDir>/src/component/**/?(*.)(spec|test).{js,jsx}',
    ],
    transform: {
        '^.+\\.(js|jsx)$': '<rootDir>/node_modules/babel-jest',
    },

    // 转换时需要忽略的文件
    transformIgnorePatterns: [
        '<rootDir>/node_modules/',
    ],
    setupFiles: ['<rootDir>/conf/jest/setup.js', '<rootDir>/node_modules/jest-canvas-mock'],
    snapshotSerializers: ['enzyme-to-json/serializer'],
    testURL: 'http://localhost',
};
