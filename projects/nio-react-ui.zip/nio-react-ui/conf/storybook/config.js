/* eslint-disable */
import {
    configure,
    addDecorator,
} from '@storybook/react';
import '@storybook/addon-console'; // show console in 'ACTION LOGGER' panel automatically
import {
    withInfo,
} from '@storybook/addon-info';
import * as knobs from '@storybook/addon-knobs';
import {
    withConsole,
} from '@storybook/addon-console';

import {
    withOptions,
} from '@storybook/addon-options';

const {
    withKnobs,
} = knobs;

addDecorator(withOptions({
    name: 'NIO-REACT-UI',
    url: 'https://git.nevint.com/uad/nio-react-ui',
    addonPanelInRight: true,
}));

// info-addon, for document
addDecorator(withInfo({
    inline: false,
    header: false,
}));

// interactive props
addDecorator(withKnobs);

// show console in ACTION-LOGGER panel
addDecorator((storyFn, context) => withConsole()(storyFn)(context));

// webpack require context
const allStories = require.context('../../src/component', true, /story\.js(x)?$/);

function loadStories() {
    // require stories registrant here
    allStories.keys().forEach(fileName => allStories(fileName));
}

configure(loadStories, module);
