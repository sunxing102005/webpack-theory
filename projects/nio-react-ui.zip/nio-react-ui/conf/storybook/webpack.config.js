const path = require('path');

const APP_DIR = path.resolve(__dirname, '../../src');
module.exports = {
    module: {
        rules: [{
            test: /\.scss$/,
            loaders: ['style-loader', 'css-loader', 'sass-loader'],
            include: path.resolve(APP_DIR),
        }, {
            test: /\.(woff(2)?|eot|ttf|svg|png|jpg|gif)$/,
            use: ['url-loader?limit=100000'],
        }],
    },
    resolve: {
        alias: {
            '~utils': path.resolve(APP_DIR, './utils'),
            '~lib': path.resolve(APP_DIR, './lib'),
            '~storybook': path.resolve(APP_DIR, '../storybook'),
            '@scss': path.resolve(APP_DIR, './lib/style'),
        },
        extensions: ['*', '.js', '.jsx'],
    },
};
