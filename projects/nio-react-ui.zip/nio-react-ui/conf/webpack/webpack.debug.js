const path = require('path');
const merge = require('webpack-merge');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const baseConfig = require('./webpack.base');

const HOST = 'localhost';
const PORT = 8052;
console.log('process', process.env.npm_config_argv);
module.exports = merge(baseConfig, {
    mode: 'development',
    entry: {
        index: './debug/app.jsx',
    },
    devtool: 'source-map',
    output: {
        path: path.resolve(__dirname, '../../dist'),
        publicPath: '/',
        filename: '[name].js',
        library: '[name]_[hash]',
        chunkFilename: '[name].bundle.js',
    },
    devServer: {
        host: HOST,
        port: PORT,
        // open: true,
        openPage: 'index.html',
    },
    plugins: [
        new webpack.DefinePlugin({
            'process.env': {
                COM_NAME: JSON.stringify(process.env.npm_config_argv),
            },
        }),
        new webpack.HotModuleReplacementPlugin(),
        new HtmlWebpackPlugin({
            filename: 'index.html',
            template: 'debug/index.html',
        }),
    ],
});
