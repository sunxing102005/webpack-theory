const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const path = require('path');

const APP_DIR = path.resolve(__dirname, '../../src');

module.exports = {
    module: {
        rules: [{
            test: /\.(js|jsx)$/,
            exclude: /node_modules/,
            use: ['babel-loader'],
        }, {
            test: /\.(scss|css)$/,
            use: ['style-loader', 'css-loader', 'sass-loader'],
        }, {
            test: /\.(woff(2)?|eot|ttf|svg|png|jpg|gif)$/,
            use: ['url-loader?limit=100000'],
        }],
    },
    resolve: {
        alias: {
            '~lib': path.resolve(APP_DIR, './lib'),
            '~utils': path.resolve(APP_DIR, './utils'),
            '@scss': path.resolve(APP_DIR, './lib/style'),
        },
        extensions: ['*', '.js', '.jsx'],
    },
    plugins: [
        // new BundleAnalyzerPlugin({
        //     analyzerPort: 8800,
        // }),
    ],
};
