## Test
test frame uses **jest** & **enzyme**

every component should have its own test cases.

[doc for jest](https://jestjs.io/docs/zh-Hans/getting-started)

[doc for enzyme](https://airbnb.io/enzyme/)

### run test
```
npm run test

```
coverage info can be found at path_to_project/coverage/lcov-report.

(coverage dir is marked in .gitignore so it won't be uploaded onto gitlab.Make sure you have run the test first.)

### build test case
please build test case for component by following:

- add ```(*.)test.jsx```  into directory which component belongs to
- example:

```javascript
/* eslint-disable import/no-extraneous-dependencies, no-undef */
/* eslint-env jest, node, enzyme */
import React from 'react';
import Comp from './index';

// test snapshot
describe('Comp Snapshot', () => {
    it('render correctly', () => {
	    // render is method from enzyme
	    // used to generate render result
	    // with the jest config in /conf/jest/config.js
	    // it will be parsed into JSON format automatically
        const wrapper = render(
            <Comp />,
        );
        expect(wrapper).toMatchSnapshot();
    });

	// more than 1 test case in SnapShot group is available
    it('render correctly when someProps=value', () => {
        const wrapper = render(
            <Comp someProps="value" />,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

// test defalt props
// why:
// nio-react-ui is a foundation component lib
// so keep default props same as far as possible is important
// this test reduce potential bugs or modify default porps unintentionally
describe('Toast Default Props', () => {
    it('default props', () => {
        const wrapper = mount(
            <Toast />,
        );
        expect(wrapper.prop('defaultPropName')).toBe('defaultPropValue');
    });
});
```

### notice
- every component **must** has its own test.
- **at least 1** snapshot test is **required**.
- test for **default props** is **required**.
- 100% coverage is **not** necessary, just focus on abilities that the component real provide. Make sure the test will discover when break changes are involved.
