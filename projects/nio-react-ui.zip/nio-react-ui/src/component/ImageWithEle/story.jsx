import React from 'react';
import registerStory from '~storybook/index';
import ImageWithEle from './index';

const style = {
    wrapperStyle: {
        width: 200,
    },
};
// register story
const { stories, knobs } = registerStory('ImageWithEle', style);

const { text } = knobs;
function onLoad() {
    console.log('call onLoad method');
}
function onError() {
    console.log('call onError method');
}
function onClick() {
    console.log('call onClick method');
}
const element = <p>邀约试驾 抽NIO Day门票</p>;
stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为图片提供属性直接设置图片宽高,设置外框样式
          - 该组件提供element属性设置图片外的元素节点
        `,
        },
    })
    .add('base usage', () => {
        const src = text(
            'src',
            'https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png',
        );
        const height = text('imgHeight', '200px');
        const width = text('imgWidth', '200px');
        return (
            <ImageWithEle
                src={src}
                imgHeight={height}
                imgWidth={width}
                onImageLoad={onLoad}
                onClick={onClick}
                onImageError={onError}
            >
                {element}
            </ImageWithEle>
        );
    })
    .add('custom style', () => {
        const src = text(
            'src',
            'https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png',
        );
        const height = text('imgHeight', '200px');
        const width = text('imgWidth', '200px');
        return (
            <ImageWithEle
                src={src}
                imgHeight={height}
                imgWidth={width}
                onImageLoad={onLoad}
                onImageError={onError}
                onClick={onClick}
            >
                <p>我是title我是title我是title</p>
                <p style={{ fontSize: 12, color: 'grey' }}>我是info我是info我是info我是info</p>
            </ImageWithEle>
        );
    });
