import React from 'react';
import ImageWithEle from './index';

describe('ImageWithEle', () => {
    it('should render correctly', () => {
        const element = <p>title</p>;
        const wrapper = render(
            <ImageWithEle
                imgHeight="150px"
                imgWidth="150px"
                className="img-test"
                src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png"
            >
                {element}

            </ImageWithEle>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

describe('ImageWithEle Event Test', () => {
    const onClick = jest.fn();
    const onLoad = jest.fn();
    const wrapper = mount(
        <ImageWithEle
            src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png"
            onClick={onClick}
            onImageLoad={onLoad}
        />,
    );
    it('should call onLoad method', () => {
        wrapper
            .find('img')
            .props()
            .onLoad();
        expect(onLoad).toHaveBeenCalled();
    });
    it('should call onLoad method', () => {
        wrapper
            .find('.nio-img-with-title')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
    it('should call onError method', () => {
        const onError = jest.fn();

        const wrapperError = mount(
            <ImageWithEle
                src="https://www.nio.com/themes/nioweb/images/XXX.png"
                onImageError={onError}
            />,
        );
        wrapperError
            .find('img')
            .props()
            .onError();
        expect(onError).toHaveBeenCalled();
    });
});
describe('ImageWithEle  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<ImageWithEle />);
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('imgHeight')).toBe('');
        expect(wrapper.prop('imgWidth')).toBe('');
        expect(wrapper.prop('src')).toBe('');
        expect(wrapper.prop('onImageLoad')).toBeNull();
        expect(wrapper.prop('onClick')).toBeNull();
        expect(wrapper.prop('onImageError')).toBeNull();
    });
});
