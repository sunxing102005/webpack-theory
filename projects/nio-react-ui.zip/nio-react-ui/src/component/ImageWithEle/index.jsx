import React from 'react';
import PropTypes from 'prop-types';
import Image from '../Image';
import { delEmptyKey } from '~utils/utils';
import { PureComponent } from '~lib';
import './index.scss';

/**
 * 带标题,悬浮文字等页面元素的图片组件
 */
class ImageWithEle extends PureComponent {
  clickItem = (e) => {
      const { onClick } = this.props;
      onClick && onClick(e);
  };

  render() {
      const {
          src,
          imgHeight,
          imgWidth,
          children,
          onImageLoad,
          onImageError,
      } = this.props;
      const imgStyle = delEmptyKey({ height: imgHeight, width: imgWidth }); // 图片style
      const containerClassName = this.className('nio-img-with-title');
      return (
          <div
              className={containerClassName}
              onClick={this.clickItem}
          >
              <Image
                  imageClassName="nio-invisible nio-internal"
                  src={src}
                  style={imgStyle}
                  onLoad={onImageLoad}
                  onError={onImageError}
              />
              {children}
          </div>
      );
  }
}
ImageWithEle.propTypes = {
    /** 图片src */
    src: PropTypes.string,
    /** 外层div class */
    // eslint-disable-next-line react/no-unused-prop-types
    className: PropTypes.string,
    /** 内部图片高度 */
    imgHeight: PropTypes.string,
    /** 内部图片宽度 */
    imgWidth: PropTypes.string,
    /** 点击事件处理方法 */
    onClick: PropTypes.func,
    /** 图片加载成功后处理方法 */
    onImageLoad: PropTypes.func,
    /** 图片加载失败后处理方法 */
    onImageError: PropTypes.func,
    /** 图片之外元素 */
    children: PropTypes.node,
};
ImageWithEle.defaultProps = {
    src: '',
    className: '',
    imgHeight: '',
    imgWidth: '',
    onClick: null,
    onImageLoad: null,
    onImageError: null,
    children: null,
};
export default ImageWithEle;
