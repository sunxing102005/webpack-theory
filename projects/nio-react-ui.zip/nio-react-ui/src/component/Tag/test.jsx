import React from 'react';
import {
    render,
    shallow,
} from 'enzyme';
import Tag from './index';
import Icon from '../Icon';

describe('Tag', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <div>
                <Tag iconName="icon-text" content="tag 1" />
                <Tag iconName="icon-text"><span>button</span></Tag>
                <Tag disabled content="tag 1" />
                <Tag selected content="tag 1" />
                <Tag selected disabled content="tag 1" />
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });

    it('render children', () => {
        const wrapper = shallow((
            <Tag
                iconName="icon-collect"
                content="tag 1"
            >
                <span className="children-span">555</span>
            </Tag>
        ));
        expect(wrapper.exists(Icon)).toEqual(true);
        expect(wrapper.exists('span.children-span')).toEqual(true);
    });

    it('simulates click events', () => {
        const onClick = jest.fn();
        const wrapper = shallow(
            <Tag
                onClick={onClick}
                value="value"
                content="tag"
            />,
        );
        wrapper.find('.nio-tag').simulate('click');
        expect(onClick).toHaveBeenCalledWith('value', false);

        wrapper.setProps({ disabled: true });
        wrapper.find('.nio-tag').simulate('click');
        expect(onClick).toHaveBeenLastCalledWith('value', true);
    });
});
