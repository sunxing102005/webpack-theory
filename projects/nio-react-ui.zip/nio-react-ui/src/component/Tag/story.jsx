import React from 'react';
import registerStory from '~storybook/index';
import Tag from './index';

const style = {
    wrapperStyle: {
        height: 100,
    },
};
// register story
const {
    stories,
    knobs,
} = registerStory('Tag', style);

const {
    text,
    boolean,
    object,
    select,
} = knobs;

const clickHandler = () => {
    console.log('Tag 被点击啦啦啦啦～');
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为Tag UI组件
          - ** 注意 **在props : ** disabled **和props : ** selected **同时为true时，显示为selected效果
        `,
        },
    })
    .add('base usage', () => {
        const disabled = boolean('disabled', false);
        const selected = boolean('selected', false);
        const content = text('content', '其他');
        const iconName = text('iconName', '');
        const iconPositionOptions = {
            before: 'icon-before',
            behind: 'icon-behind',
        };
        const iconPosition = select('iconPosition', iconPositionOptions, 'icon-behind');
        const tagStyle = object('style', {});
        return (
            <Tag
                disabled={disabled}
                selected={selected}
                iconName={iconName}
                iconPosition={iconPosition}
                style={tagStyle}
                onClick={clickHandler}
                content={content}
            />
        );
    });
