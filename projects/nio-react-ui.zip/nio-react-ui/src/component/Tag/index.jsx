import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import Icon from '../Icon';

import './index.scss';

class Tag extends PureComponent {
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick() {
        const { onClick, value, disabled } = this.props;
        onClick(value, disabled);
    }

    render() {
        const {
            disabled,
            selected,
            children,
            content,
            iconName,
            iconPosition,
        } = this.props;

        const classString = this.className(
            'nio-tag',
            {
                'nio-tag--selected': selected,
                'nio-tag--disabled': disabled,
                [`nio-tag--${iconPosition}`]: !!iconPosition && iconName,
            },
        );

        return (
            <div
                className={classString}
                style={this.style()}
                onClick={this.handleClick}
            >
                <React.Fragment>
                    {iconName ? (
                        <Icon
                            className="nio-tag__icon"
                            name={iconName}
                        />
                    ) : null}
                    {content}
                </React.Fragment>
                {children && (
                    <div className="nio-tag__label">
                        {children}
                    </div>
                )}
            </div>
        );
    }
}

Tag.defaultProps = {
    selected: false,
    onClick: null,
    disabled: false,
    children: null,
    value: '',
    content: '',
    /** Tag Icon名称，参考Icon组件 */
    iconName: '',
    /** Tag Icon位置 */
    iconPosition: 'icon-before',
};

Tag.propTypes = {
    /** tag value, will be passed by 2nd params in onClick */
    value: PropTypes
        .oneOfType([
            PropTypes.string,
            PropTypes.number,
        ]),
    /** is tag checked */
    selected: PropTypes.bool,
    /** tag click handler */
    onClick: PropTypes.func,
    /** is tag disabled */
    disabled: PropTypes.bool,
    /** child for tag */
    children: PropTypes.node,
    /** content for tag */
    content: PropTypes.string,
    /** Tag Icon名称，参考Icon组件 */
    iconName: PropTypes.string,
    /** Tag Icon位置，可选icon-before、icon-behind、icon-top、icon-bottom */
    iconPosition: PropTypes.oneOf([
        'icon-before',
        'icon-behind',
    ]),
};

export default Tag;
