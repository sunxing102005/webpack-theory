import React from 'react';
import registerStory from '~storybook';
import DateTimePicker from './index';
import { isSameDay } from '~utils/date';

// register story
const { stories, knobs, state } = registerStory('DateTimePicker', {
    wrapperStyle: {
        width: '600px',
        height: 500,
        margin: '100px auto',
    },
});

const {
    number,
    select,
    boolean,
} = knobs;

const {
    State,
    Store,
} = state;

const dateTimePickerStore = new Store({
    selectedDate: new Date(),
});

const onSelected = (data) => {
    dateTimePickerStore.set({
        selectedDate: data,
    });
    console.log(`选中${data}`);
};

const judgeDisable = (dateObj) => {
    const now = new Date();
    const beforeNow = !isSameDay(dateObj, now) && dateObj.getTime() < now.getTime();
    if (beforeNow) {
        // 日期在当前时刻之前
        return ' disable';
    }
    return false;
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 日期选择组件
          - 该组件目前支持到天级别的日期选择
        `,
        },
    })
    .add('base usage', () => {
        const showTitleBarOptions = {
            不显示: 'none',
            全部显示: 'all',
            显示前后按钮: 'preAndNext',
            显示标题: 'title',
        };
        const showTitleBar = select('showTitleBar', showTitleBarOptions, 'all');

        const titleBarTextAlignOptions = {
            center: 'center',
            left: 'left',
            right: 'right',
        };
        const titleBarTextAlign = select('titleBarTextAlign', titleBarTextAlignOptions, 'center');
        const disableTitleBar = boolean('disableTitleBar', false);

        const currentViewOptions = {
            month: 1,
            day: 2,
        };
        const currentView = select('currentView', currentViewOptions, 2);
        const currentYear = number('currentYear', 2020);
        const currentMonth = number('currentMonth', 9);
        const currentDate = number('currentDate', 23);
        return (
            <State store={dateTimePickerStore}>
                <DateTimePicker
                    className="order-calendar"
                    showTitleBar={showTitleBar}
                    titleBarTextAlign={titleBarTextAlign}
                    judgeDisable={judgeDisable}
                    disableTitleBar={disableTitleBar}
                    currentView={currentView}
                    selectedDate={dateTimePickerStore.get('selectedDate')}
                    currentYear={currentYear}
                    currentMonth={currentMonth}
                    currentDate={currentDate}
                    onSelected={dateTime => onSelected(dateTime)}
                />
            </State>
        );
    });
