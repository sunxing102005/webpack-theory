import React from 'react';
import PropTypes from 'prop-types';

import './index.scss';

export default function Month(props) {
    const { text, timestamp, selectDate } = props;
    return (
        <div
            className="month"
            timestamp={timestamp}
            onClick={() => selectDate(new Date(timestamp))}
        >
            {text}
        </div>
    );
}

Month.propTypes = {
    text: PropTypes.string,
    timestamp: PropTypes.oneOfType([
        PropTypes.instanceOf(Date),
        PropTypes.number,
    ]),
    selectDate: PropTypes.func,
};

Month.defaultProps = {
    text: '',
    timestamp: -1,
    selectDate: () => {},
};
