import React from 'react';
import PropTypes from 'prop-types';

import './index.scss';

export default function DateTimePickerTitle(props) {
    const getTitle = () => {
        const {
            currentYear: year,
            currentMonth: month,
            currentView,
        } = props;
        let title = '';
        if (currentView === 1) {
            title = `${year}年`;
        } else if (currentView === 2) {
            title = `${year}年${month}月`;
        }
        return title;
    };

    const goToPreView = () => {
        const { currentView, changeView, disable } = props;
        if (disable) {
            return;
        }
        if (currentView > 1) {
            changeView(currentView - 1);
        }
    };

    const goTo = (type) => {
        const {
            changeState, currentView, currentYear, currentMonth, disable,
        } = props;
        if (disable) {
            return;
        }
        if (currentView === 1) { // 切换年份
            const nextYear = type === 'pre' ? currentYear - 1 : currentYear + 1;
            changeState({ currentYear: nextYear });
        } else if (currentView === 2) { // 切换月份
            let nextMonth;
            let nextYear;
            if (type === 'pre') {
                nextMonth = currentMonth === 1 ? 12 : currentMonth - 1;
                nextYear = currentMonth === 1 ? currentYear - 1 : currentYear;
            } else {
                nextMonth = currentMonth === 12 ? 1 : currentMonth + 1;
                nextYear = currentMonth === 12 ? currentYear + 1 : currentYear;
            }
            changeState({ currentYear: nextYear, currentMonth: nextMonth });
        }
    };

    const { show = 'all', titleBarTextAlign } = props;
    return show !== 'none' ? (
        <div className="date-time-picker-title">
            {(show === 'all' || show === 'preAndNext')
                && (
                    <div onClick={() => goTo('pre')}>
                        {'<'}
                    </div>
                )
            }
            {(show === 'all' || show === 'title')
                && (
                    <div
                        className={`title ${titleBarTextAlign}`}
                        onClick={() => goToPreView()}
                    >
                        {getTitle()}
                    </div>
                )
            }
            {(show === 'all' || show === 'preAndNext')
                && (
                    <div onClick={() => goTo('next')}>
                        {'>'}
                    </div>
                )
            }
        </div>
    ) : null;
}

DateTimePickerTitle.propTypes = {
    /** 组件头部显示控制 */
    show: PropTypes.oneOf([
        /** 全部不显示 */
        'none',
        /** 全部显示 */
        'all',
        /** 显示前进和后退按钮 */
        'preAndNext',
        /** 显示标题 */
        'title',
    ]),
    /** 显示标题位置 */
    titleBarTextAlign: PropTypes.oneOf([
        /** 居中 */
        'center',
        /** 左对齐 */
        'left',
        /** 右对齐 */
        'right',
    ]),
    /** 标题按钮是否禁用 */
    disable: PropTypes.bool,
    /** 组件当前显示级别 */
    currentView: PropTypes.oneOf([
        /** 显示年 */
        0,
        /** 显示月 */
        1,
        /** 显示日 */
        2,
        /** 显示小时 */
        3,
    ]),
    /** 当前展示年, 如不设置, 以选中时间为准 */
    currentYear: PropTypes.number,
    /** 当前展示月 */
    currentMonth: PropTypes.number,
    /** 当前展示日 */
    // currentDate: PropTypes.number,
    changeView: PropTypes.func,
    changeState: PropTypes.func,
};

DateTimePickerTitle.defaultProps = {
    show: 'all',
    titleBarTextAlign: 'center',
    disable: false,
    currentView: 2,
    currentYear: null,
    currentMonth: null,
    // currentDate: null,
    changeView: () => {
    },
    changeState: () => {},
};
