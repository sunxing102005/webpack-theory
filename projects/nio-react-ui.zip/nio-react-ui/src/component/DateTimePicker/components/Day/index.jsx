import React from 'react';
import PropTypes from 'prop-types';

import { isSameDay } from '~utils/date';

import { Component } from '~lib';

import './index.scss';

export default class Day extends Component {
    // 年份和月份相同时，只渲染之前选中和当前选中的，否则渲染全部
    shouldComponentUpdate(nextProps) {
        const { currentYear: nextYear, currentMonth: nextMonth, selectedDate: nextSelectedDate } = nextProps;
        const { currentYear, currentMonth, selectedDate } = this.props;
        return (currentYear !== nextYear || currentMonth !== nextMonth)
            || (isSameDay(nextProps.timestamp, nextSelectedDate)
            || isSameDay(this.props.timestamp, selectedDate));
    }

    render() {
        const {
            text = '', timestamp = -1, selectDate, judgeDisable, selectedDate,
        } = this.props;
        const today = isSameDay(new Date(), timestamp);
        const disable = judgeDisable && typeof judgeDisable === 'function' ? judgeDisable(new Date(timestamp)) : false;
        const active = !disable && isSameDay(selectedDate, timestamp);
        const showText = today ? '今天' : text;
        const classString = this.className('day', {
            today,
            disable,
            [disable]: typeof disable === 'string',
            active,
        });
        return (
            <li
                className={classString}
                value={timestamp}
                onClick={() => {
                    !disable && selectDate(new Date(timestamp));
                }}
            >
                <span className={`${text ? '' : 'empty'}`}>{showText}</span>
            </li>
        );
    }
}

Day.propTypes = {
    judgeDisable: PropTypes.func,
    selectedDate: PropTypes.instanceOf(Date),
    text: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number,
    ]),
    timestamp: PropTypes.oneOfType([
        PropTypes.instanceOf(Date),
        PropTypes.number,
    ]),
    selectDate: PropTypes.func,
    /** 当前展示年, 如不设置, 以选中时间为准 */
    currentYear: PropTypes.number,
    /** 当前展示月 */
    currentMonth: PropTypes.number,
};

Day.defaultProps = {
    judgeDisable: () => false,
    selectedDate: new Date(),
    text: '',
    timestamp: -1,
    selectDate: () => {},
    currentYear: null,
    currentMonth: null,
};
