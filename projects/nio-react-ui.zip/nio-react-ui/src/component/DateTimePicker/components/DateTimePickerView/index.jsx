import React from 'react';
import PropTypes from 'prop-types';

// components
import Day from '../Day';
import Month from '../Month';

// utils
import { getDateNumberOfMonth, getDateDetail } from '~utils/date';

// style
import './index.scss';

export default function DateTimePickerView(props) {
    const getDays = () => {
        const { currentYear, currentMonth } = props;
        const dayOfFirstDate = getDateDetail(new Date(currentYear, currentMonth - 1, 1)).day;
        const emptyDateNumber = dayOfFirstDate === 0 ? 6 : dayOfFirstDate - 1;
        const emptyDays = [];
        for (let i = 0; i < emptyDateNumber; i++) {
            emptyDays.push({ text: '', timestamp: -1 });
        }

        const notEmptyDays = [];
        const dateNumberOfMonth = getDateNumberOfMonth(currentYear, currentMonth);
        let timestamp = -1;
        for (let i = 1; i <= dateNumberOfMonth; i++) {
            timestamp = new Date(currentYear, currentMonth - 1, i).getTime();
            notEmptyDays.push({ text: i, timestamp });
        }

        return emptyDays.concat(notEmptyDays);
    };

    const getMonths = () => {
        const { currentYear } = props;
        return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(i => (
            {
                text: `${i}月`,
                timestamp: new Date(currentYear, i - 1, 1),
            }
        ));
    };

    const getView = (currentView) => {
        const { judgeDisable, selectDate } = props;
        let View;
        if (currentView === 1) { // 显示 "月"
            const months = getMonths();
            View = (
                <div className="month-wrapper">
                    {months.map((month, index) => (
                        <Month
                            key={index}
                            text={month.text}
                            timestamp={month.timestamp}
                            selectDate={selectDate}
                            judgeDisable={judgeDisable}
                            {...props}
                        />
                    ))}
                </div>
            );
        }
        if (currentView === 2) { // 显示 "日"
            const days = getDays();
            View = (
                <div className="date-time-picker-content">
                    <ul className="week-wrapper">
                        <li>一</li>
                        <li>二</li>
                        <li>三</li>
                        <li>四</li>
                        <li>五</li>
                        <li>六</li>
                        <li>日</li>
                    </ul>
                    <ul className="day-wrapper">
                        {days.map((day, index) => (
                            <Day
                                key={index}
                                text={day.text}
                                timestamp={day.timestamp}
                                selectDate={selectDate}
                                judgeDisable={judgeDisable}
                                {...props}
                            />
                        ))}
                    </ul>
                </div>
            );
        }

        return View;
    };

    const { currentView } = props;
    const View = getView(currentView);
    return (
        <div className="date-time-picker-content">
            {View}
        </div>
    );
}

DateTimePickerView.propTypes = {
    /** 组件当前显示级别 */
    currentView: PropTypes.oneOf([
        /** 显示年 */
        0,
        /** 显示月 */
        1,
        /** 显示日 */
        2,
        /** 显示小时 */
        3,
    ]),
    /** 当前展示年, 如不设置, 以选中时间为准 */
    currentYear: PropTypes.number,
    /** 当前展示月 */
    currentMonth: PropTypes.number,
    judgeDisable: PropTypes.func,
    /** 当前展示日 */
    currentDate: PropTypes.number,
    /** 当前选中的时间 */
    selectDate: PropTypes.func,
};

DateTimePickerView.defaultProps = {
    currentView: 2,
    currentYear: null,
    currentMonth: null,
    currentDate: null,
    judgeDisable: () => false,
    selectDate: () => {},
};
