import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

import DateTimePickerTitle from './components/DateTimePickerTitle';
import DateTimePickerView from './components/DateTimePickerView';

import { getDateDetail } from '~utils/date';

import './index.scss';


/*
 * DateTimePicker
 * 日历组件，按年、月、日级别显示，
 * 并能通过对外接口返回选择日期
 * 级别对应： year: 0 , month: 1, date: 2, hour: 3 ...
 *
 * @props{Number}currentView, 当前显示的级别
 * @props{Number}maxView, 最大显示级别 0 => year, 1 => month ...
 * @props{Number}minView, 最小显示级别
 * @props{Date}selectedDate, 选中的日期
 * @props{Function}onSelected, 选中日期时的回调,参数为选中的Date对象
 */
export default class DateTimePicker extends PureComponent {
    constructor(props) {
        super(props);
        const {
            selectedDate,
            currentView,
            currentYear,
            currentMonth,
            currentDate,
        } = props;
        const { year, month, date } = getDateDetail(selectedDate);
        this.state = {
            currentView,
            currentYear: currentYear || year,
            currentMonth: currentMonth || month,
            currentDate: currentDate || date,
            selectedDate,
        };
        this.changeView = this.changeView.bind(this);
        this.changeState = this.changeState.bind(this);
        this.selectDate = this.selectDate.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ selectedDate: nextProps.selectedDate });
    }

    // show 0 => year, 1 => month, 2=> date
    changeView(nextView) {
        this.setState({ currentView: nextView });
    }

    changeState(newState) {
        this.setState(newState);
    }

    selectDate(dateObj) {
        const { onSelected, maxView } = this.props;
        const { currentView } = this.state;
        const { year, month, date } = getDateDetail(dateObj);
        const newState = {};
        if (currentView >= 0) {
            newState.currentYear = year;
        }
        if (currentView >= 1) {
            newState.currentMonth = month;
        }
        if (currentView >= 2) {
            newState.currentDate = date;
        }
        this.setState(newState);

        if (currentView !== maxView) {
            this.changeView(currentView + 1);
        } else {
            this.setState({
                selectedDate: dateObj,
            });
            onSelected(dateObj);
        }
    }

    render() {
        const {
            showTitleBar,
            judgeDisable,
            titleBarTextAlign,
            disableTitleBar,
        } = this.props;
        return (
            <div className={this.className('nio-date-time-picker')}>
                <DateTimePickerTitle
                    {...this.state}
                    changeView={this.changeView}
                    changeState={this.changeState}
                    show={showTitleBar}
                    disable={disableTitleBar}
                    titleBarTextAlign={titleBarTextAlign}
                />
                <DateTimePickerView
                    {...this.state}
                    judgeDisable={judgeDisable}
                    selectDate={this.selectDate}
                />
            </div>
        );
    }
}

DateTimePicker.propTypes = {
    /** 组件头部显示控制 */
    showTitleBar: PropTypes.oneOf([
        /** 全部不显示 */
        'none',
        /** 全部显示 */
        'all',
        /** 显示前进和后退按钮 */
        'preAndNext',
        /** 显示标题 */
        'title',
    ]),
    /** 判断日期是否禁用的方法 */
    judgeDisable: PropTypes.func,
    /** 显示标题位置 */
    titleBarTextAlign: PropTypes.oneOf([
        /** 居中 */
        'center',
        /** 左对齐 */
        'left',
        /** 右对齐 */
        'right',
    ]),
    /** 标题按钮是否禁用 */
    disableTitleBar: PropTypes.bool,
    /** 组件当前显示级别,暂支持1-2 */
    currentView: PropTypes.oneOf([
        /** 显示年 */
        // 0,
        /** 显示月 */
        1,
        /** 显示日 */
        2,
        /** 显示小时 */
        // 3,
    ]),
    /** 组件可显示最大级别 */
    maxView: PropTypes.oneOf([
        /** 显示月 */
        1,
        /** 显示日 */
        2,
    ]),
    /** 当前选中的时间 */
    selectedDate: PropTypes.instanceOf(Date),
    /** 时间选择回调 */
    onSelected: PropTypes.func,
    /** 当前展示年, 如不设置, 以选中时间为准 */
    currentYear: PropTypes.number,
    /** 当前展示月 */
    currentMonth: PropTypes.number,
    /** 当前展示日, 暂不支持 */
    currentDate: PropTypes.number,
};

DateTimePicker.defaultProps = {
    showTitleBar: 'all',
    judgeDisable: () => false,
    titleBarTextAlign: 'center',
    disableTitleBar: false,
    currentView: 2,
    maxView: 2,
    selectedDate: new Date(),
    currentYear: null,
    currentMonth: null,
    currentDate: null,
    onSelected: () => {
    },
};
