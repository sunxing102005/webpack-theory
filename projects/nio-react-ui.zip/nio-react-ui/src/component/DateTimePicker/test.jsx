import React from 'react';
import DateTimePicker from './index';

describe('DateTimePicker', () => {
    it('should render correctly', () => {
        const wrapper = render(<DateTimePicker selectedDate={new Date('2020-08-05')} />);
        expect(wrapper).toMatchSnapshot();
    });

    it('should support basic usage', () => {
        const changeStateFake = jest.spyOn(DateTimePicker.prototype, 'changeState');
        const changeViewFake = jest.spyOn(DateTimePicker.prototype, 'changeView');
        const selectDateFake = jest.spyOn(DateTimePicker.prototype, 'selectDate');
        const wrapper = mount(
            <DateTimePicker
                selectedDate={new Date('2020-08-05')}
            />,
        );
        wrapper.setProps({
            disableTitleBar: true,
        });
        wrapper.find('.date-time-picker-title div').at(0).simulate('click');
        expect(changeStateFake).not.toHaveBeenCalled();
        wrapper.find('.date-time-picker-title div').at(1).simulate('click');
        expect(changeViewFake).not.toHaveBeenCalled();
        wrapper.setProps({
            disableTitleBar: false,
        });
        wrapper.find('.date-time-picker-title div').at(0).simulate('click');
        expect(changeStateFake).toHaveBeenCalledWith({ currentYear: 2020, currentMonth: 7 });
        wrapper.find('.date-time-picker-title div').at(2).simulate('click');
        expect(changeStateFake).toHaveBeenLastCalledWith({ currentYear: 2020, currentMonth: 8 });
        wrapper.find('.date-time-picker-title div').at(1).simulate('click');
        expect(changeViewFake).toHaveBeenCalledWith(1);
        wrapper.find('.date-time-picker-title div').at(1).simulate('click');
        expect(changeViewFake).toHaveBeenCalledTimes(1);
        wrapper.find('.date-time-picker-title div').at(0).simulate('click');
        expect(changeStateFake).toHaveBeenCalledWith({ currentYear: 2019 });
        wrapper.find('.date-time-picker-title div').at(2).simulate('click');
        expect(changeStateFake).toHaveBeenCalledWith({ currentYear: 2020 });
        wrapper.find('.month').at(0).simulate('click');
        expect(selectDateFake).toHaveBeenLastCalledWith(new Date(2020, 0, 1));
        expect(changeViewFake).toHaveBeenLastCalledWith(2);
        wrapper.find('.day').at(2).simulate('click');
        expect(selectDateFake).toHaveBeenLastCalledWith(new Date(2020, 0, 1));
        wrapper.setProps({ selectedDate: new Date() });
        wrapper.find('.day').not('.disable').at(0)
            .simulate('click');
        expect(selectDateFake).toHaveBeenCalledTimes(3);
        wrapper.find('.date-time-picker-title div').at(0).simulate('click');
        wrapper.find('.date-time-picker-title div').at(1).simulate('click');
        wrapper.find('.month').at(11).simulate('click');
        wrapper.find('.date-time-picker-title div').at(2).simulate('click');
    });
});

describe('DateTimePicker Unit Test', () => {
    it('should render title correctly', () => {
        const judgeDisable = jest.fn(() => false);
        const wrapper = mount(
            <DateTimePicker
                showTitleBar="none"
                judgeDisable={judgeDisable}
                selectedDate={new Date('2020-08-05')}
            />,
        );
        expect(judgeDisable).toHaveBeenCalled();
        expect(wrapper.exists('.date-time-picker-title')).toBe(false);
        wrapper.setProps({ showTitleBar: 'preAndNext' });
        expect(wrapper.exists('.title')).toBe(false);
        expect(wrapper.find('.date-time-picker-title div').length).toBe(2);
        wrapper.setProps({ showTitleBar: 'title' });
        expect(wrapper.exists('.title')).toBe(true);
        expect(wrapper.find('.date-time-picker-title div').length).toBe(1);
    });
});
