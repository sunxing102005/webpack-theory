import React from 'react';
import Index from './index';

describe('Hyperlink', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <div>
                <Index href="/aa/bb/cc">test link</Index>
                <Index>test link</Index>
                <Index environment="android" href="/aa/bb/cc" needChangeHyperlink>test link</Index>
                <Index environment="android" href="/aa/bb/cc" needChangeHyperlink={false}>test link</Index>
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });

    it('should support basic usage', () => {
        // 正常渲染为a标签
        const wrapper = shallow(<Index href="/aa/bb/cc">test link</Index>);
        expect(wrapper.find('a').exists()).toEqual(true);

        // 安卓环境下更新href
        wrapper.setProps({ environment: 'android' });
        wrapper.update();
        expect(wrapper.find('a[href="newtab:http://localhost/aa/bb/cc"]').exists()).toEqual(true);

        // 安卓环境下设置了无需更新标志位时不更新href
        wrapper.setProps({ environment: 'android', needChangeHyperlink: false });
        wrapper.update();
        expect(wrapper.find('a[href="/aa/bb/cc"]').exists()).toEqual(true);

        // href 为空时a标签被替换成repalceTag标签
        wrapper.setProps({ replaceTag: 'span', href: '' });
        wrapper.update();
        expect(wrapper.find('span').exists()).toEqual(true);
    });
});
