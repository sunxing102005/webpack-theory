import React from 'react';
import registerStory from '~storybook/index';
import Hyperlink from './index';

// register story
const {
    stories,
    knobs,
} = registerStory('Hyperlink');

const {
    text,
    boolean,
} = knobs;


stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件用来解决在nio app安卓客户端中超链接跳转不能新开activity问题
        `,
        },
    })
    .add('base usage', () => {
        const replaceTag = text('replaceTag', 'div');
        const needChangeHyperlink = boolean('needChangeHyperlink', false);
        const href = text('href', 'aa/bb/cc');
        const target = text('target', '');
        const environment = text('environment', 'ios');

        return (
            <Hyperlink
                environment={environment}
                href={href}
                replaceTag={replaceTag}
                needChangeHyperlink={needChangeHyperlink}
                target={target}
            >
                test link
            </Hyperlink>
        );
    });
