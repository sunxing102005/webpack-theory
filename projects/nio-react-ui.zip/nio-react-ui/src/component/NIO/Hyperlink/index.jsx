import React from 'react';
import PropTypes from 'prop-types';
import omit from 'omit.js';
import { PureComponent } from '~lib';

export default class Index extends PureComponent {
    render() {
        const {
            environment,
            href,
            target,
            replaceTag,
            needChangeHyperlink,
            children,
        } = this.props;
        const completeHref = href.indexOf('http') < 0 ? `${window.location.origin}${href}` : href;
        const newHref = environment === 'android' && needChangeHyperlink ? `newtab:${completeHref}` : href;
        const newTarget = environment === 'android' || !needChangeHyperlink ? '' : target;

        const Com = href ? 'a' : replaceTag;

        return (
            <Com href={newHref} target={newTarget} {...omit(this.props, ['href', 'needChangeHyperlink', 'replaceTag', 'target', 'children'])}>
                { children }
            </Com>
        );
    }
}

Index.propTypes = {
    /** 需要变更的超链接url */
    href: PropTypes.string,
    /** 需要变更的超链接target */
    target: PropTypes.string,
    /** 是否需要转换成nio 超链接 */
    needChangeHyperlink: PropTypes.bool,
    /** 当url为空时显示的Htmltag */
    replaceTag: PropTypes.string,
    /** 当前运行环境（ios/android） */
    environment: PropTypes.string,
    /** 内部子组件 */
    children: PropTypes.node,
};

Index.defaultProps = {
    href: '',
    target: '_blank',
    needChangeHyperlink: true,
    replaceTag: 'div',
    environment: '',
    children: null,
};
