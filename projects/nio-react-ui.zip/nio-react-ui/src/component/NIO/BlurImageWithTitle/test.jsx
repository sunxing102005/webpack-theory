import React from 'react';
import BlurImageWithEle from './index';

describe('BlurImageWithEle', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <BlurImageWithEle
                title="早鸟票开始抢购了"
                className="test-blur-img"
                blurWrapperClassName="test-blur-wrapper"
                src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png"
            />,
        );
        const wrapperError = render(
            <BlurImageWithEle
                title="早鸟票开始抢购了"
                className="test-blur-img"
                blurWrapperClassName="test-blur-wrapper"
                src="https://xxx.png"
            />,
        );
        expect(wrapper).toMatchSnapshot();
        expect(wrapperError).toMatchSnapshot();
    });
});

describe('BlurImageWithEle Event Test', () => {
    const onClick = jest.fn();
    const wrapper = mount(
        <BlurImageWithEle
            src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png"
            onClick={onClick}
        />,
    );
    it('should call onClick method', () => {
        wrapper
            .find('.nio-blur-img')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
});
describe('BlurImageWithEle  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<BlurImageWithEle />);
        const blurTitleWrapper = wrapper.find('.nio-blur-img__title').at(0);
        expect(blurTitleWrapper).toEqual({});
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('src')).toBe('');
        expect(wrapper.prop('title')).toBe('');
        expect(wrapper.prop('blurHeight')).toBe(0);
        expect(wrapper.prop('blurWrapperClassName')).toBe('');
        expect(wrapper.prop('onClick')).toBeNull();
    });
});
