import React from 'react';
import './index.scss';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

const itemLength = '215px';
class BlurImageWithTitle extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            loadingFlag: true, // 是否加载中
            errorFlag: true, // 是否加载出错
        };
    }

    componentDidMount() {
        this.loadImage();
    }

    loadImage = () => {
        if (!this.props.src) this.handleError();
        const img = new Image();
        img.onload = e => this.handleLoad(e, img);
        img.onerror = this.handleError;
        img.src = this.props.src;
    };

    handleError = () => {
        this.setState({ loadingFlag: false, errorFlag: true });
    };

    handleLoad = () => {
        this.setState({ loadingFlag: false, errorFlag: false });
    };

    render() {
        const {
            blurHeight,
            title,
            src,
            onClick,
            blurWrapperClassName,
        } = this.props;
        const { loadingFlag, errorFlag } = this.state;
        const style = {
            height: itemLength,
            width: itemLength,
        };
        const showDefaultImage = errorFlag || loadingFlag;
        const imgWrapperClassName = PureComponent.classNames(
            'nio-blur-img__image',
            {
                'nio-default-img': showDefaultImage,
            },
        );
        const imgStyle = !showDefaultImage
            ? { backgroundImage: `url(${src})` }
            : {};
        const blurWrapperStyle = blurHeight ? { height: blurHeight } : {};
        const containerClassName = this.className('swiper-slide', 'nio-blur-img');
        return (
            <div
                className={containerClassName}
                style={style}
                onClick={onClick}
            >
                <div className={imgWrapperClassName} style={imgStyle}>
                    {!showDefaultImage ? (
                        <div
                            className={`nio-blur-img__image__title ${blurWrapperClassName}`}
                            style={blurWrapperStyle}
                        >
                            <div className="nio-blur-img__image__text">{title}</div>
                        </div>
                    ) : null}
                </div>
            </div>
        );
    }
}
BlurImageWithTitle.defaultProps = {
    title: '',
    src: '',
    className: '',
    onClick: null,
    blurHeight: 0,
    blurWrapperClassName: '',
};
BlurImageWithTitle.propTypes = {
    /** 标题 */
    title: PropTypes.string,
    /** 图片src */
    src: PropTypes.string,
    /** 外层div className */
    // eslint-disable-next-line react/no-unused-prop-types
    className: PropTypes.string,
    /** 点击事件 */
    onClick: PropTypes.func,
    /** 模糊部分高度 */
    blurHeight: PropTypes.number,
    /** 模糊部分className */
    blurWrapperClassName: PropTypes.string,
};
export default BlurImageWithTitle;
