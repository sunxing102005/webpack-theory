import React from 'react';
import registerStory from '~storybook/index';
import BlurImageWithEle from './index';

const style = {
    wrapperStyle: {
        width: 200,
    },
};
// register story
const { stories, knobs } = registerStory('BlurImageWithEle', style);

const { text, number } = knobs;
function onClick() {
    console.log('call onclick method');
}
stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为毛玻璃图片设置标题，点击事件，图片样式等
          - 该组件可设置模糊部分样式及高度
        `,
        },
    })
    .add('base usage', () => {
        const src = text(
            'src',
            'https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png',
        );
        const title = text('title', '测试标题');
        const blurHeight = number('blurHeight', 60);

        return (
            <BlurImageWithEle
                src={src}
                title={title}
                blurHeight={blurHeight}
                onClick={onClick}
            />
        );
    });
