import React from 'react';
import PropTypes from 'prop-types';
import ImageWithEle from '../../ImageWithEle';
import CountDown from '../../CountDown';
import { PureComponent } from '~lib';
import './index.scss';

class LiveBanner extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            startFlag: true, // 是否开始倒计时，当倒计时为0，置为false
        };
        this.currentIndex = 0; // 加载list 中数据的下标
    }

    /**
     * 如果api countdown 返回false，则取list中第一个数据
     */
    componentDidUpdate(prevProps) {
        const { countdown, endTime } = this.props;
        if (!countdown) this.currentIndex = 0;
        if (countdown && endTime !== prevProps.endTime) {
            // 截止时间更改且countdown等于true时，重新开始计时
            this.currentIndex = 0;
            this.setState({ startFlag: true });
        }
    }

    /**
     * 获取list中想要加载的数据
     * @param {Array} list
     */
    getData(list) {
        return list[this.currentIndex] ? list[this.currentIndex] : list[0];
    }

    /**
     * 前端判断计时到0时执行回调
     * 此时没有请求接口，countdown依然为true
     * 并存在两个article
     * 将countdown组件 count设置为false
     * 并取第二个article数据
     */
    stopCountdown = () => {
        this.currentIndex = 1;
        this.setState({ startFlag: false });
    };

    render() {
        const {
            list,
            clickDetail,
            countdown = false,
            endTime,
            countdownTitle,
        } = this.props;
        const { startFlag } = this.state;
        const data = this.getData(list) || {};
        const title = (
            <p className="nio-live-banner__title">{countdownTitle}</p>
        );
        // 如果接口不返回倒计时截止时间，就显示默认时间
        const endTimeIsDate = endTime instanceof Date;
        const containerClassName = this.className('nio-live-banner');
        return (
            <React.Fragment>
                {data && (
                    <div
                        className={containerClassName}
                        onClick={e => clickDetail(e, { link: data.link, mtaKey: 'banner' })
                        }
                    >
                        {startFlag && countdown && endTimeIsDate
                        && (
                            <CountDown
                                deadline={endTime}
                                endCallback={this.stopCountdown}
                                className="nio-live-banner__countdown"
                                title={title}
                            />
                        )}
                        <ImageWithEle src={data.url} className="nio-live-banner__img" />
                    </div>
                )}
            </React.Fragment>
        );
    }
}
LiveBanner.propTypes = {
    /** 是否开启倒计时 */
    countdown: PropTypes.bool,
    /** banner数据,数组形式，倒计时过程中有2个数据，便于结束时换图 */
    list: PropTypes.arrayOf(PropTypes.shape({
        url: PropTypes.string.isRequired, // 图片url
    })),
    /** 点击事件 */
    clickDetail: PropTypes.func,
    /** 截止时间 Date类型 */
    endTime: PropTypes.object,
    /** 倒计时标题 */
    countdownTitle: PropTypes.string,
    /** 外层div自定义类名 */
    // eslint-disable-next-line react/no-unused-prop-types
    className: PropTypes.string,
};
LiveBanner.defaultProps = {
    countdown: false,
    list: [],
    clickDetail: null,
    endTime: null,
    countdownTitle: '距开始时间还有',
    className: '',
};
export default LiveBanner;
