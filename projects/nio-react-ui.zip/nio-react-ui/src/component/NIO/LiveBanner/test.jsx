import React from 'react';
import LiveBanner from './index';
import { getDateAdd } from '~utils/date';

const list = [{
    url: 'https://cdn-app.nio.com/user/2019/10/18/970f1295-0bb9-4b3a-a8c6-5db01f395b0f.jpg?imageView2/2/w/1024',
}];
describe('LiveBanner', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <LiveBanner
                list={list}
                countdown
                endTime={new Date('2021-10-01')}
                countdownTitle="距2021-10-01天还有"
            />,
        );
        const wrapperWithClassName = render(
            <LiveBanner
                list={list}
                className="test-live-banner"
                countdownTitle="距2021-10-01还有"
                countdown
                endTime={new Date('2021-10-01')}
            />,
        );
        expect(wrapper).toMatchSnapshot();
        expect(wrapperWithClassName).toMatchSnapshot();
    });
});
describe('liveBanner Event Test', () => {
    it('should call clickDetail method', () => {
        const onClick = jest.fn();
        const wrapper = mount(<LiveBanner
            list={list}
            clickDetail={onClick}
            countdown
            endTime={getDateAdd('d', 5, new Date())}
        />);
        wrapper
            .find('.nio-live-banner')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();

        wrapper.setProps({ endTime: new Date('2022-10-01') });
        expect(wrapper.state('startFlag')).toBe(true);
    });
});
describe('LiveBanner  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<LiveBanner />);
        expect(wrapper.prop('countdown')).toBe(false);
        expect(wrapper.prop('list')).toEqual([]);
        expect(wrapper.prop('clickDetail')).toBeNull();
        expect(wrapper.prop('endTime')).toBeNull();
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('countdownTitle')).toBe('距开始时间还有');
    });
});
