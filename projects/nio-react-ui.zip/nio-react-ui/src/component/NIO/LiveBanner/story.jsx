import React from 'react';
import registerStory from '~storybook/index';
import LiveBanner from './index';
import { getDateAdd } from '~utils/date';
import './story.scss';

const style = {
    wrapperStyle: {
        width: 300,
        height: 500,
    },
};
// register story
const { stories, knobs } = registerStory('LiveBanner', style);

const {
    text, boolean, date, object,
} = knobs;
const list = [{
    url: 'https://cdn-app.nio.com/user/2019/11/27/9fcced16-bb7a-42c7-b50c-df38ad7c6b80.jpg?imageView2/2/w/1024',
    link: 'link01',
},
{
    url: 'https://cdn-app.nio.com/user/2019/11/27/df1e3a64-a80a-44ca-8f98-afc57fca3a9f.png?imageView2/2/w/1024',
    link: 'link02',
},
];
function onClick(e, params) {
    console.log('call onclick method', params);
}
function myDateKnob(name, defaultValue) {
    const stringTimestamp = date(name, defaultValue);
    return new Date(stringTimestamp);
}
const fiveDaysLater = getDateAdd('d', 5, new Date());
stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为直播头图显示组件，含倒计时功能
          - 该组件提供图片list，点击事件，倒计时等属性
          - 当倒计时开始时，list长度等于2，倒计时结束后，头图等取list第二个元素
          - 其他时间list长度为1
        `,
        },
    })
    .add('base usage', () => {
        const countdownTitle = text(
            'countdownTitle',
            '距离五天后还有',
        );
        const countdown = boolean('countdown', true);
        const endTime = myDateKnob('endTime', fiveDaysLater);
        const data = object('list', list);
        return (
            <LiveBanner
                list={data}
                clickDetail={onClick}
                countdownTitle={countdownTitle}
                countdown={countdown}
                endTime={endTime}
            />
        );
    })
    .add('change image', () => {
        const countdownTitle = text(
            'countdownTitle',
            '距离五秒后还有',
        );
        const countdown = boolean('countdown', true);
        const data = object('list', list);
        return (
            <LiveBanner
                list={data}
                countdownTitle={countdownTitle}
                countdown={countdown}
                clickDetail={onClick}
                endTime={getDateAdd('s', 5, new Date())}
            />
        );
    });
