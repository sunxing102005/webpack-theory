import React from 'react';
import PropTypes from 'prop-types';
import CheckboxGroup from '../../CheckboxGroup';
import RadioGroup from '../../RadioGroup';
import Button from '../../Button';
import Progress from '../../Progress';
import Image from '../../Image';

import { Component } from '~lib';

import './index.scss';

class Vote extends Component {
    constructor(props) {
        super(props);
        this.state = {
            voteButtonDisable: true,
            voteData: {},
        };
        this.vote = this.vote.bind(this);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return nextProps.isVoted !== this.props.isVoted
        || nextState.voteButtonDisable !== this.state.voteButtonDisable
        || nextProps.isCanVote !== this.props.isCanVote
        || nextProps.voteStatus !== this.props.voteStatus
        || nextProps.resultVisibility !== this.props.resultVisibility
        || nextProps.resultType !== this.props.resultType
        || nextState.voteData !== this.state.voteData;
    }

    onChange(id, value) {
        const { isCanVote, questions } = this.props;
        /* eslint-disable prefer-const */
        let initVoteData = {};
        questions.forEach((q) => { initVoteData[q.id] = null; });
        let voteButtonDisable = false;
        /* eslint-disable react/no-access-state-in-setstate */
        let voteData = { ...initVoteData, ...this.state.voteData };
        voteData[id] = value;
        for (const v of Object.values(voteData)) {
            voteButtonDisable = !v || v.length < 1 || voteButtonDisable;
        }
        voteButtonDisable = voteButtonDisable || !isCanVote;
        this.setState({
            voteData,
            voteButtonDisable,
        });
    }

    vote() {
        const { onVote } = this.props;
        const { voteData } = this.state;
        onVote(voteData);
    }

    renderOption(option, showResult) {
        const {
            percentage = 0,
            votes = 0,
            imageUrl = '',
            desc = '',
        } = option;
        const {
            resultType,
        } = this.props;
        const resultContent = () => {
            let result = '';
            if (resultType === 0 || resultType === 2) {
                result = `${Math.round(percentage * 100)}%`;
            }
            if (resultType === 1 || resultType === 2) {
                result = `${result} ${votes}票`;
            }
            return result;
        };
        return (
            <React.Fragment>
                { imageUrl && (
                    <Image
                        className="nio-vote__option__img"
                        src={imageUrl}
                    />
                )}
                <div className="nio-vote__option__info">
                    <p className="nio-vote__option__label">{desc}</p>
                    { showResult && <p className="nio-vote__option__result">{resultContent()}</p> }
                    { showResult && <Progress value={percentage * 100} /> }
                </div>
            </React.Fragment>
        );
    }

    renderCheckboxOption(options, isResultShowBeforeVoted) {
        const {
            isCanVote,
        } = this.props;
        return (
            options.map(option => (
                {
                    value: option.id,
                    disabled: !isCanVote,
                    content: this.renderOption(option, isResultShowBeforeVoted),
                }
            ))
        );
    }

    renderRadioGroup(isResultShowBeforeVoted, question) {
        const { isCanVote } = this.props;
        const {
            voteData,
        } = this.state;
        const classString = Component.classNames(
            'nio-vote__option',
            {
                'nio-vote__option--disabled': !isCanVote,
            },
        );
        return (
            <RadioGroup
                className="nio-vote__options"
                checkboxClass={classString}
                value={voteData[question.id]}
                onChange={value => this.onChange(question.id, value)}
                items={this.renderCheckboxOption(question.options, isResultShowBeforeVoted)}
            />
        );
    }

    renderCheckboxGroup(isResultShowBeforeVoted, question) {
        const { isCanVote } = this.props;
        const {
            voteData,
        } = this.state;
        const classString = Component.classNames(
            'nio-vote__option',
            {
                'nio-vote__option--disabled': !isCanVote,
            },
        );
        return (
            <CheckboxGroup
                className="nio-vote__options"
                checkboxClass={classString}
                maxSelect={question.multiLimit}
                values={voteData[question.id] || []}
                /* eslint-disable react/jsx-boolean-value */
                autoToast={true}
                onChange={value => this.onChange(question.id, value)}
                items={this.renderCheckboxOption(question.options, isResultShowBeforeVoted)}
            />
        );
    }

    renderOptions(isResultShowBeforeVoted, question) {
        const {
            multiSelect,
        } = question;
        let Com = null;
        if (multiSelect === 0) {
            Com = this.renderRadioGroup(isResultShowBeforeVoted, question);
        } else {
            Com = this.renderCheckboxGroup(isResultShowBeforeVoted, question);
        }
        return Com;
    }


    renderVotedOption(option, voteStatus, isVoted, isResultShowAfterVoted, isResultShowBeforeVoted) {
        const {
            id,
            isSelected,
        } = option;
        const { isCanVote } = this.props;
        const classString = Component.classNames(
            'nio-vote__option',
            {
                'nio-vote__option--disabled': !isCanVote || (isVoted && !isSelected),
            },
        );
        const showResult = isResultShowBeforeVoted || isResultShowAfterVoted || voteStatus === 'finished';
        return (
            <div key={id} className={classString}>
                { this.renderOption(option, showResult)}
            </div>
        );
    }

    render() {
        const { voteButtonDisable } = this.state;

        const {
            isVoted, // 是否已投票
            questions,
            voteStatus, // 投票状态
            resultVisibility, // 投票结果是否可见
        } = this.props;

        const isResultShowAfterVoted = isVoted && resultVisibility !== 2; // 结果投票后可见

        const isResultShowBeforeVoted = resultVisibility === 1; // 结果投票前可见

        return (
            <div className="nio-vote">
                <p className="nio-vote__title">{`投票${voteStatus === 'finished' ? '已过期' : ''}`}</p>
                { questions.map(question => (
                    <article key={question.id} className="nio-vote__question">
                        <section className="nio-vote__question__title">
                            {question.multiSelect === 0 ? '单选 ' : '多选 '}
                                |
                            {` ${question.name}`}
                        </section>
                        <section className="nio-vote__question__sub-title">{question.desc}</section>
                        {
                            (!isVoted && voteStatus !== 'finished') ? (
                                <React.Fragment>
                                    { this.renderOptions(isResultShowBeforeVoted, question) }
                                </React.Fragment>
                            )
                                : (
                                    <section className="nio-vote__options">
                                        { question.options.map(option => (
                                            this.renderVotedOption(
                                                option,
                                                voteStatus,
                                                isVoted,
                                                isResultShowAfterVoted,
                                                isResultShowBeforeVoted,
                                            )
                                        ))}
                                    </section>
                                )
                        }
                    </article>
                ))}
                { isVoted && voteStatus !== 'finished' && resultVisibility === 2 && <p className="nio-vote__tip">已投票，投票截止后可见结果</p> }
                { !isVoted && voteStatus !== 'finished' && (
                    <Button
                        className="nio-vote__button"
                        disable={voteButtonDisable}
                        onClick={() => this.vote()}
                    >
                        投票
                    </Button>
                )}
            </div>
        );
    }
}

Vote.propTypes = {
    /** 是否已投票 */
    isVoted: PropTypes.bool,
    /** 投票问题列表 */
    questions: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string.isRequired,
            /** 投票问题名称 */
            name: PropTypes.string.isRequired,
            /** 投票是否为多选 */
            multiSelect: PropTypes.oneOf([
                /** 投票为单选 */
                0,
                /** 投票为多选 */
                1,
            ]),
            /** 投票为多选时最大可选个数 */
            multiLimit: PropTypes.number,
            /** 投票描述 */
            desc: PropTypes.string,
            /** 投票选项列表 */
            options: PropTypes.arrayOf(
                PropTypes.shape({
                    /** 该option在唯一辨识 */
                    id: PropTypes.string,
                    /** 该option在问题中结果百分比 */
                    percentage: PropTypes.number,
                    /** 该option是否被选 */
                    isSelected: PropTypes.bool,
                    /** 该option投票票数 */
                    votes: PropTypes.number,
                    /** 投票option图片 */
                    imageUrl: PropTypes.string,
                    /** 投票option描述 */
                    desc: PropTypes.string,
                }),
            ),
        }),
    ).isRequired,
    /** 是否有投票资格 */
    isCanVote: PropTypes.bool,
    /** 投票状态 */
    voteStatus: PropTypes.oneOf([
        /** 投票已结束 */
        'finished',
        /** 投票进行中 */
        'ongoing',
    ]),
    /** 投票结果展示方式 */
    resultType: PropTypes.oneOf([
        /** 投票结果展示百分比 */
        0,
        /** 投票结果展示票数 */
        1,
        /** 投票结果展示百分比和票数 */
        2,
    ]),
    /** 投票结果可见状态 */
    resultVisibility: PropTypes.oneOf([
        /** 结果投票后可见 */
        0,
        /** 结果投票前可见 */
        1,
        /** 结果结束后可见 */
        2,
    ]),
    /** 投票按钮点击 */
    onVote: PropTypes.func,
};

Vote.defaultProps = {
    isVoted: false,
    /** 是否有投票资格 */
    isCanVote: true,
    /** 投票状态 */
    voteStatus: 'ongoing',
    /** 投票结果可见状态 */
    resultVisibility: 2,
    resultType: 2,
    onVote: () => {},
};

export default Vote;
