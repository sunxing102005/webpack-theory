import React from 'react';
import Vote from './index';

describe('Vote', () => {
    const questions = [{
        desc: '谁是最美的山峰谁是最美的山峰谁是最美的山峰谁是最美的山峰',
        id: '69',
        multiLimit: 2,
        multiSelect: 1,
        name: '谁是最美的山峰',
        options: [{
            desc: '黄山是最美的山峰黄山是最美的山峰黄山是最美的山峰黄山是最美的山峰',
            id: '172',
            imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/f6512c01-8c68-4f44-b4ab-bf5a18ba89de.png',
            isSelected: false,
            percentage: 0.14,
            votes: 2086,
        }, {
            id: '173',
            imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/0e407a38-50ab-4ad9-9cf2-f9bb8e5a4c0e.png',
            isSelected: false,
            percentage: 0.14,
            votes: 2086,
        }, {
            desc: '庐山是最美的山峰庐山是最美的山峰庐山是最美的山峰庐山是最美的山峰庐山是最美的山峰',
            id: '174',
            imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/64e6c579-bcd6-4265-8633-09a2d0051cce.png',
            isSelected: false,
            percentage: 0.71,
            votes: 10238,
        }],
    }, {
        desc: '谁是最美的湖泊谁是最美的湖泊谁是最美的湖泊谁是最美的湖泊谁是最美的湖泊',
        id: '70',
        multiLimit: 1,
        multiSelect: 0,
        name: '谁是最美的湖泊',
        options: [{
            desc: '洞庭湖',
            id: '175',
            imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/6c7ac245-08c1-47dc-865d-13deae298db9.png',
            isSelected: false,
            percentage: 0.14,
            votes: 2086,
        }, {
            desc: '鄱阳湖',
            id: '176',
            imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/71df9291-1769-4f73-8a4f-e61991913000.png',
            isSelected: false,
            percentage: 0.14,
        }, {
            desc: '青海湖',
            id: '177',
            imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/1ca403bf-4645-4ac3-8d93-38b7b8a71a96.png',
            isSelected: false,
            votes: 10238,
        }, {
            desc: '太湖',
            id: '178',
            isSelected: false,
            percentage: 0.71,
            votes: 10238,
        }],
    }];

    it('should render correctly', () => {
        const wrapper = render(
            <Vote
                questions={questions}
            />,
        );
        expect(wrapper).toMatchSnapshot();
    });

    it('should cannot vote when isCanVote is false', () => {
        const wrapper = mount(
            <Vote
                isCanVote={false}
                questions={questions}
            />,
        );
        expect(wrapper.find('.nio-checkbox--disabled').length).toBe(7);
        expect(wrapper.state('voteButtonDisable')).toBe(true);
    });

    it('should cannot vote when voteStatus is finished', () => {
        const wrapper = mount(
            <Vote
                voteStatus="finished"
                questions={questions}
            />,
        );
        expect(wrapper.find('.nio-vote__title').text()).toBe('投票已过期');
        expect(wrapper.find('.nio-vote__button').length).toBe(0);
        expect(wrapper.exists('.nio-vote__option__result')).toBe(true);
        expect(wrapper.exists('.nio-progress-bar')).toBe(true);
        wrapper.setProps({ resultType: 0 });
        expect(wrapper.find('.nio-vote__option__result').first().text()).toBe('14%');
        wrapper.setProps({ resultType: 1 });
        expect(wrapper.find('.nio-vote__option__result').first().text()).toBe(' 2086票');
    });

    it('should can vote', () => {
        const onVote = jest.fn();
        const wrapper = mount(
            <Vote
                questions={questions}
                resultVisibility={1}
                onVote={onVote}
            />,
        );
        const c1 = wrapper.find('.nio-checkbox').at(0);
        const r1 = wrapper.find('.nio-checkbox').at(3);
        const onChange = jest.spyOn(Vote.prototype, 'onChange');
        expect(wrapper.exists('.nio-vote__option__result')).toBe(true);
        expect(wrapper.exists('.nio-progress-bar')).toBe(true);
        wrapper.setProps({ resultVisibility: 0 });
        expect(wrapper.exists('.nio-vote__option__result')).toBe(false);
        expect(wrapper.exists('.nio-progress-bar')).toBe(false);
        wrapper.setProps({ isVoted: true });
        expect(wrapper.exists('.nio-vote__option__result')).toBe(true);
        expect(wrapper.exists('.nio-progress-bar')).toBe(true);
        wrapper.setProps({ resultVisibility: 2 });
        expect(wrapper.exists('.nio-vote__option__result')).toBe(false);
        expect(wrapper.exists('.nio-progress-bar')).toBe(false);
        wrapper.setProps({ isVoted: false });
        c1.simulate('click');
        expect(wrapper.state('voteButtonDisable')).toBe(true);
        expect(onChange).toHaveBeenCalled();
        r1.simulate('click');
        expect(onChange).toHaveBeenCalledTimes(2);
        expect(wrapper.state('voteButtonDisable')).toBe(false);
        wrapper.find('.nio-vote__button').at(0).simulate('click');
        expect(onVote).toHaveBeenCalled();
    });
});
