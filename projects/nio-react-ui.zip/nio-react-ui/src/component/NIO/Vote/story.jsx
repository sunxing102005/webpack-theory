import React from 'react';
import registerStory from '~storybook';
import Vote from './index';

// register story
const storybook = registerStory('Vote', {
    wrapperStyle: {
        width: '500px',
        margin: '0 auto',
    },
});

const {
    knobs,
    state,
    stories,
} = storybook;

const {
    boolean,
    select,
} = knobs;

const {
    State,
    Store,
} = state;

const questions = [{
    desc: '谁是最美的山峰谁是最美的山峰谁是最美的山峰谁是最美的山峰',
    id: '69',
    multiLimit: 2,
    multiSelect: 1,
    name: '谁是最美的山峰',
    options: [{
        desc: '黄山是最美的山峰黄山是最美的山峰黄山是最美的山峰黄山是最美的山峰',
        id: '172',
        imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/f6512c01-8c68-4f44-b4ab-bf5a18ba89de.png',
        isSelected: false,
        percentage: 0.14,
        votes: 2086,
    }, {
        id: '173',
        imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/0e407a38-50ab-4ad9-9cf2-f9bb8e5a4c0e.png',
        isSelected: false,
        percentage: 0.14,
        votes: 2086,
    }, {
        desc: '庐山是最美的山峰庐山是最美的山峰庐山是最美的山峰庐山是最美的山峰庐山是最美的山峰',
        id: '174',
        imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/64e6c579-bcd6-4265-8633-09a2d0051cce.png',
        isSelected: false,
        percentage: 0.71,
        votes: 10238,
    }],
}, {
    desc: '谁是最美的湖泊谁是最美的湖泊谁是最美的湖泊谁是最美的湖泊谁是最美的湖泊',
    id: '70',
    multiLimit: 1,
    multiSelect: 0,
    name: '谁是最美的湖泊',
    options: [{
        desc: '洞庭湖',
        id: '175',
        imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/6c7ac245-08c1-47dc-865d-13deae298db9.png',
        isSelected: false,
        percentage: 0.14,
        votes: 2086,
    }, {
        desc: '鄱阳湖',
        id: '176',
        imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/71df9291-1769-4f73-8a4f-e61991913000.png',
        isSelected: false,
        percentage: 0.14,
    }, {
        desc: '青海湖',
        id: '177',
        imageUrl: 'https://cdn-app.nio.com/user/2020/7/23/1ca403bf-4645-4ac3-8d93-38b7b8a71a96.png',
        isSelected: false,
        votes: 10238,
    }, {
        desc: '太湖',
        id: '178',
        isSelected: false,
        percentage: 0.71,
        votes: 10238,
    }],
}];

const baseUsageStore = new Store({
    isVoted: false,
});

// 回调函数中通过store.set更新state
const voteHandler = (voteData) => {
    for (const [k, v] of Object.entries(voteData)) {
        const i = questions.findIndex(q => q.id === k);
        if (questions[i].multiSelect === 0) {
            const oi = questions[i].options.findIndex(o => o.id === v);
            questions[i].options[oi].isSelected = true;
        } else {
            v.forEach((vi) => {
                questions[i].options.find(o => o.id === vi).isSelected = true;
            });
        }
    }
    baseUsageStore.set({ isVoted: true, questions });
    console.log(`receive value by props 'onChange' : ${voteData} \n please update props 'questions' here to make selected option change actually`);
};

stories
// 该故事集下所有场景通用的Notes
// 支持Markdown语法或者普通文本
    .addParameters({
        info: {
            text: `
          ## Notes
          - 只适用于** 移动端 **
          - 必须更新props : ** columns **的value值，来改变组件选中选项的状态
          - wrapper height必须大于 numberToShow * optionSize (default as 180px)
          - 请在场景**base usage**下，使用devtool中的**device mode**查看组件使用效果
        `,
        },
    })
    // 添加场景'base usage'
    // State组件为 addon-state 提供，用来模拟外部state变化
    // text,boolean等函数为 addon-knobs提供，提供在 knobs panel中改变props的能力
    .add('base usage', () => {
        // const isVoted = boolean('isVoted', false);
        const isCanVote = boolean('isCanVote', true);
        const resultTypeOptions = {
            显示百分比: 0,
            显示票数: 1,
            显示百分比和票数: 2,
        };
        const resultType = select('resultType', resultTypeOptions, 2);
        const resultVisibilityOptions = {
            结果投票后可见: 0,
            结果投票前可见: 1,
            结果投票结束后可见: 2,
        };
        const resultVisibility = select('resultVisibility', resultVisibilityOptions, 0);

        const voteStatusOptions = {
            finished: 'finished',
            ongoing: 'ongoing',
        };
        const voteStatus = select('voteStatus', voteStatusOptions, 'ongoing');
        return (
            <State store={baseUsageStore}>
                <Vote
                    isCanVote={isCanVote}
                    isVoted={baseUsageStore.get('isVoted')}
                    resultType={resultType}
                    resultVisibility={resultVisibility}
                    voteStatus={voteStatus}
                    questions={questions}
                    onVote={voteHandler}
                />
            </State>
        );
    });
