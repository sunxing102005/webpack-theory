import React from 'react';
import PropTypes from 'prop-types';
import { Component } from '~lib';
import EndsLayout from '../EndsLayout';

import './index.scss';

const defaultUserPhoto = require('../../../static/images/default_user_photo.png');

export default class UserProfile extends Component {
    shouldComponentUpdate(nextProps) {
        return Component.shallowEqualOnKeys({
            pre: this.props,
            next: nextProps,
            keys: ['user'],
        });
    }

    render() {
        const {
            user = {}, size, showProfile, onClick,
        } = this.props;
        const {
            name = '',
            medal = {},
            headImage = '',
            department = '',
            publishTime = '',
            showNioIcon = true,
            needProfileDetail = true,
            profileDetailEllip = false,
            profileDetailType = '', // 个人字段类型 certification,department,publishTime
            profileIntro = '', // 个人信息字段,优先级最高
        } = user;

        const {
            certification = '', // 认证信息
            is_nio_authorized: isNio = false, // 是否展示姓名旁的nio标志
        } = medal;

        const profileDetailMap = {
            certification,
            department,
            publishTime,
        };

        const profileDetail = profileIntro || profileDetailMap[profileDetailType] || certification || department || publishTime || '';

        const userNameClassName = `ellip user-name ${isNio && showNioIcon ? 'with-employee-icon' : ''}`; // user-name class name
        const userProfileDetailClassName = `profile-detail ${profileDetailEllip ? 'ellip' : ''}`; // profile-detail class name
        const blockWrapClassName = this.className('user-profile', `${size}`);

        return (
            <EndsLayout className={blockWrapClassName} onClick={onClick}>
                <div className="user-profile__user-photo app-jump-logic">
                    <img alt="" className="user-profile__img avatar nio-invisible nio-internal" src={headImage || defaultUserPhoto} />
                    {medal && medal.img_url && <img alt="" className="user-profile__img nio-invisible nio-internal" src={medal.img_url} />}
                </div>
                {
                    showProfile && (
                        <div className="user-profile__profile">
                            <div className="user-profile__name-wrapper">
                                <p className={userNameClassName}>{name}</p>
                                {isNio && showNioIcon && <div className="nio-icon icon-employee" />}
                            </div>
                            <div className={userProfileDetailClassName}>{needProfileDetail && (profileDetail)}</div>
                        </div>
                    )
                }
            </EndsLayout>
        );
    }
}

UserProfile.propTypes = {
    /** 用户信息 */
    user: PropTypes.shape({
        name: PropTypes.string,
        medal: PropTypes.object,
        headImage: PropTypes.string,
        department: PropTypes.string,
        publishTime: PropTypes.string,
        showNioIcon: PropTypes.bool,
        needProfileDetail: PropTypes.bool,
        profileDetailEllip: PropTypes.bool,
        profileDetailType: PropTypes.string, // 个人字段类型 certification,department,publishTime
        profileIntro: PropTypes.string,
    }),
    /** 区域大小 属性值 small | normal | large | share */
    size: PropTypes.string,
    /** 是否展示用户头像 */
    showProfile: PropTypes.bool,
    /** 点击区域回调 */
    onClick: PropTypes.func,
};

UserProfile.defaultProps = {
    user: {},
    size: 'normal',
    showProfile: true,
    onClick: null,
};
