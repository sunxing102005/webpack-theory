import React from 'react';
import registerStory from '~storybook/index';
import UserProfile from './index';

const testData = {
    name: 'test name',
    medal: {
        certification: '认证: 认证用户',
        identity: 'pre_owner',
        img_url: 'https://cdn-app-test.nio.com/user/2019/9/20/4fb03901-e794-4b24-a1a3-a973f8d44516.png',
        is_nio_authorized: true,
        level_name: '准车主',
    },
    headImage: 'https://cdn-app-test.nio.com/account-center/2019/11/9/77109043-69ef-4d15-b6ba-49cbd5bff625.jpeg',
    department: '',
    publishTime: '2020-06-05',
    showNioIcon: true,
    needProfileDetail: true,
    profileDetailEllip: false,
    profileDetailType: 'publishTime', // 个人字段类型 certification,department,publishTime
    profileIntro: '',
};

const {
    stories,
    knobs,
} = registerStory('UserProfile');

const {
    boolean,
    select,
    object,
} = knobs;

const clickHandler = () => {
    console.log('UserProfile had been clicked');
};

stories
    .addParameters({
        info: {
            text: `
              ## Notes
              - 该组件为用户信息头像信息展示组件
              - 提供属性控制仅展示用户头像或展示用户昵称等信息
              - 提供 small | normal | large 三种尺寸，可通过size属性配置
            `,
        },
    })
    .add('base usage', () => {
        const size = select('size', { normal: 'normal', small: 'small', large: 'large' }, 'normal');
        const showProfile = boolean('showProfile', true);
        const user = object('user', testData);
        return (
            <UserProfile
                user={user}
                size={size}
                showProfile={showProfile}
                onClick={clickHandler}
            />
        );
    });
