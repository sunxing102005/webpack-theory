import React from 'react';
import UserProfile from './index';

const user = {};

describe('UserProfile', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <UserProfile user={user} />,
        );
        const smallSizeWrapper = render(
            <UserProfile user={user} size="small" />,
        );
        const largeSizeWrapper = render(
            <UserProfile user={user} size="large" />,
        );
        const withoutProfileWrapper = render(
            <UserProfile user={user} showProfile={false} />,
        );
        expect(wrapper).toMatchSnapshot();
        expect(smallSizeWrapper).toMatchSnapshot();
        expect(largeSizeWrapper).toMatchSnapshot();
        expect(withoutProfileWrapper).toMatchSnapshot();
    });
});

describe('UserProfile Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<UserProfile />);
        expect(wrapper.prop('user')).toEqual({});
        expect(wrapper.prop('size')).toBe('normal');
        expect(wrapper.prop('showProfile')).toBe(true);
        expect(wrapper.prop('onClick')).toBeNull();
    });
});

describe('UserProfile Event Test', () => {
    it('should call onClick method', () => {
        const onClick = jest.fn();
        const wrapper = mount(<UserProfile onClick={onClick} />);
        wrapper
            .find('.user-profile')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
});
