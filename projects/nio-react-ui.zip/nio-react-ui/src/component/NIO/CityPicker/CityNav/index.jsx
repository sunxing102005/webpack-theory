import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import './index.scss';

export default class CityNav extends PureComponent {
    renderNavItem() {
        const { cityNavData, navClick } = this.props;
        const array = [];
        /* eslint-disable no-plusplus */
        for (let i = 65; i < 91; i++) {
            const showNav = String.fromCharCode(i);
            array.push(<NavItem key={i} disable={!cityNavData.includes(showNav)} content={showNav} navClick={navClick} />);
        }
        array.push(<NavItem key={91} disable={false} content="#" navClick={navClick} />);
        return array;
    }

    render() {
        const { navPositionFixed } = this.props;
        return (
            <nav className={`nio-city-list-nav ${navPositionFixed ? 'fixed' : ''}`}>
                { this.renderNavItem() }
            </nav>
        );
    }
}

CityNav.defaultProps = {
    /** 热门城市数组 */
    cityNavData: [],
    /** 城市选择回调 */
    navClick: () => {},
    navPositionFixed: false,
};

CityNav.propTypes = {
    /* eslint-disable react/forbid-prop-types */
    /** 热门城市数组 */
    cityNavData: PropTypes.array,
    /** 城市选择回调 */
    navClick: PropTypes.func,
    /** 快速导航是否fixed */
    navPositionFixed: PropTypes.bool,
};

class NavItem extends PureComponent {
    constructor(props) {
        super(props);
        this.clickHandler = this.clickHandler.bind(this);
    }

    clickHandler() {
        const { content, disable = false, navClick } = this.props;
        /* eslint-disable  */
        !disable && navClick(content);
    }

    render() {
        const { content, disable = false } = this.props;
        return (
            <span className={`city-list-nav-item ${disable ? 'disable' : ''}`} onClick={this.clickHandler}>
                { content }
            </span>
        );
    }
}

NavItem.defaultProps = {
    /** 定位名称 */
    content: '',
    /** 定位选择回调 */
    navClick: () => {},
    disable: false,
};

NavItem.propTypes = {
    /** 定位名称 */
    content: PropTypes.string,
    /** 定位选择回调 */
    navClick: PropTypes.func,
    /** 是否为disable状态 */
    disable: PropTypes.bool,
};
