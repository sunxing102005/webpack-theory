import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import CityPickerSection from '../CityPickerSection';
import CityNav from '../CityNav';

import './index.scss';


export default class CityList extends PureComponent {
    getCityBlock() {
        const { cityData, cityClick } = this.props;
        const array = [];
        cityData.forEach((value) => {
            array.push(<CityBlockWithAnchor cityBlock={value} cityClick={cityClick} />);
        });
        return array;
    }

    render() {
        const { cityData, navClick, navPositionFixed } = this.props;

        return (
            <div className="nio-city-list">
                <CityNav cityNavData={Array.from(cityData.keys())} navPositionFixed={navPositionFixed} navClick={navClick} />
                <ul>
                    { this.getCityBlock() }
                </ul>
            </div>
        );
    }
}

CityList.defaultProps = {
    /** 城市列表map */
    cityData: new Map(),
    /** 城市选择回调 */
    cityClick: () => {},

    navClick: () => {},

    navPositionFixed: false,
};

CityList.propTypes = {
    /* eslint-disable react/forbid-prop-types */
    /** 城市列表map */
    cityData: PropTypes.object,
    /** 城市选择回调 */
    cityClick: PropTypes.func,
    /** 快速导航定位点击 */
    navClick: PropTypes.func,
    /** 快速导航是否fixed */
    navPositionFixed: PropTypes.bool,
};

class CityBlockWithAnchor extends PureComponent {
    render() {
        const { cityBlock = {}, cityClick } = this.props;
        return (
            <CityPickerSection className="city-block-with-anchor" title={cityBlock.key}>
                {
                    cityBlock.citys.map((city, index) => {
                        const key = cityBlock.key + index;
                        return <CityItem key={key} content={city} cityClick={cityClick} />;
                    })
                }
            </CityPickerSection>
        );
    }
}

CityBlockWithAnchor.defaultProps = {
    /** 城市首字母段 */
    cityBlock: {},
    /** 城市选择回调 */
    cityClick: () => {},
};

CityBlockWithAnchor.propTypes = {
    /* eslint-disable react/forbid-prop-types */
    /** 城市首字母段 */
    cityBlock: PropTypes.object,
    /** 城市选择回调 */
    cityClick: PropTypes.func,
};

class CityItem extends PureComponent {
    constructor(props) {
        super(props);
        this.clickHandler = this.clickHandler.bind(this);
    }

    clickHandler() {
        const { content: { city, area_code: cityCode } = {}, cityClick } = this.props;
        cityClick({ city, cityCode });
    }

    render() {
        const { content: { city } = {} } = this.props;
        return (
            <div className="city-item" onClick={this.clickHandler}>
                { city }
            </div>
        );
    }
}

CityItem.defaultProps = {
    /** 城市信息 */
    content: {},
    /** 城市选择回调 */
    cityClick: () => {},
};

CityItem.propTypes = {
    /* eslint-disable react/forbid-prop-types */
    /** 城市信息 */
    content: PropTypes.object,
    /** 城市选择回调 */
    cityClick: PropTypes.func,
};
