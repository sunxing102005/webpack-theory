import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import CityPickerSection from '../CityPickerSection';
import Icon from '../../../Icon';
import './index.scss';

export default class CityLocate extends PureComponent {
    constructor(props) {
        super(props);
        this.clickHandler = this.clickHandler.bind(this);
    }

    clickHandler() {
        const {
            cityClick,
            locateStatus,
            city,
            cityCode,
        } = this.props;
        cityClick({ locateStatus, city, cityCode });
    }

    render() {
        const {
            city,
            locateStatus,
            locationInfo,
            locateErrorInfo,
        } = this.props;
        const locateText = city || (locateStatus === 'error' ? locateErrorInfo : locationInfo);
        return (
            <CityPickerSection className="nio-city-locate" title="当前位置">
                <div className="city-locate-label" onClick={this.clickHandler}>
                    <Icon name="icon-map" />
                    <span>
                        {' '}
                        {locateText}
                        {' '}
                    </span>
                </div>
            </CityPickerSection>
        );
    }
}

CityLocate.defaultProps = {
    /** 定位城市名称 */
    city: '',
    /** 定位城市areacode */
    cityCode: '',
    /** 定位状态 */
    locateStatus: 'loading',
    /** 正在定位时显示信息 */
    locationInfo: '正在定位中...',
    /** 定位失败时显示信息 */
    locateErrorInfo: '定位失败...',
    /** 城市选择回调 */
    cityClick: () => {},
};

CityLocate.propTypes = {
    /** 定位城市名称 */
    city: PropTypes.string,
    /** 定位城市areacode */
    cityCode: PropTypes.string,
    /** 定位状态 */
    locateStatus: PropTypes.oneOf(['loading', 'success', 'error']),
    /** 正在定位时显示信息 */
    locationInfo: PropTypes.string,
    /** 定位失败时显示信息 */
    locateErrorInfo: PropTypes.string,
    /** 城市选择回调 */
    cityClick: PropTypes.func,
};
