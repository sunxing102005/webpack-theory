import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import CityPickerSection from '../CityPickerSection';

import './index.scss';

export default class CityFavor extends PureComponent {
    render() {
        const { favorCityList = [], cityClick } = this.props;
        return (
            <CityPickerSection className="nio-city-favor" title="热门选择">
                {
                    favorCityList.slice(0, 9).map((item, index) => {
                        const {
                            city: {
                                title = '',
                            } = {},
                        } = item;
                        const key = title + index;
                        return <CityTag key={key} city={item.city} cityClick={cityClick} />;
                    })
                }
            </CityPickerSection>
        );
    }
}

CityFavor.defaultProps = {
    /** 热门城市数组 */
    favorCityList: [],
    /** 城市选择回调 */
    cityClick: () => {},
};

CityFavor.propTypes = {
    /* eslint-disable react/forbid-prop-types */
    /** 热门城市数组 */
    favorCityList: PropTypes.array,
    /** 城市选择回调 */
    cityClick: PropTypes.func,
};

class CityTag extends PureComponent {
    constructor(props) {
        super(props);
        this.clickHandler = this.clickHandler.bind(this);
    }

    clickHandler() {
        const {
            city: {
                title: city,
                zone_code: cityCode,
            } = {},
            cityClick,
        } = this.props;
        cityClick({ city, cityCode });
    }

    render() {
        const { city: { title: city } = {} } = this.props;

        return (
            <span className="city-tag" onClick={this.clickHandler}>
                { city }
            </span>
        );
    }
}

CityTag.defaultProps = {
    /** 城市信息 */
    city: {},
    /** 城市选择回调 */
    cityClick: () => {},
};

CityTag.propTypes = {
    /* eslint-disable react/forbid-prop-types */
    /** 城市信息 */
    city: PropTypes.object,
    /** 城市选择回调 */
    cityClick: PropTypes.func,
};
