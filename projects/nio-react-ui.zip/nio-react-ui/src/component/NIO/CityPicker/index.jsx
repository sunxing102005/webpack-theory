import React from 'react';
import PropTypes from 'prop-types';
import underscore from 'underscore';
import { PureComponent } from '~lib';
import CityList from './CityList';
import CityLocate from './CityLocate';
import CityFavor from './CityFavor';

import './index.scss';

const cityBlockAnchorHeight = 25;
const cityItemHeight = 61;
const cityBlockMarginTop = 0;
const cityListOffsetTop = 260;

export default class Index extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            navPositionFixed: false,
        };
        this.cityPicker = React.createRef();
        this.cityClick = this.cityClick.bind(this);
        this.changeTitleState = this.changeTitleState.bind(this);
        this.navClick = this.navClick.bind(this);
        this.handleScroll = underscore.throttle(this.changeTitleState, 300); //  滚动事件节流执行
        this.shouldAddScrollHandler = true;
        this.timer = 0;
    }

    componentDidMount() {
        if (this.shouldAddScrollHandler) {
            this.cityPicker.current.addEventListener('scroll', this.handleScroll);
            this.shouldAddScrollHandler = false;
        }
    }

    componentWillUnmount() {
        this.cityPicker.current.removeEventListener('scroll', this.handleScroll);
    }

    changeTitleState() {
        const { scrollTop } = this.cityPicker.current;
        if (scrollTop < 89) {
            this.setState({
                navPositionFixed: false,
            });
        } else if (scrollTop >= 89 && scrollTop < 233) {
            this.setState({
                navPositionFixed: false,
            });
        } else {
            this.setState({
                navPositionFixed: true,
            });
        }
    }

    cityClick(value) {
        const { onChange } = this.props;
        onChange(value);
    }

    navClick(navIndex) {
        this.cityListScrollTo(navIndex);
    }

    cityListScrollTo(navIndex) {
        const { citys } = this.props;
        clearInterval(this.timer);
        const cityBlock = citys.get(navIndex);
        if (!cityBlock) {
            return;
        }
        const { offsetHeight, scrollHeight } = this.cityPicker.current;
        const target = cityBlock.sectionIndex * (cityBlockAnchorHeight + cityBlockMarginTop)
            + cityBlock.cityIndex * cityItemHeight
            + cityListOffsetTop
            - cityBlockAnchorHeight - 2;
        this.timer = setInterval(() => {
            let leader = this.cityPicker.current.scrollTop;
            let step = (target - leader) / 10;
            step = step > 0 ? Math.ceil(step) : Math.floor(step);
            leader += step;
            this.cityPicker.current.scrollTop = leader;
            if (leader === target || leader + offsetHeight >= scrollHeight || leader <= 0) {
                clearInterval(this.timer);
            }
        }, 15);
    }

    render() {
        const { navPositionFixed } = this.state;
        const {
            showBox, citys, locateCity, locateCityCode, locateStatus, locationInfo, locateErrorInfo, favorCityList = [],
        } = this.props;
        return (
            <React.Fragment>
                { showBox && <div className="nio-header-box" /> }
                <div className={this.className('nio-city-picker', showBox && 'from-top')} ref={this.cityPicker}>
                    <CityLocate
                        city={locateCity}
                        cityCode={locateCityCode}
                        locationInfo={locationInfo}
                        locateStatus={locateStatus}
                        locateErrorInfo={locateErrorInfo}
                        cityClick={this.cityClick}
                    />
                    { favorCityList.length > 0 && <CityFavor favorCityList={favorCityList} cityClick={this.cityClick} /> }
                    <CityList cityData={citys} navClick={this.navClick} cityClick={this.cityClick} navPositionFixed={navPositionFixed} />
                </div>
            </React.Fragment>
        );
    }
}

Index.propTypes = {
    /* eslint-disable react/forbid-prop-types */
    /** 城市列表Map key为拼音索引 value为数组 */
    citys: PropTypes.object,
    /** 定位城市名称 */
    locateCity: PropTypes.string,
    /** 定位城市areacode */
    locateCityCode: PropTypes.string,
    /** 定位状态 */
    locateStatus: PropTypes.oneOf(['loading', 'success', 'error']),
    /** 正在定位时显示信息 */
    locationInfo: PropTypes.string,
    /** 定位失败时显示信息 */
    locateErrorInfo: PropTypes.string,
    /** 热门城市数组 */
    favorCityList: PropTypes.array,
    /** 是否需要预留页面顶部 */
    showBox: PropTypes.bool,
    /** 城市选择回调 */
    onChange: PropTypes.func,
};

Index.defaultProps = {
    /** 城市列表Map key为拼音索引 value为数组 */
    citys: new Map(),
    /** 定位城市名称 */
    locateCity: '',
    /** 定位城市areacode */
    locateCityCode: '',
    /** 定位状态 */
    locateStatus: 'loading',
    /** 正在定位时显示信息 */
    locationInfo: '正在定位中...',
    /** 定位失败时显示信息 */
    locateErrorInfo: '定位失败...',
    /** 热门城市数组 */
    favorCityList: [],
    /** 是否需要预留页面顶部 */
    showBox: false,
    /** 城市选择回调 */
    onChange: null,
};
