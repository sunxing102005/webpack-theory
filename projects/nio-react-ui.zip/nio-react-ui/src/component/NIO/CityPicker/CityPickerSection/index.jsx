import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import './index.scss';

export default class CityPickerSection extends PureComponent {
    render() {
        const { title, children } = this.props;
        return (
            <section className={this.className('nio-city-picker-section')}>
                <h3 className="city-picker-section-title">{ title }</h3>
                <div className="city-picker-section-content">{ children }</div>
            </section>
        );
    }
}

CityPickerSection.defaultProps = {
    title: '',
    children: null,
};

CityPickerSection.propTypes = {
    /** 段落title */
    title: PropTypes.string,
    /** 内部子组件 */
    children: PropTypes.node,
};
