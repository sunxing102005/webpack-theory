import React from 'react';
import PropTypes from 'prop-types';
import Card from '../../Card';
import UserProfile from '../UserProfile';
import './index.scss';

function Synopsis(props) {
    const {
        synopsis: {
            publisher: {
                user_id: id,
                head_image: headImage,
                name,
                medal,
            } = {},
            synopsis,
        },
        showCard = false,
        onClick,
    } = props;

    const user = {
        name,
        id,
        headImage,
        medal,
        needProfileDetail: false,
    };

    return (
        showCard
            ? (
                <Card
                    className="comparison-userpost-card"
                    shadowArround
                    onClick={onClick}
                >
                    <p className="comparison-userpost-card__content">
                        {synopsis}
                    </p>
                    <UserProfile
                        className="comparison-userpost-card__user"
                        user={user}
                        size="small"
                    />
                </Card>
            )
            : (
                <section
                    className="comparison-userpost"
                    onClick={onClick}
                >
                    <UserProfile
                        user={user}
                        className="comparison-userpost__user"
                    />
                    <p className="comparison-userpost__content">
                        {synopsis}
                    </p>
                </section>
            )
    );
}

Synopsis.propTypes = {
    /** 版块信息 */
    synopsis: PropTypes.shape({
        publisher: PropTypes.shape({
            user_id: PropTypes.string,
            head_image: PropTypes.string,
            name: PropTypes.string,
            medal: PropTypes.object,
        }),
        synopsis: PropTypes.string,
    }),
    /** 是否以卡片形式展示 */
    showCard: PropTypes.bool,
    /** 点击区域回调 */
    onClick: PropTypes.func,
};

Synopsis.defaultProps = {
    synopsis: {},
    showCard: false,
    onClick: null,
};

export default Synopsis;
