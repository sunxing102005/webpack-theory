import React from 'react';
import registerStory from '~storybook/index';
import Synopsis from './index';

const testData = {
    publisher: {
        user_id: '101319',
        head_image: 'https://cdn-app-test.nio.com/account-center/2019/11/9/77109043-69ef-4d15-b6ba-49cbd5bff625.jpeg',
        name: '116哦啦',
        medal: {
            certification: '认证: 认证用户',
            identity: 'pre_owner',
            img_url: 'https://cdn-app-test.nio.com/user/2019/9/20/4fb03901-e794-4b24-a1a3-a973f8d44516.png',
            is_nio_authorized: true,
            level_name: '准车主',
        },
    },
    synopsis: '我是116，短视频-此刻，@段永刚 #漫画好可爱# #短视频话题# 老南京啦懒得楼里计较KKK路我',
};

const {
    stories,
    knobs,
} = registerStory('Synopsis');

const {
    boolean,
    object,
} = knobs;

const clickHandler = () => {
    console.log('Synopsis had been clicked');
};

stories
    .addParameters({
        info: {
            text: `
              ## Notes
              - 该组件为用户信息展示模块
              - synopsis属性为模块展示数据
              - showCard属性控制模块展示方式是否使用card形式
              - onClick为点击回调
            `,
        },
    })
    .add('base usage', () => {
        const showCard = boolean('showCard', false);
        const synopsis = object('synopsis', testData);
        return (
            <Synopsis synopsis={synopsis} showCard={showCard} onClick={clickHandler} />
        );
    });
