import React from 'react';
import Synopsis from './index';

const synopsis = {
    publisher: {
        user_id: '101319',
        head_image: 'https://cdn-app-test.nio.com/account-center/2019/11/9/77109043-69ef-4d15-b6ba-49cbd5bff625.jpeg',
        name: '116哦啦',
        medal: {
            certification: '认证: 认证用户',
            identity: 'pre_owner',
            img_url: 'https://cdn-app-test.nio.com/user/2019/9/20/4fb03901-e794-4b24-a1a3-a973f8d44516.png',
            is_nio_authorized: true,
            level_name: '准车主',
        },
    },
    synopsis: '我是116，短视频-此刻，@段永刚 #漫画好可爱# #短视频话题# 老南京啦懒得楼里计较KKK路我',
};

describe('Synopsis', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <Synopsis
                synopsis={synopsis}
            />,
        );
        const wrapperShowAsCard = render(
            <Synopsis
                synopsis={synopsis}
                showCard
            />,
        );
        expect(wrapper).toMatchSnapshot();
        expect(wrapperShowAsCard).toMatchSnapshot();
    });
});

describe('Synopsis Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<Synopsis />);
        expect(wrapper.prop('synopsis')).toEqual({});
        expect(wrapper.prop('showCard')).toBe(false);
        expect(wrapper.prop('onClick')).toBeNull();
    });
});

describe('Synopsis Event Test', () => {
    const onClick = jest.fn();
    it('should call onClick method', () => {
        const wrapper = mount(<Synopsis synopsis={synopsis} onClick={onClick} />);
        wrapper
            .find('.comparison-userpost')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
    it('should call onClick method when show as card', () => {
        const wrapper = mount(<Synopsis synopsis={synopsis} onClick={onClick} showCard />);
        wrapper
            .find('.comparison-userpost-card')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
});
