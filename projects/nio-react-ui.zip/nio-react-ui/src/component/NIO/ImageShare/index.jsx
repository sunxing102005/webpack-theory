import React from 'react';
import PropTypes from 'prop-types';
import UserProfile from '../UserProfile';
import Image from '../../Image';

import './index.scss';

function ImageShare(props) {
    const getElement = () => {
        const {
            title,
            name,
            desc,
            type,
            image,
        } = props;
        let Com = '';
        if (type === 'article') {
            Com = (
                <React.Fragment>
                    <Image className="share-page__img--article" src={image} />
                    <section className="share-page__img--content">
                        <p className="share-page__title">{title}</p>
                        <p className="share-page__name">{name}</p>
                        <p className="share-page__desc">{desc}</p>
                    </section>
                </React.Fragment>
            );
        } else if (type === 'brand') {
            Com = <Image className="share-page__img--brand" src={image} />;
        }
        return Com;
    };

    const {
        className = '',
        hidden,
        userProfile,
        info,
        qcCode,
    } = props;

    const user = { ...userProfile, needProfileDetail: false };

    return (
        <div id="share_page" className={`share-page ${className} ${hidden ? 'hidden' : ''}`}>
            {getElement()}
            <div className="share-page__download">
                <div className="share-page__info">
                    <UserProfile size="share" user={user} />
                    <p className="share-page__desc">{info}</p>
                </div>
                <div className="share-page__code">
                    <Image
                        needBackgroundImage={false}
                        src={qcCode}
                    />
                </div>
            </div>
        </div>
    );
}

ImageShare.propTypes = {
    /** 组件类名 */
    className: PropTypes.string,
    /** 组件是否在页面上展示 */
    hidden: PropTypes.bool,
    /** 用户信息 */
    userProfile: PropTypes.shape({
        name: PropTypes.string,
        medal: PropTypes.shape({
            img_url: PropTypes.string,
            is_nio_authorized: PropTypes.bool,
        }),
        headImage: PropTypes.string,
    }),
    /** 下载区域用户头像下方的展示文案 */
    info: PropTypes.string,
    /** 生成的分享图片格式 */
    type: PropTypes.oneOf([
        'article',
        'brand',
    ]),
    /** 下载区域的二维码图片 */
    qcCode: PropTypes.string,
    /** 分享具体article图片时的标题 */
    title: PropTypes.string,
    /** 分享具体article图片时的名称 */
    name: PropTypes.string,
    /** 分享具体article图片时的描述 */
    desc: PropTypes.string,
    /** 分享的图片 */
    image: PropTypes.string,
};

ImageShare.defaultProps = {
    className: '',
    hidden: false,
    userProfile: {},
    info: '我就是个测试文案',
    type: 'article',
    qcCode: '',
    title: '精品活动',
    name: '上海活动1',
    desc: '我是一个特别有意思的活动哦',
    image: 'https://cdn-app.nio.com/user/2019/4/10/2ae052c1-d4f3-4cc0-a2e3-ecf3464c5b9b.jpg',
};

export default ImageShare;
