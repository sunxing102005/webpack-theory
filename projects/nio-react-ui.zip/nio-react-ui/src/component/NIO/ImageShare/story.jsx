import React from 'react';
import registerStory from '~storybook';
import ImageShare from './index';

// register story
const {
    stories,
    knobs,
} = registerStory('ImageShare');

const {
    text,
    object,
    boolean,
} = knobs;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件提供海报生成样式
          - ** 注意 **props : ** type **不同时，某些参数不生效，请参考doc
          - ** 注意 **在正式使用该组件生成图片时，如果不需要在页面上展示生成的图片样式，可设置props : ** hidden **为true
        `,
        },
    });

const testData = {
    name: 'test name',
    medal: {
        img_url: 'https://cdn-app-test.nio.com/user/2019/9/20/4fb03901-e794-4b24-a1a3-a973f8d44516.png',
        is_nio_authorized: true,
    },
    headImage: 'https://cdn-app-test.nio.com/account-center/2019/11/9/77109043-69ef-4d15-b6ba-49cbd5bff625.jpeg',
};

story.add('article image share', () => {
    const hidden = boolean('hidden', false);
    const title = text('title', '精品活动');
    const name = text('name', '上海活动1');
    const desc = text('desc', '我是一个特别有意思的活动哦');
    const userInArticle = object('user', testData);
    const infoInArticle = text('info', '我就是个测试文案');
    const qcCodeInArticle = text('qcCode', 'https://cdn-app.nio.com/c83934555f37498892f5319f6725ea7c.png');
    const imageInArticle = text('image', 'https://cdn-app.nio.com/user/2019/4/10/2ae052c1-d4f3-4cc0-a2e3-ecf3464c5b9b.jpg');

    return (
        <ImageShare
            type="article"
            hidden={hidden}
            title={title}
            userProfile={userInArticle}
            name={name}
            desc={desc}
            info={infoInArticle}
            qcCode={qcCodeInArticle}
            image={imageInArticle}
        />
    );
})
    .add('brand image share', () => {
        const hiddenInBrand = boolean('hidden', false);
        const userInBrand = object('user', testData);
        const infoInBrand = text('info', '我就是个测试文案');
        const qcCodeInBrand = text('qcCode', 'https://cdn-app.nio.com/c83934555f37498892f5319f6725ea7c.png');
        const imageInBrand = text('image', 'https://cdn-app.nio.com/user/2019/4/10/2ae052c1-d4f3-4cc0-a2e3-ecf3464c5b9b.jpg');
        return (
            <ImageShare
                type="brand"
                hidden={hiddenInBrand}
                info={infoInBrand}
                userProfile={userInBrand}
                qcCode={qcCodeInBrand}
                image={imageInBrand}
            />
        );
    });
