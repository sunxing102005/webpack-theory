import React from 'react';
import ImageShare from './index';

describe('ImageShare', () => {
    it('should render correctly', () => {
        const wrapperArticle = render(
            <ImageShare
                type="article"
            />,
        );
        const wrapperBrand = render(
            <ImageShare
                type="brand"
            />,
        );
        expect(wrapperArticle).toMatchSnapshot();
        expect(wrapperBrand).toMatchSnapshot();
    });
});
