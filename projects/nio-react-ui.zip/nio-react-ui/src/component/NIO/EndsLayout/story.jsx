import React from 'react';
import registerStory from '~storybook/index';
import EndsLayout from './index';

const {
    stories,
    knobs,
} = registerStory('EndsLayout');

const {
    text,
} = knobs;

const clickHandler = () => {
    console.log('EndsLayout had been clicked');
};

stories
    .addParameters({
        info: {
            text: `
              ## Notes
              - flex layout容器组件，均分排列块级子元素
              - 点击跳转功能基于Hyperlink组件
              - href为跳转link
              - onClick为点击回调
            `,
        },
    })
    .add('base usage', () => {
        const href = text('href', '');
        return (
            <EndsLayout href={href} onClick={clickHandler}>
                <p>EndsLayout content left</p>
                <p>EndsLayout content center</p>
                <p>EndsLayout content right</p>
            </EndsLayout>
        );
    });
