import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Hyperlink from '../Hyperlink';

import './index.scss';

function EndsLayout(props) {
    const {
        className, children, href, onClick,
    } = props;

    const classString = classnames(className, {
        'nio-ends-container': true,
    });

    return (
        <Hyperlink className={classString} href={href} onClick={onClick}>
            { children }
        </Hyperlink>
    );
}

EndsLayout.defaultProps = {
    href: '',
    className: '',
    onClick: null,
    children: null,
};

EndsLayout.propTypes = {
    /** 跳转链接 */
    href: PropTypes.string,
    /** 自定义样式class */
    className: PropTypes.string,
    /** 点击回调 */
    onClick: PropTypes.func,
    /** 内部子组件,只能是单个元素 */
    children: PropTypes.node,
};

export default EndsLayout;
