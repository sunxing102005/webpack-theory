import React from 'react';
import EndsLayout from './index';

describe('EndsLayout', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <EndsLayout>
                <p>EndsLayout test</p>
            </EndsLayout>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

describe('EndsLayout Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<EndsLayout><p>EndsLayout test</p></EndsLayout>);
        expect(wrapper.prop('href')).toBe('');
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('onClick')).toBeNull();
    });
});

describe('EndsLayout Event Test', () => {
    it('should call onClick method', () => {
        const onClick = jest.fn();
        const wrapper = mount(<EndsLayout onClick={onClick} />);
        wrapper
            .find('.nio-ends-container')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
});
