import React from 'react';
import registerStory from '~storybook/index';
import './story.scss';

const {
    stories,
} = registerStory('FontRules');

stories
    .addParameters({
        info: {
            text: `
              ## Notes
              - 该页面用来展示NIO APP中字体规范
            `,
        },
    })
    .add('base usage', () => (
        <div>
            <p>
                    字体:font-family
                {' '}
                <br />
                    中文：PingFang SC
                {' '}
                <br />
                    英文：Blue Sky Standard // 目前在单独的数字以及英文时使用，一般出现在标题等文字比较大的情况
            </p>

            <p className="font-nav-title">
                导航条大标题文字 @mixin font-nav-title
                <br />
                font-size: 30px;
                {' '}
                <br />
                line-height: 42px;
                <br />
                font-color: #363c54;
                <br />
                font-weight: 600;
                <br />
            </p>
            <p className="font-title">
                页面标题文字 @mixin font-title
                <br />
                font-size: 24px;
                {' '}
                <br />
                line-height: 33px;
                <br />
                font-color: #363c54;
                <br />
                font-weight: 600;
                <br />
            </p>
            <p className="font-sub-title">
                段落标题文字 @mixin font-sub-title
                <br />
                font-size: 20px;
                {' '}
                <br />
                line-height: 28px;
                <br />
                font-color: #363c54;
                <br />
                font-weight: 600;
                <br />
            </p>
            <p className="font-dialog-title">
                弹框加粗文字 @mixin font-dialog-title
                <br />
                font-size: 18px;
                <br />
                line-height: 25px;
                <br />
                font-color: #363c54;
                <br />
                font-weight: 600;
                <br />
            </p>
            <p className="font-larger">
                正文文字／标题文字 @mixin font-larger
                <br />
                font-size: 16px;
                <br />
                line-height: 22px;
                <br />
                font-color: #363c54;
                <br />
            </p>
            <p className="font-base-content">
                文章文字 @mixin font-base-content
                <br />
                font-size: 16px;
                <br />
                line-height: 30px;
                <br />
                font-color: #363c54;
                <br />
            </p>
            <p className="font-tip">
                提示文字 @mixin font-tip
                <br />
                font-size: 14px;
                <br />
                line-height: 20px;
                <br />
                font-color: #9B9DA9;
                <br />
            </p>
            <p className="font-small">
                提示文字small @mixin font-small
                <br />
                font-size: 12px;
                <br />
                line-height: 17px;
                <br />
                font-color: #9B9DA9;
                <br />
            </p>
        </div>
    ));
