import React from 'react';
import NioVlog from './index';
import Toast from '../../Toast';

jest.mock('../../Toast');

const vlogSrc = 'http://1400292488.vod2.myqcloud.com/d4534610vodtranscq1400292488/bfea1bf55285890803966170757/v.f30.mp4';
const posterSrc = 'https://cdn-app-test.nio.com/user/2019/11/26/6f229173-7cd7-4a27-840f-03a2cfb6e68b.jpg';

describe('NioVlog', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <NioVlog src={vlogSrc} poster={posterSrc} />,
        );
        const posterWrapper = render(
            <NioVlog src={vlogSrc} poster={posterSrc} onlyShowPoster />,
        );
        expect(wrapper.find('.nio-vlog__progress').length).toBe(1);
        expect(wrapper.find('.nio-vlog__img-bg').length).toBe(0);
        expect(wrapper).toMatchSnapshot();
        expect(posterWrapper.find('.nio-vlog__progress').length).toBe(0);
        expect(posterWrapper.find('.nio-vlog__duration').length).toBe(1);
        expect(posterWrapper.find('.nio-vlog__img-bg').length).toBe(1);
        expect(posterWrapper).toMatchSnapshot();
    });
});

describe('NioVlog Event Test', () => {
    const palyFake = jest.spyOn(NioVlog.prototype, 'play');
    const pauseFake = jest.spyOn(NioVlog.prototype, 'pause');
    const videoPlayStatusChangeFunc = jest.spyOn(NioVlog.prototype, 'onVideoPlayStatusChange');
    const videoDurationChangeFunc = jest.spyOn(NioVlog.prototype, 'onVideoDurationChange');
    const videoProgressFunc = jest.spyOn(NioVlog.prototype, 'onVideoProgress');
    const videoClickFunc = jest.spyOn(NioVlog.prototype, 'onVideoClick');
    const loadedDataFunc = jest.spyOn(NioVlog.prototype, 'onVideoAllBuffered');
    const wrapper = mount(
        <NioVlog src={vlogSrc} poster={posterSrc} onlyShowPoster={false} />,
        { attachTo: document.body },
    );
    const video = wrapper.find('video').at(0);
    it('should call togglePlay method when click play button', () => {
        const button = wrapper
            .find('.icon-play')
            .at(0);
        button.simulate('click');
        expect(palyFake).toHaveBeenCalled();
        expect(videoPlayStatusChangeFunc).toHaveBeenCalled();
        button.simulate('click');
        expect(pauseFake).toHaveBeenCalled();
    });

    it('video on click & error', () => {
        Toast.show.mockImplementation(value => value);
        video.simulate('error');
        expect(Toast.show).toHaveBeenLastCalledWith('当前网络环境差，请检查网络连接！');
        video.simulate('click');
        expect(videoClickFunc).toHaveBeenCalled();
    });

    it('event trigger', () => {
        video.simulate('durationChange');
        expect(videoDurationChangeFunc).toHaveBeenCalled();
        video.simulate('progress');
        expect(videoProgressFunc).toHaveBeenCalled();
        video.simulate('loadedData');
        expect(loadedDataFunc).toHaveBeenCalled();
    });
    it('should call toggleFullScreen method when click maximum button', () => {
        const eventFunc = jest.spyOn(NioVlog.prototype, 'toggleFullScreen');
        const button = wrapper
            .find('.icon-maximum')
            .at(0);
        button.simulate('click');
        setTimeout(() => expect(eventFunc).toHaveBeenCalled());
    });
});

describe('NioVlog Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<NioVlog />);
        expect(wrapper.prop('src')).toBe('');
        expect(wrapper.prop('duration')).toBe(0);
        expect(wrapper.prop('poster')).toBe('');
        expect(wrapper.prop('onlyShowPoster')).toBe(false);
        expect(wrapper.prop('showDuration')).toBe(true);
    });
});
