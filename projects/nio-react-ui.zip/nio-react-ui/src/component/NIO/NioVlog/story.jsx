import React from 'react';
import registerStory from '~storybook/index';

import NioVlog from './index';

const vlogSrc = 'http://1400292488.vod2.myqcloud.com/d4534610vodtranscq1400292488/8cdeeea25285890804242383150/v.f30.mp4';
const posterSrc = 'https://cdn-app.nio.com/ugc/2020/6/17/29761a85-5890-4f85-a571-322575cefeb2.jpeg';

const wrapperStyle = {
    wrapperStyle: {
        width: 640,
    },
};

const {
    stories,
    knobs,
} = registerStory('NioVlog', wrapperStyle);

const {
    boolean,
    text,
    object,
    number,
    select,
} = knobs;

stories
    .addParameters({
        info: {
            text: `
              ## Notes
              - 该组件为Nio定制Vlog插件
              - onlyShowPoster为true仅仅只展示海报时，视频不可播放，通过poster配置海报封面地址，duration配置视频时长展示值，showDuration控制是否需要展示视频时长
              - onlyShowPoster为false，视频可以点击播放，需配置视频地址src及展示封面地址poster
            `,
        },
    })
    .add('base usage [poster]', () => {
        const preloadOptions = {
            none: 'none',
            metadata: 'metadata',
            auto: 'auto',
        };
        const duration = number('duration', 15);
        const poster = text('poster', posterSrc);
        const onlyShowPoster = select('onlyShowPoster', { true: true }, true);
        const showDuration = boolean('showDuration', true);
        const preload = select('preload', preloadOptions, 'normal');
        const style = object('style', {
            width: '500px',
            height: '500px',
        });
        return (
            <NioVlog
                duration={duration}
                poster={poster}
                onlyShowPoster={onlyShowPoster}
                showDuration={showDuration}
                style={style}
                preload={preload}
            />
        );
    }).add('base usage [video]', () => {
        const src = text('src', vlogSrc);
        const poster = text('poster', posterSrc);
        const onlyShowPoster = select('onlyShowPoster', { false: false }, false);
        const showDuration = boolean('showDuration', true);
        const style = object('style', {
            width: '100%',
            height: '360px',
        });
        return (
            <NioVlog
                src={src}
                poster={poster}
                onlyShowPoster={onlyShowPoster}
                showDuration={showDuration}
                style={style}
            />
        );
    });
