import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import { isMobile } from '~utils/device-check';
import Image from '../../Image';
import Icon from '../../Icon';
import Toast from '../../Toast';
import Progress from '../../Progress';

import './index.scss';

const VIDEO_STATUS = ['loading', 'loaded', 'play', 'paused', 'error'];

export default class NioVlog extends PureComponent {
    constructor(props) {
        super(props);
        this.onCanplay = this.onCanplay.bind(this);
        this.togglePlay = this.togglePlay.bind(this);
        this.toggleFullScreen = this.toggleFullScreen.bind(this);
        this.onVideoClick = this.onVideoClick.bind(this);
        this.onVideoPlayStatusChange = this.onVideoPlayStatusChange.bind(this);
        this.onVideoDurationChange = this.onVideoDurationChange.bind(this);
        this.onVideoProgress = this.onVideoProgress.bind(this);
        this.onVideoAllBuffered = this.onVideoAllBuffered.bind(this);
        this.onVideoError = this.onVideoError.bind(this);

        this.timer = 0;
        this.isMobile = isMobile(window.navigator.userAgent);

        this.state = {
            showPoster: true,
            videoStatus: VIDEO_STATUS[1], // 由于各客户端对preload loading支持不一致，所以从loaded开始
            duration: 0, // 时长
            bufferedDuration: 0, // 缓冲时长
            currentTime: 0, // 当前已播放时长
        };
    }

    // load 到可以播放
    onCanplay() {
        if (this.state.videoStatus !== VIDEO_STATUS[2]) {
            this.setState({
                videoStatus: VIDEO_STATUS[1],
            });
        }
    }

    onVideoClick() {
        if (this.video && !this.video.paused) {
            this.pause();
        }
    }

    onVideoPlayStatusChange() {
        clearTimeout(this.timer);
        if (this.video.paused) {
            const newState = {
                videoStatus: VIDEO_STATUS[3],
            };
            if (this.video.ended) {
                newState.currentTime = this.video.duration;
            }
            this.setState(newState);
        } else {
            this.setState({
                videoStatus: VIDEO_STATUS[2],
            });
            this.timer = setTimeout(() => this.changeCurrentTime(), 300);
        }
    }

    onVideoDurationChange() {
        this.setState({
            duration: this.video.duration,
        });
    }

    onVideoProgress() {
        if (this.video.buffered) {
            this.setState({
                bufferedDuration: this.video.buffered.end(0),
            });
        }
    }

    // 全部缓存结束
    onVideoAllBuffered() {
        this.setState({
            bufferedDuration: this.video.duration,
        });
    }

    // 全部缓存结束
    onVideoError() {
        if (this.video.error && this.video.error.code !== 2) {
            Toast.show('视频已下线！');
            this.setState({
                videoStatus: VIDEO_STATUS[4],
            });
        } else {
            Toast.show('当前网络环境差，请检查网络连接！');
        }
    }

    changeCurrentTime() {
        clearTimeout(this.timer);
        this.setState({
            currentTime: this.video.currentTime,
        });
        this.timer = setTimeout(() => this.changeCurrentTime(), 300);
    }

    /* eslint class-methods-use-this: ["error", { "exceptMethods": ["toggleFullScreen"] }] */
    /* eslint-disable no-alert */
    toggleFullScreen() {
        const elem = document.querySelector('video');
        if (!document.fullscreenElement) {
            elem.requestFullscreen().catch((err) => {
                alert(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
            });
        } else {
            document.exitFullscreen();
        }
    }

    // toggle play
    togglePlay() {
        if (this.video && this.video.paused) {
            this.play();
        } else {
            this.pause();
        }
    }

    // pause the video
    pause() {
        if (this.video) {
            const promise = this.video.pause();
            if (promise !== undefined) {
                promise.then(() => {}).catch(() => {});
            }
        }
    }

    // play the video
    play() {
        const promise = this.video.play();
        if (promise !== undefined) {
            promise.then(() => {
                this.state.showPoster && this.setState({
                    showPoster: false,
                });
            }).catch(() => {});
        }
    }

    render() {
        const {
            src,
            poster,
            onlyShowPoster,
            showDuration,
            preload,
        } = this.props;
        const {
            showPoster,
            videoStatus,
            bufferedDuration,
            currentTime,
        } = this.state;
        const iconPlayClassName = PureComponent.classNames('vlog-icon', {
            // 'icon-loading roll': !onlyShowPoster && videoStatus === VIDEO_STATUS[0], 各客户端不支持loading状态
            'icon-play': onlyShowPoster || videoStatus === VIDEO_STATUS[1] || videoStatus === VIDEO_STATUS[3],
            'icon-error': videoStatus === VIDEO_STATUS[4],
        });
        const duration = this.state.duration || this.props.duration;
        const playProgress = (currentTime / duration) * 100;
        const progressStyle = {
            width: `${(bufferedDuration / duration) * 100}%`,
        };
        return (
            <div className="nio-vlog">
                <div
                    className={this.className('nio-vlog__main')}
                    style={this.style()}
                >
                    { showPoster
                        && (
                            <React.Fragment>
                                { onlyShowPoster
                                && (
                                    <img
                                        className="nio-vlog__img-bg nio-invisible nio-internal"
                                        src={poster}
                                        alt=""
                                    />
                                )
                                }
                                <Image
                                    className="nio-vlog__poster"
                                    imageClassName={`${!onlyShowPoster ? '' : 'contain'} nio-invisible nio-internal`}
                                    src={poster}
                                />
                            </React.Fragment>
                        )
                    }
                    <Icon
                        canClickInShare={!onlyShowPoster}
                        className={iconPlayClassName}
                        onClick={this.togglePlay}
                    />
                    { !onlyShowPoster
                        && (
                            <React.Fragment>
                                { !this.isMobile && (
                                    <Icon
                                        canClickInShare
                                        className="vlog-icon icon-maximum"
                                        onClick={this.toggleFullScreen}
                                    />
                                ) }
                                <video
                                    ref={(node) => {
                                        this.video = node;
                                    }}
                                    //                                webkit-playsinline='true'
                                    //                                playsinline='true'
                                    x5-video-player-type="h5" /* 让video开启同层H5播放器 */
                                    preload={preload}
                                    className="nio-vlog__video"
                                    loop
                                    src={src}
                                    onClick={this.onVideoClick}
                                    //                                onCanPlay={this.onCanplay}
                                    onPause={this.onVideoPlayStatusChange}
                                    onPlay={this.onVideoPlayStatusChange}
                                    onError={this.onVideoError}
                                    onDurationChange={this.onVideoDurationChange}
                                    onProgress={this.onVideoProgress}
                                    onLoadedData={this.onVideoAllBuffered}
                                />
                            </React.Fragment>
                        )
                    }
                    { onlyShowPoster && showDuration
                        && (
                            <p className="nio-vlog__duration">
                                {`00:${`${Math.floor(duration)}`.padStart(2, '0')}`}
                            </p>
                        )
                    }
                </div>
                { !onlyShowPoster
                    && (
                        <Progress
                            className="nio-vlog__progress"
                            value={playProgress}
                            style={progressStyle}
                            valueBarCls="nio-vlog__progress-value"
                        />
                    )
                }
            </div>
        );
    }
}

NioVlog.propTypes = {
    /** vlog地址 */
    src: PropTypes.string,
    /** 时长 */
    duration: PropTypes.number,
    /** 视频海报 */
    poster: PropTypes.string,
    /** 是否是仅仅展示海报，不可播放 */
    onlyShowPoster: PropTypes.bool,
    /** 是否展示时长 */
    showDuration: PropTypes.bool,
    preload: PropTypes.oneOf(['none', 'metadata', 'auto', '']),
};

NioVlog.defaultProps = {
    src: '',
    duration: 0,
    poster: '',
    onlyShowPoster: false,
    showDuration: true,
    preload: 'auto',
};
