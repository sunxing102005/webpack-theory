import React from 'react';
import BlockContainer from './index';

describe('BlockContainer', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <BlockContainer
                className="test-wrap-class"
                titleClass="test-title-class"
                hasUnderline={false}
                horizontalMargin
                verticalMargin
                title="Test BlockContainer"
            >
                <p>this is content</p>
            </BlockContainer>,
        );
        const wrapperWithoutMargin = render(
            <BlockContainer
                className="test-wrap-class"
                titleClass="test-title-class"
                hasUnderline
                horizontalMargin={false}
                verticalMargin={false}
                title="Test BlockContainer"
            >
                <p>this is content</p>
            </BlockContainer>,
        );
        expect(wrapper).toMatchSnapshot();
        expect(wrapperWithoutMargin).toMatchSnapshot();
    });
});

describe('BlockContainer Event Test', () => {
    it('should call clickTitle method', () => {
        const onClick = jest.fn();
        const wrapper = mount(<BlockContainer clickTitle={onClick} showJumpIcon />);
        wrapper
            .find('header')
            .at(0)
            .props()
            .onClick();
        expect(onClick).toHaveBeenCalled();
    });
});
describe('BlockContainer  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<BlockContainer />);
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('titleClass')).toBe('');
        expect(wrapper.prop('title')).toBe('');
        expect(wrapper.prop('hasUnderline')).toBe(true);
        expect(wrapper.prop('children')).toBeNull();
        expect(wrapper.prop('clickTitle')).toBeNull();
        expect(wrapper.prop('showJumpIcon')).toBe(false);
        expect(wrapper.prop('horizontalMargin')).toBe(false);
        expect(wrapper.prop('verticalMargin')).toBe(false);
    });
});
