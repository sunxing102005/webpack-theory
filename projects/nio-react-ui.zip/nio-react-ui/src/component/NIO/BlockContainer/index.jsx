import React from 'react';
import './index.scss';
import PropTypes from 'prop-types';
import classnames from 'classnames';
/**
 * 动态频道每个业务块外层通用组件，含有标题，下边线等
 */
function BlockContainer(props) {
    const {
        children,
        className,
        titleClass,
        title,
        clickTitle,
        showJumpIcon,
        hasUnderline,
        horizontalMargin,
        verticalMargin,
    } = props;
    const wrapperClassName = classnames([
        'nio-block',
        className,
        { 'nio-block--no-underline': !hasUnderline },
        { 'nio-block--horizontal-margin': horizontalMargin },
        { 'nio-block--bottom-margin': verticalMargin },
    ]);
    return (
        <section className={wrapperClassName}>
            <header onClick={clickTitle}>
                {title ? (
                    <h2 className={`nio-block__title ${titleClass}`}>
                        {title}
                        {showJumpIcon ? (
                            <div className="nio-block__title__icon icon-back" />
                        ) : null}
                    </h2>
                ) : null}
            </header>
            {children}
        </section>
    );
}
BlockContainer.propTypes = {
    /** 自定义block外层样式 */
    className: PropTypes.string,
    /** 自定义标题外层样式 */
    titleClass: PropTypes.string,
    /** 标题text */
    title: PropTypes.string,
    /** 是否有下分割线 */
    hasUnderline: PropTypes.bool,
    /** 标题点击方法 */
    clickTitle: PropTypes.func,
    /** 包含children */
    children: PropTypes.node,
    /** 是否有水平margin(25px) */
    horizontalMargin: PropTypes.bool,
    /** 是否有垂直margin-bottom(30px) */
    verticalMargin: PropTypes.bool,
    /** 是否显示跳转箭头 */
    showJumpIcon: PropTypes.bool,
};
BlockContainer.defaultProps = {
    className: '',
    titleClass: '',
    title: '',
    hasUnderline: true,
    clickTitle: null,
    children: null,
    horizontalMargin: false,
    verticalMargin: false,
    showJumpIcon: false,
};
export default BlockContainer;
