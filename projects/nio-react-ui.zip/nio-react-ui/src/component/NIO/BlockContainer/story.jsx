import React from 'react';
import registerStory from '~storybook/index';
import BlockContainer from './index';
import './story.scss';

const style = {
    wrapperStyle: {
        width: 500,
        height: 200,
    },
};
// register story
const { stories, knobs } = registerStory('BlockContainer', style);

const { text, boolean } = knobs;
stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为container类型组件，带有标题与底部下划线
          - 该组件提供title,children等属性设置标题与内容
        `,
        },
    })
    .add('base usage', () => {
        const title = text('title', 'Title');
        const hasUnderline = boolean('hasUnderline', true);
        const horizontalMargin = boolean('horizontalMargin', false);
        const verticalMargin = boolean('verticalMargin', false);
        const showJumpIcon = boolean('showJumpIcon', false);
        const clickTitle = (e) => {
            console.log('click title', e);
        };
        return (
            <BlockContainer
                className="story-container"
                title={title}
                hasUnderline={hasUnderline}
                horizontalMargin={horizontalMargin}
                verticalMargin={verticalMargin}
                clickTitle={clickTitle}
                showJumpIcon={showJumpIcon}
            >
            content
            </BlockContainer>
        );
    });
