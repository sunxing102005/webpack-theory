import React from 'react';
import Swiper from 'swiper';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import './index.scss';
/**
 * 内部元素可滑动组件
 */
class SwiperComponent extends PureComponent {
    componentDidMount() {
        const {
            slidesPerView,
            spaceBetween,
            slidesOffsetBefore,
            slidesOffsetAfter,
            className,
            disabled,
            onInit,
            initialSlide,
        } = this.props;
        if (disabled) return;
        const wraperClassName = className.split(' ')[0] || 'nio-swiper-view';
        const mySwiper = new Swiper(`.${wraperClassName}`, {
            slidesPerView,
            spaceBetween,
            slidesOffsetBefore,
            slidesOffsetAfter,
            initialSlide,
        });
        if (Array.isArray(mySwiper)) {
            mySwiper.forEach((swiperItem) => {
                this.bindSwiperListener(swiperItem);
            });
        } else {
            this.bindSwiperListener(mySwiper);
        }
        onInit && onInit(mySwiper);
    }

    bindSwiperListener=(mySwiper) => {
        const {
            onSlideChangeStart,
            onSlideChangeEnd,
            onTouchEnd,
        } = this.props;
        onSlideChangeStart && mySwiper.on && mySwiper.on('slideChangeStart', () => { onSlideChangeStart(mySwiper); });
        onSlideChangeEnd && mySwiper.on && mySwiper.on('slideChangeEnd', () => { onSlideChangeEnd(mySwiper); });
        onTouchEnd && mySwiper.on && mySwiper.on('touchEnd', () => { onTouchEnd(mySwiper); });
    }

    render() {
        const { children, forwardedRef, onClick } = this.props;
        const containerClassName = this.className('nio-swiper-view');
        return (
            <div className={containerClassName} ref={forwardedRef} onClick={onClick}>
                <div className="swiper-wrapper">{children}</div>
            </div>
        );
    }
}
SwiperComponent.propTypes = {
    /** 每个视图的幻灯片数量，auto时根据元素自身长度确定 */
    slidesPerView: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    /** 每个幻灯片间距 */
    spaceBetween: PropTypes.number,
    /** 在容器开头添加其他幻灯片偏移 */
    slidesOffsetBefore: PropTypes.number,
    /** 在容器的末尾添加（以像素为单位）附加的幻灯片偏移量 */
    slidesOffsetAfter: PropTypes.number,
    /** swiper容器内内容 */
    children: PropTypes.node,
    /** swiper容器样式 */
    className: PropTypes.string,
    /** 是否禁止滑动 */
    disabled: PropTypes.bool,
    /** 初始化后回调函数 */
    onInit: PropTypes.func,
    /** 滑动开始事件 */
    onSlideChangeStart: PropTypes.func,
    /** 滑动结束事件 */
    onSlideChangeEnd: PropTypes.func,
    /** 根dom ref */
    forwardedRef: PropTypes.object,
    /** touchend事件 */
    onTouchEnd: PropTypes.func,
    onClick: PropTypes.func,
    initialSlide: PropTypes.number,
};
SwiperComponent.defaultProps = {
    slidesPerView: 'auto',
    spaceBetween: 10,
    slidesOffsetBefore: 25,
    slidesOffsetAfter: 25,
    children: null,
    className: '',
    disabled: false,
    onInit: null,
    onSlideChangeStart: null,
    onSlideChangeEnd: null,
    forwardedRef: null,
    onTouchEnd: null,
    onClick: null,
    initialSlide: 0,
};
export default SwiperComponent;
