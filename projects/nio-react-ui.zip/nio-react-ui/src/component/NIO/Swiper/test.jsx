import React from 'react';
import Swiper from './index';

describe('Swiper', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <Swiper
                className="test-wrap-class"
                spaceBetween={20}
                slidesOffsetBefore={30}
                slidesOffsetAfter={30}
            >
                <div>this is swiper item</div>
                <div>this is swiper item</div>
                <div>this is swiper item</div>
                <div>this is swiper item</div>
            </Swiper>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

describe('Swiper Event Test', () => {
    it('should call method', () => {
        const onInit = jest.fn();
        const onClick = jest.fn();
        const wrapper = mount(
            <Swiper
                onInit={onInit}
                onClick={onClick}
            >
                <div style={{ width: '300px' }}>this is swiper item</div>
                <div style={{ width: '300px' }}>this is swiper item</div>
                <div style={{ width: '300px' }}>this is swiper item</div>
            </Swiper>,
        );
        expect(onInit).toHaveBeenCalled();
        const swiperDom = wrapper.find('.nio-swiper-view').at(0);
        swiperDom.simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
});
describe('Swiper Disable Test', () => {
    it('should call be disabled', () => {
        const onInit = jest.fn();
        mount(
            <Swiper
                disabled
                onInit={onInit}
            >
                <div style={{ width: '300px' }}>this is swiper item</div>
                <div style={{ width: '300px' }}>this is swiper item</div>
                <div style={{ width: '300px' }}>this is swiper item</div>
            </Swiper>,
        );
        expect(onInit).toHaveBeenCalledTimes(0);
    });
});
describe('Swiper  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<Swiper />);
        expect(wrapper.prop('slidesPerView')).toBe('auto');
        expect(wrapper.prop('spaceBetween')).toBe(10);
        expect(wrapper.prop('slidesOffsetBefore')).toBe(25);
        expect(wrapper.prop('slidesOffsetAfter')).toBe(25);
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('children')).toBeNull();
    });
});
