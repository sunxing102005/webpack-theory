import React from 'react';
import registerStory from '~storybook/index';
import Swiper from './index';
import './index.scss';

const style = {
    wrapperStyle: {
        width: 500,
        height: 200,
        border: '1px solid black',
    },
};
// register story
const { stories } = registerStory('Swiper', style);

const onSlideChangeStart = () => {
    console.log('onSlideChangeStart');
};
const onSlideChangeEnd = () => {
    console.log('onSlideChangeEnd');
};
const onInit = () => {
    console.log('onInit');
};
const onTouchEnd = () => {
    console.log('onTouchEnd');
};
const onClick = () => {
    console.log('onClick swiper container');
};
const itemStyle = {
    width: '250px',
    height: '200px',
    backgroundSize: 'cover',
    backgroundImage: 'url(https://cdn-app.nio.com/user/2019/10/18/970f1295-0bb9-4b3a-a8c6-5db01f395b0f.jpg?imageView2/2/w/1024)',
};
stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为内部子组件提供滑动效果
          - 该组件提供属性定义滑块间距等属性
          - ** 注意：** 除了children,className外其他props只在初始化设置时有效
          - ** 注意：** 当className传多个class时，如果页面存在多个swiper，
          需要保证第一个className名字不重复。
        `,
        },
    })
    .add('base usage', () => (
        <Swiper
            spaceBetween={10}
            slidesOffsetBefore={25}
            slidesOffsetAfter={25}
            onSlideChangeStart={onSlideChangeStart}
            onSlideChangeEnd={onSlideChangeEnd}
            onInit={onInit}
            onTouchEnd={onTouchEnd}
            onClick={onClick}
        >
            <div style={itemStyle} className="swiper-slide" />
            <div style={itemStyle} className="swiper-slide" />
            <div style={itemStyle} className="swiper-slide" />
        </Swiper>
    ));
