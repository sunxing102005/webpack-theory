import React from 'react';
import SwiperTab from './index';

const tabTitleArr = ['title1', 'title2', 'title3'];
const children = [
    <div key="0">this is swiper item</div>,
    <div key="1">this is swiper item</div>,
    <div key="2">this is swiper item</div>,
];
describe('SwiperTab', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <SwiperTab
                tabTitleClassName="test-swiper-tab-class"
                titleSpaceBetween={20}
                titleSlidesOffsetBefore={30}
                titleSlidesOffsetAfter={30}
                tabTitleArr={tabTitleArr}
            >
                {children}
            </SwiperTab>,
        );
        const wrapperDisabled = render(
            <div className="test-container">
                <SwiperTab
                    tabTitleClassName="test-swiper-tab-class"
                    disableSwiper
                    tabTitleArr={tabTitleArr}
                    needFixTitles={false}
                    containerSelector=".test-container"
                >
                    {children}
                </SwiperTab>
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
        expect(wrapperDisabled).toMatchSnapshot();
    });
});
describe('SwiperTab Event Test', () => {
    it('should call method', () => {
        const tabChangeStart = jest.fn();
        const onInit = jest.fn();
        const wrapper = mount(
            <SwiperTab
                tabTitleArr={tabTitleArr}
                tabChangeStart={tabChangeStart}
                onInit={onInit}
            >
                {children}
            </SwiperTab>,
        );
        wrapper.find('.nio-swiper-tab-titles__title').at(1)
            .simulate('click');
        expect(tabChangeStart).toHaveBeenCalled();
        expect(wrapper.state('activeIndex')).toEqual(1);
        wrapper.unmount();
    });
});
describe('SwiperTab  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<SwiperTab />);
        expect(wrapper.prop('tabTitleArr')).toEqual([]);
        expect(wrapper.prop('children')).toEqual([]);
        expect(wrapper.prop('needFixTitles')).toBe(true);
        expect(wrapper.prop('titleSlidesOffsetBefore')).toBe(20);
        expect(wrapper.prop('titleSlidesOffsetAfter')).toBe(20);
        expect(wrapper.prop('titleSlidesPerView')).toBe('auto');
        expect(wrapper.prop('titleSpaceBetween')).toBe(20);
        expect(wrapper.prop('tabTitleClassName')).toBe('');
        expect(wrapper.prop('tabChangeStart')).toBeNull();
        expect(wrapper.prop('onInit')).toBeNull();
        expect(wrapper.prop('disableSwiper')).toBe(false);
    });
});
