import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Swiper from '../Swiper';
import './index.scss';

class SwiperTab extends React.PureComponent {
    constructor(props) {
        super(props);
        this.titlesWrapperRef = React.createRef();
        this.state = {
            activeIndex: 0,
            clicked: false,
        };
        this.contentSwiperIns = null;
        this.tabSwiperIns = null;
    }

    setSwiperInst = ({ swiper, key }) => {
        this[key] = swiper;
    };

    tabChangeStart = ({ activeIndex }) => {
        const { activeIndex: index, clicked: click } = this.state;
        this.tabSwiperIns && this.tabSwiperIns.slideTo(activeIndex - 1);
        this.setState({ activeIndex, clicked: false });
        const { tabChangeStart } = this.props;
        if (!click) {
            tabChangeStart && tabChangeStart({ activeIndex, originIndex: index, click });
        }
    };

    /**
     * @param activeIndex
     * @param clicked 是否通过点击触发
     */
    clickTab = (activeIndex, clicked = true) => {
        const { tabChangeStart } = this.props;
        const { activeIndex: index } = this.state;
        if (index !== activeIndex) {
            this.setState({
                activeIndex,
                clicked,
            },
            () => {
                this.contentSwiperIns && this.contentSwiperIns.slideTo && this.contentSwiperIns.slideTo(activeIndex);
                tabChangeStart && tabChangeStart({ activeIndex, originIndex: index, click: clicked });
            });
        }
    };

    onInitSwiperContent = (swiper) => {
        this.setSwiperInst({ swiper, key: 'contentSwiperIns' });
        const { onInit } = this.props;
        onInit && onInit({ activeIndex: 0 });
    };

    /**
     * 保证swiper中单个元素滑动，不出现样式左右偏移
     */
    onTouchEnd=() => {
        setTimeout(() => {
            const { activeIndex: newIndex } = this.state;
            this.contentSwiperIns && this.contentSwiperIns.slideTo(newIndex);
        });
    }

    onInitTitleSwiper = (swiper) => {
        this.setSwiperInst({ swiper, key: 'tabSwiperIns' });
    }

    render() {
        const { activeIndex } = this.state;
        const {
            tabTitleArr,
            children,
            tabTitleClassName,
            titleSlidesOffsetBefore: slidesOffsetBefore,
            titleSlidesPerView: slidesPerView,
            titleSpaceBetween: spaceBetween,
            titleSlidesOffsetAfter: slidesOffsetAfter,
            tabChangedCb,
            disableSwiper,
            needFixTitles,
        } = this.props;
        const titleClassNames = classnames([
            'nio-swiper-tab-titles',
            { 'fixed-tab': needFixTitles },
        ]);
        return (
            <React.Fragment>
                <Swiper
                    className={titleClassNames}
                    forwardedRef={this.titlesWrapperRef}
                    slidesOffsetBefore={slidesOffsetBefore}
                    slidesOffsetAfter={slidesOffsetAfter}
                    slidesPerView={slidesPerView}
                    spaceBetween={spaceBetween}
                    disabled={disableSwiper}
                    onInit={this.onInitTitleSwiper}
                >
                    {tabTitleArr.map((item, index) => (
                        <div
                            className={`nio-swiper-tab-titles__title  swiper-slide  ${tabTitleClassName} ${
                                index === activeIndex
                                    ? 'actived-underline'
                                    : ''
                            }`}
                            onClick={() => this.clickTab(index)}
                            key={index}
                        >
                            {item}
                        </div>
                    ))}
                </Swiper>
                <Swiper
                    className="nio-swiper-tab-content"
                    slidesOffsetBefore={0}
                    onSlideChangeStart={this.tabChangeStart}
                    onInit={this.onInitSwiperContent}
                    onTouchEnd={this.onTouchEnd}
                    onSlideChangeEnd={tabChangedCb}
                    disabled={disableSwiper}
                >
                    {children
                        && children.map((item, index) => (
                            <div
                                className="swiper-slide nio-swiper-tab-content__item"
                                key={index}
                            >
                                {item}
                            </div>
                        ))}
                </Swiper>
            </React.Fragment>
        );
    }
}
SwiperTab.propTypes = {
    /** tab的标题 */
    tabTitleArr: PropTypes.arrayOf(PropTypes.string),
    /** 数组形式传入组件滑块内容元素 */
    children: PropTypes.arrayOf(PropTypes.node),
    /** 是否需要滚动到顶部时，固定标题 */
    needFixTitles: PropTypes.bool,
    /** 在标题容器开头添加其他幻灯片偏移 */
    titleSlidesOffsetBefore: PropTypes.number,
    /** 在标题容器的末尾添加（以像素为单位）附加的幻灯片偏移量 */
    titleSlidesOffsetAfter: PropTypes.number,
    /** 每个标题视图的幻灯片数量，auto时根据元素自身长度确定 */
    titleSlidesPerView: PropTypes.string,
    /** 每个标题幻灯片间距 */
    titleSpaceBetween: PropTypes.number,
    /** 标题classname */
    tabTitleClassName: PropTypes.string,
    /** 标签内容开始切换 */
    tabChangeStart: PropTypes.func,
    /** 初始化阶段函数 */
    onInit: PropTypes.func,
    /** 标签内容结束切换 */
    tabChangedCb: PropTypes.func,
    /** 初始化时设置是否允许滑动 */
    disableSwiper: PropTypes.bool,
};
SwiperTab.defaultProps = {
    tabTitleArr: [],
    children: [],
    needFixTitles: true,
    titleSlidesOffsetBefore: 20,
    titleSlidesOffsetAfter: 20,
    titleSlidesPerView: 'auto',
    titleSpaceBetween: 20,
    tabTitleClassName: '',
    tabChangeStart: null,
    onInit: null,
    tabChangedCb: null,
    disableSwiper: false,
};
export default SwiperTab;
