import React from 'react';
import registerStory from '~storybook/index';
import SwiperTab from './index';
import './story.scss';

const style = {
    wrapperStyle: {
        width: 370,
        height: 500,
        position: 'relative',
    },
};
// register story
const { stories, knobs } = registerStory('SwiperTab', style);

const { boolean, object } = knobs;
const tabChangeStart = () => {
    console.log('tabChangeStart');
};
const onInit = () => {
    console.log('onInit');
};
const tabChangedCb = () => {
    console.log('tabChangedCb');
};
const itemStyle = {
    width: '100%',
    height: '400px',
    backgroundSize: 'cover',
    backgroundImage: 'url(https://cdn-app.nio.com/user/2019/10/18/970f1295-0bb9-4b3a-a8c6-5db01f395b0f.jpg?imageView2/2/w/1024)',
};
const tabTitleArr = ['标题1', '标题2', '标题3', '标题4'];
stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为内部可滑动的标签页组件
          - 该组件提供属性定义滑块间距等属性
          - **注意：** 除tabTitleArr,children,needFixTitles之外属性，
            都只能初始化时设置，之后更新无效。
          - **注意：** 不设置needFixTitles，或设置为true时，组件标题滚动到顶时，会粘到外层滚动区域顶部。
        `,
        },
    })
    .add('base usage', () => (
        <SwiperTab tabTitleArr={tabTitleArr}>
            <div style={itemStyle} />
            <div style={itemStyle} />
            <div style={itemStyle} />
            <div style={itemStyle} />
        </SwiperTab>
    ))
    .add('custom style', () => {
        const needFixTitles = boolean('needFixTitles', true);
        const tabTitleArrProp = object('tabTitleArr', tabTitleArr);
        return (
            <div className="swiper-tab-container">
                <div className="swiper-tab-title">外部区域</div>
                <SwiperTab
                    tabChangeStart={tabChangeStart}
                    onInit={onInit}
                    tabChangedCb={tabChangedCb}
                    containerSelector=".swiper-tab-container"
                    tabTitleArr={tabTitleArrProp}
                    needFixTitles={needFixTitles}
                >
                    <div style={itemStyle} />
                    <div style={itemStyle} />
                    <div style={itemStyle} />
                    <div style={itemStyle} />
                </SwiperTab>
            </div>
        );
    });
