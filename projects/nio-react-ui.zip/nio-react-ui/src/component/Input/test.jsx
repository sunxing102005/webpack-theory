import React from 'react';
import Input from './index';

beforeAll(() => {
    const div = document.createElement('div');
    div.setAttribute('id', 'container');
    document.body.appendChild(div);
});

afterAll(() => {
    const div = document.getElementById('container');
    if (div) {
        document.body.removeChild(div);
    }
});

describe('Input', () => {
    it('should render correctly', () => {
        const wrapper = render(<Input value="我是test" />);
        expect(wrapper).toMatchSnapshot();
        /* eslint-disable react/jsx-boolean-value */
        const wrapperAuto = render(<Input value="我是test" autosize={true} />);
        expect(wrapperAuto).toMatchSnapshot();
    });

    it('should support basic usage', () => {
        const onChange = jest.fn();
        const wrapper = mount(
            <Input
                value="我是test"
                onChange={onChange}
            />,
        );
        wrapper.find('input').props().onChange();
        expect(onChange).toHaveBeenCalled();
    });
});


describe('Input Unit Test', () => {
    const onChangeMock = jest.fn();
    const onBlurMock = jest.fn();
    const onFocusMock = jest.fn();
    const wrapper = mount(
        <Input
            value="我是test"
            onChange={onChangeMock}
            onBlur={onBlurMock}
            onFocus={onFocusMock}
        />,
    );
    /* eslint-disable react/jsx-boolean-value */
    const wrapperAuto = mount(
        <Input
            value="我是test"
            autosize={true}
            onChange={onChangeMock}
        />, { attachTo: document.body },
    );
    it('event handlers', () => {
        const input = wrapper.find('input').at(0);
        input.simulate('focus');
        expect(onFocusMock).toHaveBeenCalledTimes(1);
        wrapper.setProps({ readOnly: true });
        input.simulate('focus');
        expect(onFocusMock).toHaveBeenCalledTimes(1);
        expect(onBlurMock).toHaveBeenCalledTimes(1);
    });

    it('render autosize input', () => {
        const text = wrapperAuto.find('textarea').at(0);
        expect(wrapperAuto.find('textarea').length).toEqual(1);
        text.simulate('focus');
        expect(onFocusMock).toHaveBeenCalledTimes(1);
        wrapperAuto.setProps({ readOnly: true });
        text.simulate('focus');
        expect(onFocusMock).toHaveBeenCalledTimes(1);
        expect(onBlurMock).toHaveBeenCalledTimes(1);
        text.simulate('change');
        expect(onChangeMock).toHaveBeenCalled();
    });
});
