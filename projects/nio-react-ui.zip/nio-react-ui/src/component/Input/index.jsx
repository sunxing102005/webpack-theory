import React from 'react';
import PropTypes from 'prop-types';
import { deviceCheck } from '~utils';
import { Component } from '~lib';

import './index.scss';

export default class Input extends Component {
    constructor(props) {
        super(props);
        this.input = null;
        this.saveInput = this.saveInput.bind(this);
        this.blur = this.blur.bind(this);
        this.focus = this.focus.bind(this);
        this.changeHandler = this.changeHandler.bind(this);
    }

    componentDidMount() {
        const { autoFocus = false } = this.props;
        if (autoFocus) {
            this.focus();
        }
    }

    focus() {
        this.input.focus();
    }

    blur(e) {
        const { readOnly, onBlur } = this.props;
        if (!readOnly && deviceCheck.isWx() && deviceCheck.isIOS()) {
            setTimeout(() => {
                const scrollHeight = document.documentElement.scrollTop || document.body.scrollTop || 0;
                window.scrollTo(0, Math.max(scrollHeight - 1, 0));
            }, 100);
        }
        this.input.blur();
        if (onBlur) {
            onBlur(e);
        }
    }

    saveInput(node) {
        this.input = node;
    }

    changeHandler(e) {
        const { onChange, maxHeight, autosize } = this.props;
        /* eslint-disable no-unused-expressions */
        onChange && onChange(this.input.value, e);
        if (!autosize) return;
        const { scrollHeight, offsetHeight } = document.getElementById('nio-input__textarea');
        const pre = document.getElementsByClassName('nio-input__content')[0];
        if (maxHeight > scrollHeight && offsetHeight < scrollHeight) {
            pre.style.height = `${Math.min(scrollHeight, maxHeight)}px`;
        } else {
            pre.style.height = 'auto';
        }
    }

    render() {
        const {
            disabled,
            readOnly,
            onChange,
            autoFocus,
            autosize,
            maxHeight,
            value,
            /* eslint-disable react/prop-types */
            style,
            placeholder,
            ...rest
        } = this.props;

        const classString = this.className('nio-input', {
            'nio-input--autosize': autosize,
            'nio-input--disabled': disabled,
            'nio-input--readonly': readOnly,
        });

        const otherProps = {};

        if (readOnly) {
            otherProps.onFocus = this.blur;
        }
        return (
            autosize
                ? (
                    <div
                        className={classString}
                        style={style}
                    >
                        <pre style={{ maxHeight }} className="nio-input__content">{ value }</pre>
                        <textarea
                            id="nio-input__textarea"
                            placeholder={placeholder}
                            disabled={disabled}
                            readOnly={readOnly}
                            value={value}
                            {...rest}
                            {...otherProps}
                            onChange={this.changeHandler}
                            onBlur={this.blur}
                            ref={this.saveInput}
                        />
                    </div>
                )
                : (
                    <input
                        placeholder={placeholder}
                        disabled={disabled}
                        readOnly={readOnly}
                        value={value}
                        style={style}
                        {...rest}
                        {...otherProps}
                        onBlur={this.blur}
                        onChange={this.changeHandler}
                        className={classString}
                        ref={this.saveInput}
                    />
                )
        );
    }
}

Input.propTypes = {
    /** input placeholder配置 */
    placeholder: PropTypes.string,
    /** input 初始value */
    value: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number,
    ]),
    /** input 初始化后自动聚焦 */
    autoFocus: PropTypes.bool,
    /** input 自增高 */
    autosize: PropTypes.bool,
    /** input 自增高时最大高度 */
    maxHeight: PropTypes.number,
    /** input 是否可操作 */
    disabled: PropTypes.bool,
    /** input 是否只读 */
    readOnly: PropTypes.bool,
    /** input change回调 */
    onChange: PropTypes.func,
    /** input 失焦回调 */
    onBlur: PropTypes.func,
};

Input.defaultProps = {
    disabled: false,
    readOnly: false,
    autoFocus: false,
    autosize: false,
    maxHeight: 100,
    placeholder: '',
    value: '',
    onChange: null,
    onBlur: null,
};
