import React from 'react';
import registerStory from '~storybook/index';
import Input from './index';

const style = {
    wrapperStyle: {
        height: 100,
    },
};
// register story
const {
    stories,
    state,
    knobs,
} = registerStory('Input', style);

const {
    text,
    boolean,
    number,
    object,
} = knobs;

const {
    State,
    Store,
} = state;

const inputStore = new Store({
    value: '我是test',
});

const changeHandler = (v, e) => {
    console.log('input change', e, 'value:', v);
    inputStore.set({
        value: v,
    });
};

const blurHandler = () => {
    console.log('input 失焦啦啦啦啦～');
};

const focusHandler = () => {
    console.log('input 聚焦啦啦啦啦～');
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为Input输入组件
          - ** 注意 **在props : ** disabled **为true时，input无法聚焦无法操作
          - ** 注意 **在props : ** readOnly **为true时，input无法聚焦点击即调用失焦方法
          - ** 注意 **在props : ** autosize **为true时，input自增高，通过props : ** maxHeight **设置最大高度
        `,
        },
    })
    .add('base usage', () => {
        const placeholder = text('placeholder', '请输入');
        const disable = boolean('disabled', false);
        const readOnly = boolean('readOnly', false);
        const needAutoFocus = boolean('autoFocus', true);
        const inputStyle = object('style', {
            width: 100,
        });
        return (
            <State store={inputStore}>
                <Input
                    placeholder={placeholder}
                    disabled={disable}
                    readOnly={readOnly}
                    style={inputStyle}
                    autoFocus={needAutoFocus}
                    onChange={changeHandler}
                    value={inputStore.get('value')}
                    onFocus={focusHandler}
                    onBlur={blurHandler}
                />
            </State>
        );
    }).add('custom usage', () => {
        const placeholder = text('placeholder', '请输入');
        const autosize = boolean('autosize', true);
        const disable = boolean('disabled', false);
        const readOnly = boolean('readOnly', false);
        const maxHeight = number('maxHeight', 200);
        const needAutoFocus = boolean('autoFocus', true);
        const inputStyle = object('style', {
            width: 300,
            fontSize: 16,
            paddingBottom: 6,
            borderBottomWidth: 1,
            borderBottomColor: '#CDCED4',
            borderBottomStyle: 'solid',
        });
        return (
            <State store={inputStore}>
                <Input
                    placeholder={placeholder}
                    maxHeight={maxHeight}
                    disabled={disable}
                    readOnly={readOnly}
                    autosize={autosize}
                    style={inputStyle}
                    autoFocus={needAutoFocus}
                    onChange={changeHandler}
                    value={inputStore.get('value')}
                />
            </State>
        );
    });
