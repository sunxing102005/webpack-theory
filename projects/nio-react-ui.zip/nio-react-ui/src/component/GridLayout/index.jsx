import React from 'react';
import './index.scss';
import PropTypes from 'prop-types';
/**
 * grid布局div
 * 子元素按照设置列数布局
 */
function GridLayout(props) {
    const {
        cols,
        className,
        children,
        gap,
    } = props;
    const colsPrec = 100 / cols;
    const gapEach = (gap * (cols - 1)) / cols;
    return (
        <div
            className={`nio-grid-layout ${className}`}
            style={{
                gridTemplateColumns: `repeat(${cols},calc(${colsPrec}% - ${gapEach}px ))`,
                gridGap: `${gap}px`,
            }}
        >
            {children}
        </div>
    );
}
GridLayout.propTypes = {
    /** 表格的列数 */
    cols: PropTypes.number,
    /** 表格的样式类名 */
    className: PropTypes.string,
    /** 子元素 */
    children: PropTypes.arrayOf(PropTypes.node),
    /** 子元素间距 */
    gap: PropTypes.number,
};
GridLayout.defaultProps = {
    cols: 2,
    className: '',
    children: null,
    gap: 10,
};
export default GridLayout;
