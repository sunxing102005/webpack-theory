import React from 'react';
import GridLayout from './index';

describe('GridLayout Snapshot', () => {
    const itemArr = ['section 1', 'section2', 'section3', 'section4'];
    it('render correctly', () => {
        const wrapper = mount(
            <GridLayout cols={3}>
                {itemArr.map((item, index) => (
                    <div className="section" key={index}>
                        {item}
                    </div>
                ))}
            </GridLayout>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});
describe('GridLayout Default Props', () => {
    const wrapper = mount(<GridLayout />);
    expect(wrapper.prop('cols')).toBe(2);
    expect(wrapper.prop('children')).toBeNull();
    expect(wrapper.prop('className')).toBe('');
    expect(wrapper.prop('gap')).toBe(10);
});
