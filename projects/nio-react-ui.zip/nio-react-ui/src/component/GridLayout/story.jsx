import React from 'react';
import registerStory from '~storybook/index';
import GridLayout from './index';

const style = {
    wrapperStyle: {
        height: 500,
        width: 500,
    },
};
const itemArr = ['section 1', 'section2', 'section3', 'section4'];
// register story
const { stories, knobs } = registerStory('GridLayout', style);

const { number } = knobs;

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为grid布局组件
          - 内部元素按照grid布局排列
          - 提供属性设置列数，间距
        `,
        },
    })
    .add('base usage', () => {
        const cols = number('cols', 3);
        const gap = number('gap', 10);
        return (
            <GridLayout cols={cols} gap={gap}>
                {itemArr.map(item => (
                    <div
                        className="story-grid-div"
                        key={item}
                        style={{
                            height: '100px',
                            backgroundImage:
                            'url(https://cdn-app.nio.com/user/2019/10/18/970f1295-0bb9-4b3a-a8c6-5db01f395b0f.jpg?imageView2/2/w/1024)',
                            backgroundSize: 'cover',
                        }}
                    />
                ))}
            </GridLayout>
        );
    });
