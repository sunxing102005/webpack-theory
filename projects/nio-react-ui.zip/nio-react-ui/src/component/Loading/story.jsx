import React from 'react';
import registerStory from '~storybook';
import Loading from './index';

// register story
const {
    stories,
    knobs,
} = registerStory('Loading');

const {
    text,
    object,
} = knobs;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件提供显示和隐藏loading方法
          - show 提供显示方法&destroy 提供隐藏组件
        `,
        },
    });


story.add('base usage', () => {
    const showText = text('text', 'loading');
    const style = object('style', {

    });

    const showLoading = () => {
        Loading.show({
            text: showText,
            style,
        });
        setTimeout(Loading.destroy, 2000);
    };

    return (
        <button
            type="button"
            onClick={() => showLoading()}
        >
点我测试
        </button>
    );
});
