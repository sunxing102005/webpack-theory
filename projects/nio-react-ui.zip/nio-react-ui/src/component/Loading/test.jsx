import React from 'react';
import Loading from './index';

describe('Loading', () => {
    it('should render correctly', () => {
        const wrapper = render(<Loading />);
        expect(wrapper).toMatchSnapshot();
    });

    it('should support basic usage', () => {
        const wrapper = mount(
            <Loading text="loading" />,
        );
        expect(wrapper.find('.loading__text').at(0).text()).toEqual('loading');
    });

    it('should show toast', () => {
        Loading.show();
        expect(Loading.hasLoading).toEqual(true);
        expect(document.getElementsByClassName('loading__cover').length).toEqual(1);
        Loading.destroy();
        Loading.hasLoading = true;
        Loading.show();
        expect(document.getElementsByClassName('loading__cover').length).toEqual(0);
        Loading.hasLoading = false;
    });

    it('should destory toast', () => {
        Loading.show();
        Loading.destroy();
        expect(Loading.hasLoading).toEqual(false);
        expect(document.getElementsByClassName('loading__cover').length).toEqual(0);
        Loading.hasLoading = false;
        Loading.destroy();
    });
});
