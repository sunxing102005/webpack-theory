import React from 'react';
import { render } from 'react-dom';
import PropTypes from 'prop-types';

import './index.scss';

function Loading(props) {
    const { text, style = {} } = props;

    return (
        <div className="loading__cover" style={style}>
            <div className="loading" />
            <span className="loading__text">{text}</span>
        </div>
    );
}

Loading.hasLoading = false;
Loading.container = null;

/**
 * @description 显示loading
 * @property{string} text,(optional) 提示内容
 * @property{object} style,(optional) 样式
 */
Loading.show = function showLoading(props = {}) {
    if (Loading.hasLoading) {
        return;
    }
    // loading最后都挂载在body div中
    const div = document.createElement('div');
    Loading.container = div;
    document.body.appendChild(div);
    Loading.hasLoading = true;
    render(<Loading {...props} />, div);
};

/**
 *@description 隐藏loading
 */
Loading.destroy = function destroyLoading() {
    if (!Loading.hasLoading) {
        return;
    }
    document.body.removeChild(Loading.container); // 移除挂载的容器
    Loading.hasLoading = false;
};

Loading.defaultProps = {
    /** Loading 提示内容 */
    text: '',
    /** Loading 样式 */
    style: {},
};

Loading.propTypes = {
    /** Loading 提示内容 */
    text: PropTypes.string,
    /** Loading 样式 */
    /* eslint-disable react/forbid-prop-types */
    style: PropTypes.object,
};

export default Loading;
