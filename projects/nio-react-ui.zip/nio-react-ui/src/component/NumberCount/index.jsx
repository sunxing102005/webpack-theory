import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
// style
import './index.scss';

class NumberCount extends PureComponent {
    constructor(props) {
        super(props);
        this.changeValue = this.changeValue.bind(this);
    }

    changeValue(e, type) {
        e.preventDefault();
        const {
            step,
            value,
            max,
            min,
            onChange,
        } = this.props;
        // disabled
        if ((value <= min && type === 'minus') || (value >= max && type === 'add')) {
            return;
        }
        const actStep = type === 'add' ? step : -step;
        const oldValue = value;
        let newValue = oldValue + actStep;
        // new value should not be out of range [min, max]
        newValue = newValue > max ? max : newValue;
        newValue = newValue < min ? min : newValue;
        onChange(newValue, oldValue);
    }

    render() {
        const {
            value,
            min,
            max,
        } = this.props;
        const leftBtnClass = PureComponent.classNames(
            'number-count__button',
            'number-count__button--left',
            { 'number-count__button--disable': value <= min },
        );
        const rightBtnClass = PureComponent.classNames(
            'number-count__button',
            'number-count__button--right',
            { 'number-count__button--disable': value >= max },
        );

        const valueClass = 'number-count__value';
        return (
            <div className={this.className('number-count')}>
                <button
                    type="button"
                    className={`${leftBtnClass}`}
                    onClick={(e) => {
                        this.changeValue(e, 'minus');
                    }}
                >
                    -
                </button>
                <span className={valueClass}>
                    {value}
                </span>
                <button
                    type="button"
                    className={`${rightBtnClass}`}
                    onClick={(e) => {
                        this.changeValue(e, 'add');
                    }}
                >
                    +
                </button>
            </div>
        );
    }
}

NumberCount.propTypes = {
    /** 当前值 */
    value: PropTypes.number,
    /** 最小值, 只能限制由NumberCount组件引起的变化 */
    min: PropTypes.number,
    /** 最大值,只能限制由NumberCount组件引起的变化 */
    max: PropTypes.number,
    /** 每次加、减的跨度 */
    step: PropTypes.number,
    /** 值改变时的回调函数 */
    onChange: PropTypes.func,
};

NumberCount.defaultProps = {
    value: 0,
    min: 0,
    max: Infinity,
    step: 1,
    onChange: null,
};

export default NumberCount;
