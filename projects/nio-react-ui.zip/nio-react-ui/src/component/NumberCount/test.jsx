import React from 'react';
import NumberCount from './index';

// 快照测试
describe('NumberCount Snapshot', () => {
    it('render correctly', () => {
        const wrapper1 = render(
            <NumberCount value={1} />,
        );
        expect(wrapper1).toMatchSnapshot();
        const wrapper2 = render(
            <NumberCount value={1} min={1} />,
        );
        expect(wrapper2).toMatchSnapshot();
        const wrapper3 = render(
            <NumberCount value={1} max={1} />,
        );
        expect(wrapper3).toMatchSnapshot();
    });
});

describe('NumberCount Default Props', () => {
    it('default props', () => {
        const wrapper = mount(
            <NumberCount />,
        );
        expect(wrapper.prop('value')).toBe(0);
        expect(wrapper.prop('min')).toBe(0);
        expect(wrapper.prop('max')).toBe(Infinity);
        expect(wrapper.prop('step')).toBe(1);
        expect(wrapper.prop('onChange')).toBeNull();
    });
});

describe('NumberCount Unit Case', () => {
    it('handle change correctly', () => {
        let wrapper;
        const mockOnChange = jest.fn((value) => {
            wrapper.setProps({ value });
        });
        const initialValue = 1;
        wrapper = mount(
            <NumberCount
                max={2}
                value={initialValue}
                min={0}
                step={1}
                onChange={mockOnChange}
            />,
        );
        const minusButton = wrapper.find('button').at(0);
        const addButton = wrapper.find('button').at(1);

        // minus
        minusButton.simulate('click');
        expect(mockOnChange).toHaveBeenCalledTimes(1);
        expect(mockOnChange).toHaveBeenCalledWith(0, 1);

        // reached min limitation
        minusButton.simulate('click');
        expect(mockOnChange).toHaveBeenCalledTimes(1);

        wrapper.setProps({ value: initialValue });

        // add
        addButton.simulate('click');
        expect(mockOnChange).toHaveBeenCalledTimes(2);
        expect(mockOnChange).toHaveBeenCalledWith(2, 1);

        // reached min limitation
        addButton.simulate('click');
        expect(mockOnChange).toHaveBeenCalledTimes(2);

        // step larger than 1
        const props = {
            value: 4,
            step: 3,
            max: 8,
            min: 0,
        };
        wrapper.setProps(props);
        minusButton.simulate('click');
        expect(mockOnChange).lastCalledWith(1, 4);
        // if result out of range after minus
        // current value should be 1 and -2 after minus by step
        // but min is 0, so should fire onChange with value 0
        minusButton.simulate('click');
        expect(mockOnChange).lastCalledWith(0, 1);
        // reset props
        wrapper.setProps(props);
        addButton.simulate('click');
        expect(mockOnChange).lastCalledWith(7, 4);
        // if result out of range after add
        // current value should be 7 and 10 after add by step
        // but max is 8, so should fire onChange with value 8
        addButton.simulate('click');
        expect(mockOnChange).lastCalledWith(8, 7);
    });
});
