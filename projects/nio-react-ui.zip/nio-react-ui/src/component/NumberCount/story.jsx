import React from 'react';
import registerStory from '~storybook';
import NumberCount from './index';

const style = {
    wrapperStyle: {
        height: 100,
    },
};
// register story
const {
    stories,
    knobs,
    state,
} = registerStory('NumberCount', style);

const {
    text,
    number,
} = knobs;

const {
    State,
    Store,
} = state;

const store = new Store({
    value: 1,
});

const onChange = (value, old) => {
    console.log('onChange with value: ', value, ' and old value:', old);
    store.set({ value });
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为number输入
          - ** 注意 **在props : 不设置** max **时等同于没有最大值限制
        `,
        },
    })
    .add('base usage', () => {
        const className = text('className', '');
        const step = number('step', 1);
        const min = number('min', 1);
        const max = number('max', 10);

        return (
            <State store={store}>
                <NumberCount
                    className={className}
                    value={store.get('value')}
                    step={step}
                    onChange={onChange}
                    min={min}
                    max={max}
                />
            </State>
        );
    });
