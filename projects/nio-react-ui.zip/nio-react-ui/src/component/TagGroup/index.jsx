import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import Tag from '../Tag';
import Toast from '../Toast';

import './index.scss';

class TagGroup extends PureComponent {
    constructor(props) {
        super(props);
        this.renderChild = this.renderChild.bind(this);
        this.onSelect = this.onSelect.bind(this);
    }

    onSelect(value, disabled) {
        const {
            onChange,
            values,
            maxSelect,
            autoToast,
        } = this.props;
        if (!onChange || disabled) {
            return;
        }
        const valueIndex = values.findIndex(v => v === value);

        // 是否已选中的value里
        const hasSelected = valueIndex > -1;

        if (!hasSelected && values.length >= maxSelect) {
            // 直接切换选项
            if (maxSelect === 1) {
                onChange([value]);
                return;
            }
            // 达到选中数量限制且尝试选中新项
            if (autoToast) {
                Toast.show(`最多只能选${maxSelect}项！`);
            }
            return;
        }

        const newValues = [...values];
        if (hasSelected) {
            // 取消选中
            newValues.splice(valueIndex, 1);
        } else {
            // 选中
            newValues.push(value);
        }
        onChange(newValues);
    }

    renderChild(items) {
        const {
            values,
            tagClass,
            disabled: globalDisabled,
        } = this.props;
        return items.map((radioItem) => {
            const {
                value,
                content,
                iconName,
                disabled: itemDisabled,
            } = radioItem;
            const selected = !!values.find(v => value === v);
            return (
                <Tag
                    className={tagClass}
                    iconName={iconName}
                    key={String(value)}
                    value={value}
                    content={content}
                    selected={selected}
                    disabled={globalDisabled || itemDisabled}
                    onClick={(v, d) => {
                        this.onSelect(v, d);
                    }}
                />
            );
        });
    }

    render() {
        const { items } = this.props;
        const cls = this.className('nio-tag-group');

        return (
            <div className={cls}>
                {this.renderChild(items)}
            </div>
        );
    }
}

TagGroup.defaultProps = {
    tagClass: '',
    values: [],
    onChange: null,
    items: [],
    disabled: false,
    maxSelect: Number.MAX_SAFE_INTEGER,
    autoToast: false,
};

TagGroup.propTypes = {
    /** 内部Tag class */
    tagClass: PropTypes.string,
    /** 当前组件选中值 */
    values: PropTypes.arrayOf(
        PropTypes
            .oneOfType([
                PropTypes.string,
                PropTypes.number,
            ]),
    ),
    /** 选中值变化回调 onChange(newValues) */
    onChange: PropTypes.func,
    /** 待渲染item */
    items: PropTypes.arrayOf(
        PropTypes.shape({
            value: PropTypes
                .oneOfType([
                    PropTypes.string,
                    PropTypes.number,
                ])
                .isRequired,
            disabled: PropTypes.bool,
            iconName: PropTypes.string,
        }),
    ),
    /** 为true时禁用所有checkbox */
    disabled: PropTypes.bool,
    /** 最多选中数量 */
    maxSelect: PropTypes.number,
    /** 超过最多数目时是否需要自动提示 */
    autoToast: PropTypes.bool,
};

export default TagGroup;
