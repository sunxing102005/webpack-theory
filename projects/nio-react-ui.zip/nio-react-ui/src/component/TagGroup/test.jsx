import React from 'react';
import TagGroup from './index';
import Tag from '../Tag';
import Toast from '../Toast';

jest.mock('../Toast');

describe('TagGroup Snapshot', () => {
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
    ];

    it('render correctly', () => {
        const wrapper = render(
            <TagGroup
                items={items}
            />,
        );
        expect(wrapper).toMatchSnapshot();

        const wrapperDisable = render(
            <TagGroup
                disabled
                items={items}
            />,
        );
        expect(wrapperDisable).toMatchSnapshot();
    });
});

describe('TagGroup Default Props', () => {
    const wrapper = mount(
        <TagGroup />,
    );
    expect(wrapper.prop('items')).toEqual([]);
    expect(wrapper.prop('values')).toEqual([]);
    expect(wrapper.prop('onChange')).toBeNull();
    expect(wrapper.prop('disabled')).toBe(false);
    expect(wrapper.prop('autoToast')).toBe(false);
    expect(wrapper.prop('tagClass')).toBe('');
});

describe('TagGroup Unit Test', () => {
    // do not modify these test data
    // To push new items is allowed
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
        {
            value: 3,
            disabled: false,
            content: 'item 3',
        },
        {
            value: 4,
            disabled: false,
            content: 'item 4',
        },
    ];

    const onChangeMock = jest.fn();
    Toast.show.mockImplementation(value => value);
    const wrapper = mount(
        <TagGroup
            values={[1]}
            maxSelect={1}
            items={items}
            disabled={false}
            autoToast={false}
            onChange={onChangeMock}
        />,
    );

    const tag0 = wrapper.find(Tag).at(0);
    const tag1 = wrapper.find(Tag).at(1);
    const tag2 = wrapper.find(Tag).at(2);
    const tag3 = wrapper.find(Tag).at(3);

    it('handle correctly', () => {
        expect(tag0.props().selected).toBe(true);
        expect(tag0.props().disabled).toBe(false);
        expect(tag1.props().selected).toBe(false);
        expect(tag1.props().disabled).toBe(true);
        expect(tag2.props().selected).toBe(false);
        expect(tag2.props().disabled).toBe(false);

        // onChange should be called when selecting new value with values.length === maxSelect and maxSelect === 1
        tag2.simulate('click');
        expect(onChangeMock).toHaveBeenCalledWith([3]);

        // onChange shouldn't be called when selecting new value with values.length === maxSelect and maxSelect > 1
        wrapper.setProps({ maxSelect: 2 });
        wrapper.setProps({ values: [1, 3] });
        tag3.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(1);

        wrapper.setProps({ autoToast: true });
        tag3.simulate('click');
        expect(Toast.show).toHaveBeenCalledWith('最多只能选2项！');
        expect(onChangeMock).toHaveBeenCalledTimes(1);

        // select item in disabled mode shouldn't fire onChange
        wrapper.setProps({ disabled: true });
        tag0.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(1);
        wrapper.setProps({ disabled: false });
        // cancel select
        tag0.simulate('click');
        expect(onChangeMock).toHaveBeenLastCalledWith([3]);

        wrapper.setProps({ values: [] });

        // disable item shouldn't not fire onChange
        tag1.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(2);

        tag2.simulate('click');
        expect(onChangeMock).toHaveBeenLastCalledWith([3]);
    });
});
