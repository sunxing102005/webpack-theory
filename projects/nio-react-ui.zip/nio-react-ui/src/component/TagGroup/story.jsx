import React from 'react';
import registerStory from '~storybook';
import TagGroup from './index';

const style = {
    wrapperStyle: {
        width: 400,
    },
};

// register story
const {
    stories,
    state,
    knobs,
} = registerStory('TagGroup', style);

const {
    boolean,
    number,
} = knobs;

const {
    State,
    Store,
} = state;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 传入Item数组，快速渲染tag列表
          - 提供参数控制列表行为
          - item.value 不能重复
          - **注意** props : ** maxSelect **为1时，选择时会自动切换选项
        `,
        },
    });

const store = new Store({
    values: [1],
});

const onChange = (values) => {
    console.log('new values:', values);
    store.set({ values });
};

story.add('base usage', () => {
    const autoToast = boolean('autoToast', false);
    const disabled = boolean('disabled', false);
    const maxSelect = number('maxSelect', 1);
    const items = [
        {
            value: 1,
            disabled: false,
            content: '我是测试item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
        {
            value: 3,
            disabled: false,
            content: 'item 3',
        },
        {
            value: 4,
            disabled: false,
            content: 'item 4',
        },
    ];
    return (
        <State store={store}>
            <TagGroup
                disabled={disabled}
                maxSelect={maxSelect}
                autoToast={autoToast}
                items={items}
                onChange={onChange}
            />
        </State>
    );
});
