import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

export default class Notice extends PureComponent {
    constructor(props) {
        super(props);
        this.close = this.close.bind(this);
        this.startCloseTimer = this.startCloseTimer.bind(this);
        this.clearCloseTimer = this.clearCloseTimer.bind(this);
    }

    componentDidMount() {
        // 启动关闭组件的定时器
        this.startCloseTimer();
    }

    componentDidUpdate(prevProps) {
        const { closeDelay, update } = this.props;
        if (closeDelay !== prevProps.closeDelay
          || update) {
            this.restartCloseTimer();
        }
    }

    componentWillUnmount() {
        // 组件卸载了，清除定时器
        this.clearCloseTimer();
    }

    close() {
        const { onClose } = this.props;
        this.clearCloseTimer();
        onClose();
    }

    startCloseTimer() {
        const { closeDelay } = this.props;
        // closeDelay 默认为2秒
        if (closeDelay) {
            this.closeTimer = setTimeout(() => {
                this.close();
            }, closeDelay * 1000);
        }
    }

    clearCloseTimer() {
        if (this.closeTimer) {
            // 清除定时器，并将this.closeTimer设置为null
            clearTimeout(this.closeTimer);
            this.closeTimer = null;
        }
    }

    restartCloseTimer() {
        // 重启关闭组件的定时器。重启前，先清除定时器。
        this.clearCloseTimer();
        this.startCloseTimer();
    }

    render() {
        const { prefixCls, style, children } = this.props;
        // componentClass表示整个组件的样式前缀
        const componentClass = this.className({
            [`${prefixCls}__notice`]: !!prefixCls,
        });
        const contentClass = PureComponent.classNames({
            [`${prefixCls}__content`]: !!prefixCls,
        });
        return (
            // 组件没有定义样式。使用者可以传入样式类的前缀prefixCls。
            <div
                className={componentClass}
                style={style}
            >
                <div className={contentClass}>{children}</div>
            </div>
        );
    }
}

Notice.propTypes = {
    /** 该组件样式前缀 */
    prefixCls: PropTypes.string,
    /** 该组件挂载后多久关闭 */
    closeDelay: PropTypes.number, // 组件挂载后多久关闭
    /** 当notice关闭后被调用的函数 */
    onClose: PropTypes.func, // 当notice关闭后被调用的函数
    /** 内部展示元素 */
    children: PropTypes.string, // 内部展示元素
    /** update属性为true时，组件更新会重启定时器 */
    update: PropTypes.bool, // update属性为true时，组件更新会重启定时器
    /** 自定义样式 */
    style: PropTypes.object, // eslint-disable-line
};

Notice.defaultProps = {
    prefixCls: '',
    onClose() {}, // Notice没有定义关闭的具体细节，由使用者发挥
    children: null,
    closeDelay: 2, // closeDelay不能设置为0和null,undefined
    update: false,
    style: {},
};
