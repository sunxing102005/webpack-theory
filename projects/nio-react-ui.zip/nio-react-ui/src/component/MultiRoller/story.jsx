import React from 'react';
import registerStory from '~storybook';
import MultiRoller from './index';

// register story
const storybook = registerStory('MultiRoller', {
    wrapperStyle: {
        width: '50%',
        height: 500,
        margin: '0 auto',
    },
});

const {
    knobs,
    state,
    stories,
} = storybook;

const {
    boolean,
    number,
} = knobs;

const {
    State,
    Store,
} = state;

const columns = [{
    id: 'column1',
    value: '2',
    data: [{
        value: '1',
        label: '选项一',
    }, {
        value: '2',
        label: '选项二',
    }, {
        value: '3',
        label: '选项三',
    }, {
        value: '4',
        label: '选项四',
    }, {
        value: '5',
        label: (<span>use react element as label</span>),
    }],
    numberToShow: 3,
}, {
    id: 'column2',
    value: '3',
    data: [{
        value: '1',
        label: '选项一',
    }, {
        value: '2',
        label: '选项二',
    }, {
        value: '3',
        label: '选项三',
    }, {
        value: '4',
        label: '选项四',
    }, {
        value: '5',
        label: (<span>use react element as label</span>),
    }],
    numberToShow: 3,
}, {
    id: 'column3',
    value: '4',
    data: [{
        value: '1',
        label: '选项一',
    }, {
        value: '2',
        label: '选项二',
    }, {
        value: '3',
        label: '选项三',
    }, {
        value: '4',
        label: '选项四',
    }, {
        value: '5',
        label: (<span>use react element as label</span>),
    }],
    numberToShow: 3,
}];

const baseUsageStore = new Store({
    columns,
});

// 回调函数中通过store.set更新state
const changeHandler = (v) => {
    columns[v.columnIndex].value = v.value;
    baseUsageStore.set({ columns });
    console.log(`receive value by props 'onChange' : ${v} \n please update props 'columns' here to make selected option change actually`);
};
const closeHandler = (v) => {
    columns[v.columnIndex].value = v.value;
    baseUsageStore.set({ columns });
    console.log(`receive value by props 'onClose' : ${v} \n this value is actually the selected column when closing Roller`);
};

stories
// 该故事集下所有场景通用的Notes
// 支持Markdown语法或者普通文本
    .addParameters({
        info: {
            text: `
          ## Notes
          - 只适用于** 移动端 **
          - 必须更新props : ** columns **的value值，来改变组件选中选项的状态
          - wrapper height必须大于 numberToShow * optionSize (default as 180px)
          - 请在场景**base usage**下，使用devtool中的**device mode**查看组件使用效果
        `,
        },
    })
    // 添加场景'base usage'
    // State组件为 addon-state 提供，用来模拟外部state变化
    // text,boolean等函数为 addon-knobs提供，提供在 knobs panel中改变props的能力
    .add('base usage', () => {
        const height = number('height', 222);
        const headerHeight = number('headerHeight', 60);
        const show = boolean('show', true);
        return (
            <State store={baseUsageStore}>
                <MultiRoller
                    columns={baseUsageStore.get('columns')}
                    // 通过store.get获取state
                    show={show}
                    height={height}
                    headerHeight={headerHeight}
                    onChange={v => changeHandler(v)}
                    onClose={v => closeHandler(v)}
                />
            </State>
        );
    });
