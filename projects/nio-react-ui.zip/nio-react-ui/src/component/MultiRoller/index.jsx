import React from 'react';
import PropTypes from 'prop-types';
import { Component } from '~lib';

import Roller from '../Roller';

import './index.scss';

const DEFAULT_NUMBER_TO_SHOW = 3;
const DEFAULT_HEADER_HEIGHT = 60;
const DEFAULT_HEIGHT = 222;

class MultiRoller extends Component {
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
    }

    handleChange(columnId, columnIndex) {
        const {
            onChange,
        } = this.props;
        return (value, index) => {
            if (onChange) {
                onChange({
                    id: columnId,
                    columnIndex,
                    value,
                    index,
                });
            }
        };
    }

    handleClose(columnId, columnIndex) {
        const {
            onClose,
        } = this.props;
        return (value, index) => {
            if (onClose) {
                onClose({
                    id: columnId,
                    columnIndex,
                    value,
                    index,
                });
            }
        };
    }

    render() {
        const {
            columns,
            height,
            show,
            headerHeight,
        } = this.props;
        return (
            <div className={this.className('nio-multi-roller')} style={{ height }}>
                {columns.map((option, columnIndex) => {
                    const k = option.id;
                    return (
                        <div className="roller" key={k}>
                            <Roller
                                data={option.data}
                                rollerId={k || 'unknown'}
                                show={show}
                                value={option.value}
                                onChange={this.handleChange(k, columnIndex)}
                                onClose={this.handleClose(k, columnIndex)}
                                title={option.title || ''}
                                headerHeight={headerHeight}
                                numberToShow={option.numberToShow || DEFAULT_NUMBER_TO_SHOW}
                                optionSize={height / (option.numberToShow || DEFAULT_NUMBER_TO_SHOW)}
                            />
                        </div>
                    );
                })}
            </div>
        );
    }
}

MultiRoller.defaultProps = {
    columns: [],
    onChange: null,
    onClose: null,
    height: DEFAULT_HEIGHT,
    headerHeight: DEFAULT_HEADER_HEIGHT,
    show: true,
};

MultiRoller.propTypes = {
    /** 展示的列表 */
    columns: PropTypes.arrayOf(
        PropTypes.shape({
            /** 列表每一列项ID */
            id: PropTypes.any.isRequired,
            /** 列表每一列中行数据 */
            data: PropTypes.arrayOf(
                PropTypes.shape({
                    value: PropTypes.any.isRequired,
                    label: PropTypes.oneOfType([
                        PropTypes.string,
                        PropTypes.element,
                    ]).isRequired,
                }),
            ),
            /** 列表每一列选中value值，data中某一项的value */
            value: PropTypes.any.isRequired,
            /** 展示的行数 */
            numberToShow: PropTypes.number,
        }),
    ),
    /** 关闭组件回调 */
    onClose: PropTypes.func,
    /** 修改操作回调 */
    onChange: PropTypes.func,
    /** 整体组件高度，通过这个算出每一行高度 */
    height: PropTypes.number,
    /** 头部高度 */
    headerHeight: PropTypes.number,
    /** 显示隐藏 */
    show: PropTypes.bool,
};

export default MultiRoller;
