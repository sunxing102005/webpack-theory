import React from 'react';
import registerStory from '~storybook/index';
import Banner from './index';

const style = {
    wrapperStyle: {
        width: 500,
    },
};
// register story
const {
    stories,
    knobs,
} = registerStory('Banner', style);

const {
    text,
    array,
} = knobs;

const clickBanner = (index) => {
    console.log(`第${index + 1}张图片被电击拉卡拉啦`);
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为轮播图UI组件
          - props : ** imageList **为图片url string数组
        `,
        },
    })
    .add('base usage', () => {
        const className = text('className', '');
        const imageCls = text('imageCls', '');
        const paginationCls = text('paginationCls', '');
        const imageList = array('imageList', [
            'https://cdn-app.nio.com/user/2019/4/10/30467070-7bfc-4399-950c-8c5b0c624d46.jpg',
            'https://cdn-app.nio.com/user/2019/4/10/2ae052c1-d4f3-4cc0-a2e3-ecf3464c5b9b.jpg',
        ]);
        return (
            <Banner
                className={className}
                imageCls={imageCls}
                paginationCls={paginationCls}
                imageList={imageList}
                clickBanner={clickBanner}
            />
        );
    });
