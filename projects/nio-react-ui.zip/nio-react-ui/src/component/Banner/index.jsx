import React from 'react';
import PropTypes from 'prop-types';
import Swiper from 'swiper';
import { PureComponent } from '~lib';
import Image from '../Image';

import './index.scss';

class Banner extends PureComponent {
    componentDidMount() {
        this.swiper = new Swiper('.nio-banner', {
            pagination: {
                el: '.swiper-pagination',
            },
            uniqueNavElements: false,
            onSlideChangeEnd: (swiper) => {
                const { changeBanner } = this.props;
                if (changeBanner) {
                    changeBanner(swiper.activeIndex);
                }
            },
        });
    }

    clickBannerHandler(index) {
        const { clickBanner } = this.props;
        if (clickBanner) {
            clickBanner(index);
        }
    }

    render() {
        const {
            imageList,
            imageCls,
            paginationCls,
        } = this.props;

        const imageClassString = PureComponent.classNames(imageCls, {
            'nio-banner__image': true,
        });

        const paginationClassString = PureComponent.classNames(paginationCls, {
            'swiper-pagination': true,
        });

        const classString = this.className('nio-banner');

        return (
            <div className={classString}>
                <div className="swiper-wrapper">
                    {imageList.map((image, i) => {
                        const key = image + i;
                        return (
                            <div
                                key={key}
                                className="swiper-slide"
                                onClick={this.clickBannerHandler.bind(this, i)}
                            >
                                <Image
                                    className={imageClassString}
                                    src={image}
                                />
                            </div>
                        );
                    })}
                </div>
                <div className={paginationClassString} />
            </div>
        );
    }
}

Banner.defaultProps = {
    imageCls: '',
    paginationCls: '',
    imageList: [],
    changeBanner: null,
    clickBanner: null,
};

Banner.propTypes = {
    /** banner 内部图片样式类名 */
    imageCls: PropTypes.string,
    /** banner 内部导航定制样式类名 */
    paginationCls: PropTypes.string,
    /** banner 图片数据列表 */
    imageList: PropTypes.arrayOf(PropTypes.string),
    /** banner 图片切换回调，参数index */
    changeBanner: PropTypes.func,
    /** banner 图片点击回调，参数index */
    clickBanner: PropTypes.func,
};

export default Banner;
