import React from 'react';
import registerStory from '~storybook';
import Toast from './index';

// register story
const {
    stories,
} = registerStory('Toast');

const showToast = () => {
    Toast.show('你好，我是test');
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - show方法提供toast展示, 可设置content, needAnimation, delay, onClose参数
          - destroy方法删除
        `,
        },
    })
    .add('base usage', () => (
        <button
            type="button"
            onClick={() => showToast()}
        >
  点我测试
        </button>
    ));
