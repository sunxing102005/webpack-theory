import Notification from '../Notification';
import './index.scss';

const defaultDelay = 2;
let toastInstance = null;
const maxNoticeCount = 1;

function getToastInstance(callback) {
    if (toastInstance) {
        callback(toastInstance);
        return;
    }
    Notification.newInstance(
        {
            className: 'nio-toast',
            maxCount: maxNoticeCount,
        },
        (instance) => {
            if (toastInstance) {
                callback(toastInstance);
                return;
            }
            toastInstance = instance;
            callback(instance);
        },
    );
}

function notice(props = {}) {
    const {
        delay = defaultDelay,
        content,
        needAnimation = false,
        onClose,
    } = props;
    /* eslint-disable no-unused-vars */
    const closePromise = new Promise((resolve) => {
        const callback = () => {
            if (typeof onClose === 'function') {
                onClose();
            }
            return resolve(true);
        };
        getToastInstance((instance) => {
            instance.notice({
                delay,
                className: needAnimation ? 'slide-up' : '',
                prefixCls: 'nio-toast',
                content: ((`${content}`).replace(/</g, '&lt;').replace(/</g, '&gt;')),
                onClose: callback,
            });
        });
    });
}

const Toast = {
    /** 展示toast,重复展示会覆盖 */
    show: (content, needAnimation, delay, onClose) => notice({
        content, delay, needAnimation, onClose,
    }),
    /** 删除toast */
    destroy: () => {
        if (toastInstance) {
            toastInstance.destroy();
            toastInstance = null;
        }
    },
};

export default Toast;
