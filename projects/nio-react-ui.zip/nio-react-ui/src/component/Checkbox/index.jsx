import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import CheckboxIcon from './CheckboxIcon';
import './index.scss';

class Checkbox extends PureComponent {
    constructor(props) {
        super(props);
        this.onClick = this.onClick.bind(this);
    }

    onClick(e) {
        const { onClick, value, disabled } = this.props;
        if (disabled || !onClick) {
            return;
        }
        onClick(e, value);
    }

    render() {
        const {
            checked,
            children,
            disabled,
            iconClass,
            roundIcon,
            dotIcon,
        } = this.props;
        const classString = this.className(
            'nio-checkbox',
            {
                'nio-checkbox--checked': checked,
                'nio-checkbox--disabled': disabled,
            },
        );

        return (
            <div className={classString} onClick={this.onClick}>
                <CheckboxIcon
                    roundIcon={roundIcon}
                    dotIcon={dotIcon}
                    className={iconClass}
                    checked={checked}
                    disabled={disabled}
                />
                {children && (
                    <div className="nio-checkbox__label">
                        {children}
                    </div>
                )}
            </div>
        );
    }
}

Checkbox.defaultProps = {
    checked: false,
    onClick: null,
    disabled: false,
    children: null,
    iconClass: '',
    roundIcon: true,
    dotIcon: false,
    value: '',
};

Checkbox.propTypes = {
    /** checkbox value, will be passed by 2nd params in onClick */
    value: PropTypes
        .oneOfType([
            PropTypes.string,
            PropTypes.number,
        ]),
    /** is checkbox checked */
    checked: PropTypes.bool,
    /** checkbox click handler */
    onClick: PropTypes.func,
    /** is checkbox disabled */
    disabled: PropTypes.bool,
    /** content for checkbox */
    children: PropTypes.node,
    /** checkbox icon class */
    iconClass: PropTypes.string,
    /** is icon round */
    roundIcon: PropTypes.bool,
    /** is icon dot style */
    dotIcon: PropTypes.bool,
};

export default Checkbox;
