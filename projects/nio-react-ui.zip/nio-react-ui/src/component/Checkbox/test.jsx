import React from 'react';
import Checkbox from './index';

describe('Checkbox Snapshot', () => {
    it('render custom classname', () => {
        const wrapper = render(<Checkbox className="customized" />);
        expect(wrapper).toMatchSnapshot();
    });

    it('render with different prop', () => {
        const wrapper = render(
            <div>
                <Checkbox checked disabled />
                <Checkbox checked disabled={false} />
                <Checkbox checked={false} disabled />
                <Checkbox checked={false} disabled={false} />
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

describe('Checkbox default props', () => {
    const wrapper = mount(
        <Checkbox />,
    );
    expect(wrapper.prop('checked')).toBe(false);
    expect(wrapper.prop('onClick')).toBeNull();
    expect(wrapper.prop('disabled')).toBe(false);
    expect(wrapper.prop('children')).toBeNull();
    expect(wrapper.prop('iconClass')).toBe('');
    expect(wrapper.prop('value')).toBe('');
    expect(wrapper.prop('roundIcon')).toBe(true);
});

describe('Checkbox unit test', () => {
    it('handle click', () => {
        const onClickMock = jest.fn();
        const value = 'value';
        const wrapper = shallow(
            <Checkbox value={value} disabled onClick={onClickMock} />,
        );
        wrapper.simulate('click');
        expect(onClickMock).toHaveBeenCalledTimes(0);
        wrapper.setProps({ disabled: false });
        wrapper.simulate('click');
        expect(onClickMock).toHaveBeenCalledTimes(1);
        expect(onClickMock).toHaveBeenCalledWith(undefined, value);
    });
});
