import React from 'react';
import registerStory from '~storybook';
import Checkbox from './index';

// register story
const {
    stories,
    state,
    knobs,
} = registerStory('Checkbox');

const {
    text,
    boolean,
} = knobs;

const {
    State,
    Store,
} = state;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 传入props.value时，会作为props.onClick的第二个参数返回
        `,
        },
    });

const checkboxStore = new Store({
    checked: false,
});

const handleClick = (e, v) => {
    console.log('handle click', e, 'value:', v);
    checkboxStore.set({
        checked: !checkboxStore.get('checked'),
    });
};

story.add('base usage', () => {
    const disabled = boolean('disabled', false);
    const roundIcon = boolean('roundIcon', true);
    const dotIcon = boolean('dotIcon', false);
    const content = text('children', '');
    return (
        <State store={checkboxStore}>
            <Checkbox
                roundIcon={roundIcon}
                dotIcon={dotIcon}
                onClick={handleClick}
                checked={checkboxStore.get('checked')}
                disabled={disabled}
            >
                {content}
            </Checkbox>
        </State>
    );
});
