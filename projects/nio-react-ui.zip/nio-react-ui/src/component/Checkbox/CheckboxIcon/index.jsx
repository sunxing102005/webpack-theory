import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

import './index.scss';

class CheckboxIcon extends PureComponent {
    render() {
        const {
            checked, disabled, roundIcon, dotIcon,
        } = this.props;
        const baseCls = 'nio-checkbox-icon';
        const classString = this.className(
            baseCls,
            {
                [`${baseCls}--checked`]: checked,
                [`${baseCls}--disabled`]: disabled,
                [`${baseCls}--round`]: roundIcon,
                [`${baseCls}--dot`]: dotIcon,
            },
        );

        const innerCls = PureComponent.classNames(
            'nio-checkbox-icon__inner',
            {
                'nio-checkbox-icon__inner--checked': checked,
            },
        );

        return (
            <div className={classString}>
                <div className={innerCls} />
            </div>
        );
    }
}

CheckboxIcon.defaultProps = {
    checked: false,
    disabled: false,
    roundIcon: true,
    dotIcon: false,
};

CheckboxIcon.propTypes = {
    /** 是否选中，控制样式显示 */
    checked: PropTypes.bool,
    /** 是否禁用，控制样式显示 */
    disabled: PropTypes.bool,
    /** icon是否为圆角 */
    roundIcon: PropTypes.bool,
    /** icon为实心样式 */
    dotIcon: PropTypes.bool,
};

export default CheckboxIcon;
