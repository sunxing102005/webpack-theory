/* eslint-disable import/no-extraneous-dependencies, no-undef */
/* eslint-env jest, node, enzyme */
import React from 'react';
import CheckboxIcon from './index';

describe('CheckboxIcon Snapshot', () => {
    it('render custom classname', () => {
        const wrapper = render(<CheckboxIcon className="customized" />);
        expect(wrapper).toMatchSnapshot();
    });

    it('render with different prop', () => {
        const wrapper = render(
            <div>
                <CheckboxIcon checked disabled />
                <CheckboxIcon checked disabled={false} />
                <CheckboxIcon checked={false} disabled />
                <CheckboxIcon checked={false} disabled={false} />
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

describe('CheckboxIcon default props', () => {
    const wrapper = mount(
        <CheckboxIcon />,
    );
    expect(wrapper.prop('checked')).toBe(false);
    expect(wrapper.prop('disabled')).toBe(false);
    expect(wrapper.prop('roundIcon')).toBe(true);
});

describe('CheckboxIcon unit test', () => {
    it('right class with props', () => {
        const wrapper = shallow(
            <CheckboxIcon checked />,
        );
        expect(wrapper.hasClass('nio-checkbox-icon--checked')).toBe(true);
        expect(wrapper.hasClass('nio-checkbox-icon--disabled')).toBe(false);
        wrapper.setProps({
            checked: false,
            disabled: true,
        });
        expect(wrapper.hasClass('nio-checkbox-icon--checked')).toBe(false);
        expect(wrapper.hasClass('nio-checkbox-icon--disabled')).toBe(true);
    });
});
