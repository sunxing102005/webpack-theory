import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import Checkbox from '../Checkbox';

export default class RadioGroup extends PureComponent {
    constructor(props) {
        super(props);
        this.onSelect = this.onSelect.bind(this);
    }

    onSelect(value) {
        const {
            onChange,
            onCancel,
            value: selectedValue,
        } = this.props;
        if (!onChange) {
            return;
        }
        const hasSelected = selectedValue === value;
        if (!hasSelected) {
            onChange(value);
        } else {
            onCancel && onCancel(value);
        }
    }

    renderChild(items) {
        const {
            value: selectedValue,
            checkboxClass,
            iconClass,
            dotIcon,
        } = this.props;
        return items.map((radioItem) => {
            const { value, content, disabled } = radioItem;
            const checked = selectedValue === value;
            return (
                <Checkbox
                    dotIcon={dotIcon}
                    className={checkboxClass}
                    iconClass={iconClass}
                    key={String(value)}
                    value={value}
                    checked={checked}
                    disabled={disabled}
                    onClick={(e, v) => {
                        this.onSelect(v);
                    }}
                >
                    {content}
                </Checkbox>
            );
        });
    }

    render() {
        const { items } = this.props;
        const cls = this.className('nio-radio-group');

        return (
            <div className={cls}>
                {this.renderChild(items)}
            </div>
        );
    }
}

RadioGroup.defaultProps = {
    value: null,
    onChange: null,
    dotIcon: true,
    items: [],
    checkboxClass: '',
    iconClass: '',
    onCancel: null,
};

RadioGroup.propTypes = {
    /** 内部checkbox class */
    checkboxClass: PropTypes.string,
    /** 内部checkbox icon class */
    iconClass: PropTypes.string,
    /** 是否使用实心icon */
    dotIcon: PropTypes.bool,
    /** 当前组件选中值 */
    value: PropTypes
        .oneOfType([
            PropTypes.string,
            PropTypes.number,
        ]),
    /** 选中值变化回调 onChange(newValues) */
    onChange: PropTypes.func,
    onCancel: PropTypes.func,
    /** 待渲染item */
    items: PropTypes.arrayOf(
        PropTypes.shape({
            value: PropTypes
                .oneOfType([
                    PropTypes.string,
                    PropTypes.number,
                ])
                .isRequired,
            disabled: PropTypes.bool,
            iconClass: PropTypes.string,
        }),
    ),
};
