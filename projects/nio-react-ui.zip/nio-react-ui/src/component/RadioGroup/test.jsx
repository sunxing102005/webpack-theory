import React from 'react';
import RadioGroup from './index';
import Checkbox from '../Checkbox';

describe('RadioGroup Snapshot', () => {
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
    ];

    it('render correctly', () => {
        // Toast should not be rendered
        const wrapper = render(
            <RadioGroup
                items={items}
            />,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

describe('RadioGroup Default Props', () => {
    const wrapper = mount(
        <RadioGroup />,
    );
    expect(wrapper.prop('items')).toEqual([]);
    expect(wrapper.prop('value')).toBeNull();
    expect(wrapper.prop('onChange')).toBeNull();
    expect(wrapper.prop('dotIcon')).toBe(true);
    expect(wrapper.prop('iconClass')).toBe('');
    expect(wrapper.prop('checkboxClass')).toBe('');
});

describe('RadioGroup Unit Test', () => {
    // do not modify these test data
    // To push new items is allowed
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
        {
            value: 3,
            disabled: false,
            content: 'item 3',
        },
    ];

    const onChangeMock = jest.fn();
    const onCancelMock = jest.fn();
    const wrapper = mount(
        <RadioGroup
            value={null}
            items={items}
            onChange={onChangeMock}
            onCancel={onCancelMock}
        />,
    );

    const checkbox0 = wrapper.find(Checkbox).at(0);
    const checkbox1 = wrapper.find(Checkbox).at(1);
    const checkbox2 = wrapper.find(Checkbox).at(2);

    it('is checkboxs status right', () => {
        expect(checkbox0.props().checked).toBe(false);
        expect(checkbox0.props().disabled).toBe(false);
        expect(checkbox1.props().checked).toBe(false);
        expect(checkbox1.props().disabled).toBe(true);
        expect(checkbox2.props().checked).toBe(false);
        expect(checkbox2.props().disabled).toBe(false);
        // select disabled item
        checkbox1.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(0);
        // select
        checkbox2.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(1);
        expect(onChangeMock).toHaveBeenCalledWith(3);
        wrapper.setProps({ value: 3 });
        checkbox2.simulate('click');
        // select same item
        expect(onChangeMock).toHaveBeenCalledTimes(1);
        expect(onCancelMock).toHaveBeenCalledTimes(1);
        // select another item
        checkbox0.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(2);
        expect(onChangeMock).toHaveBeenCalledWith(1);
    });
});
