import React from 'react';
import registerStory from '~storybook';
import RadioGroup from './index';
import Image from '../Image';

// register story
const {
    stories,
    state,
    knobs,
} = registerStory('RadioGroup');

const {
    boolean,
} = knobs;

const {
    State,
    Store,
} = state;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 传入items数组，快速创建radio列表
          - 只能选中单个值
          - item.value 不能重复
        `,
        },
    });

const store = new Store({
    value: 1,
});

const onChange = (value) => {
    console.log('new value:', value);
    store.set({ value });
};

story.add('base usage', () => {
    const dotIcon = boolean('dotIcon', true);
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
        {
            value: 3,
            disabled: false,
            content: 'item 3',
        },
        {
            value: 4,
            disabled: false,
            content: <Image src="https://cdn-app.nio.com/user/2019/4/10/30467070-7bfc-4399-950c-8c5b0c624d46.jpg" />,
        },
    ];
    return (
        <State store={store}>
            <RadioGroup
                items={items}
                dotIcon={dotIcon}
                onChange={onChange}
            />
        </State>
    );
});
