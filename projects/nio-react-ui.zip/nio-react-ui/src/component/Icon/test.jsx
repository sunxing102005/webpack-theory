import React from 'react';
import Icon from './index';

describe('Icon', () => {
    it('should render correctly', () => {
        const wrapper = shallow(
            <Icon name="icon-nio" />,
        );
        expect(wrapper.find('i.nio-icon.icon-nio').exists()).toEqual(true);

        wrapper.setProps({ src: 'test.png' });
        wrapper.update();
        expect(wrapper.find('img[src="test.png"]').exists()).toEqual(true);
    });
});

describe('Image Default Props', () => {
    const wrapper = mount(
        <Icon />,
    );
    expect(wrapper.prop('name')).toBe('');
    expect(wrapper.prop('roll')).toBe(false);
    expect(wrapper.prop('src')).toBe('');
    expect(wrapper.prop('onClick')).toBeNull();
});
