import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import './index.scss';

class Icon extends PureComponent {
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick(e) {
        const { onClick } = this.props;
        if (onClick) {
            onClick(e);
        }
    }

    render() {
        const {
            name,
            src,
            roll,
        } = this.props;

        const cls = this.className(
            'nio-icon',
            name,
            {
                roll,
            },
        );
        const style = this.style();
        return src
            ? (
                <img
                    alt=""
                    style={style}
                    className={cls}
                    src={src}
                    onClick={this.handleClick}
                />
            )
            : (
                <i
                    style={style}
                    className={cls}
                    onClick={this.handleClick}
                />
            );
    }
}

Icon.defaultProps = {
    /** iconfont 名称 */
    name: '',
    /** 是否旋转 */
    roll: false,
    /** 如果为img图片，图片地址 */
    src: '',
    onClick: null,
};

Icon.propTypes = {
    /** iconfont 名称 */
    name: PropTypes.string,
    /** 是否旋转 */
    roll: PropTypes.bool,
    /** 如果为img图片，图片地址 */
    src: PropTypes.string,
    /** click handler */
    onClick: PropTypes.func,
};

export default Icon;
