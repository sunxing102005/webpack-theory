import React from 'react';
import registerStory from '~storybook/index';
import Icon from './index';

// register story
const {
    stories,
    knobs,
} = registerStory('Icon');

const {
    text,
    boolean,
} = knobs;


stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为图标UI组件
          - 该组件定制图片icon可通过props src传入图片地址
          - 通过设置name值选择使用icon库中的iconfont
        `,
        },
    })
    .add('base usage', () => {
        const name = text('name', 'icon-nio');
        const roll = boolean('roll', false);
        return <Icon name={name} roll={roll} />;
    })
    .add('all Icons', () => {
        const iconList = [{
            name: 'icon-loading',
            roll: true,
        }, {
            name: 'icon-close',
        }, {
            name: 'icon-tick',
        }, {
            name: 'icon-group',
        }, {
            name: 'icon-view',
        }, {
            name: 'icon-comment',
        }, {
            name: 'icon-map',
        }, {
            name: 'icon-text',
        }, {
            name: 'icon-phone',
        }, {
            name: 'icon-telephone',
        }, {
            name: 'icon-im',
        }, {
            name: 'icon-exchange',
        }, {
            name: 'icon-remark',
        }, {
            name: 'icon-license',
        }, {
            name: 'icon-arrow',
        }, {
            name: 'icon-calendar',
        }, {
            name: 'icon-lbs',
        }, {
            name: 'icon-send',
        }, {
            name: 'icon-white-list',
        }, {
            name: 'icon-lit-next',
        }, {
            name: 'icon-lit',
        }, {
            name: 'icon-like',
        }, {
            name: 'icon-not-like',
        }, {
            name: 'icon-collect',
        }, {
            name: 'icon-not-collect',
        }, {
            name: 'icon-employee',
        }, {
            name: 'icon-nio',
        }, {
            name: 'icon-es8',
        }, {
            name: 'icon-person',
        }, {
            name: 'icon-edit',
        }, {
            name: 'icon-star-light',
        }, {
            name: 'icon-setting',
        }, {
            name: 'icon-add',
        }, {
            name: 'icon-right-arrow',
        }, {
            name: 'icon-down-arrow',
        }, {
            name: 'icon-play',
        }, {
            name: 'icon-pause',
        }, {
            name: 'icon-minimum',
        }, {
            name: 'icon-maximum',
        }, {
            name: 'icon-vioce',
        }, {
            name: 'icon-more',
        }, {
            name: 'icon-handpoint',
        }, {
            name: 'icon-ellipsis',
        }];
        return (
            <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                { iconList.map(icon => (
                    <p
                        key={icon.name}
                        style={{
                            display: 'flex',
                            flexDirection: 'column',
                            margin: '10px',
                            padding: '10px',
                            alignItems: 'center',
                            border: '1px solid #EEEEEE',
                            borderRadius: '4px',
                        }}
                    >
                        <Icon name={icon.name} roll={icon.roll} style={{ fontSize: '24px', marginBottom: '10px' }} />
                        <span style={{ fontSize: '12px' }}>{icon.name}</span>
                    </p>
                ))}
            </div>
        );
    });
