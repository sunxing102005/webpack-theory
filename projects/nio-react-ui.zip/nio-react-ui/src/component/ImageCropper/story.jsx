import React from 'react';
import registerStory from '~storybook';
import ImageCropper from './index';
import ImageInput from '../ImageInput';

// register story
const {
    stories,
    state,
    knobs,
} = registerStory('ImageCropper');

const {
    text,
    number,
    select,
} = knobs;

const {
    State,
    Store,
} = state;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件提供移动端图片裁剪功能
          - 只适用于** 移动端 **
          - ** 注意 **props : ** name **只在props : ** encode **为file时生效
          - ** 注意 **props : ** quality **只在props : ** encode **为base64时生效,且取值0～1之间
          - 请在场景**base usage**下，使用devtool中的**device mode**查看组件使用效果
        `,
        },
    });

const imageCropperStore = new Store({
    origin: '',
    src: '',
});

const onChange = (data) => {
    imageCropperStore.set({
        origin: data,
    });
};

const onSave = (data) => {
    imageCropperStore.set({
        src: data,
    });
};

story.add('base usage', () => {
    const width = number('width', 300);
    const height = number('height', 300);
    const top = number('top', 200);
    const encodeOptions = {
        base64: 'base64',
        blob: 'blob',
        file: 'file',
    };
    const encode = select('encode', encodeOptions, 'base64');
    const typeOptions = {
        jpeg: 'jpeg',
        png: 'png',
    };
    const type = select('type', typeOptions, 'jpeg');
    const name = text('name', 'default_name');
    const label = 'quality';
    const defaultValue = 1;
    const options = {
        range: true,
        min: 0.1,
        max: 1,
        step: 0.1,
    };
    const quality = number(label, defaultValue, options);
    return (
        <State store={imageCropperStore}>
            <ImageInput key={1} onChange={onChange} />
            <ImageCropper
                key={2}
                width={width}
                height={height}
                top={top}
                encode={encode}
                type={type}
                name={name}
                quality={quality}
                origin={imageCropperStore.get('origin')}
                onSave={onSave}
            />
            <img
                key={3}
                style={{
                    marginTop: 20,
                    height: 200,
                    width: 200,
                    objectFit: 'contain',
                }}
                src={imageCropperStore.get('src')}
                alt=""
            />
        </State>
    );
});
