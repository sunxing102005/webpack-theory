import React from 'react';
import ImageCropper from './index';
import {
    createMoveTouchEventObject,
    createEndTouchEventObject,
} from '~utils/test/EventHelpers';

const imageSrc = 'https://cdn-app.nio.com/user/2019/4/10/30467070-7bfc-4399-950c-8c5b0c624d46.jpg';

// canvas.toDataURL.mockReturnValueOnce(imageResult);
describe('ImageCropper', () => {
    it('should render correctly', () => {
        const wrapper = render(<ImageCropper origin={imageSrc} />);
        expect(wrapper).toMatchSnapshot();
    });

    it('should support basic usage', () => {
        const handleImageLoadedFake = jest.spyOn(ImageCropper.prototype, 'handleImageLoaded');
        const setTransformFake = jest.spyOn(ImageCropper.prototype, 'setTransform');
        const showFake = jest.spyOn(ImageCropper.prototype, 'show');
        const wrapper = mount(
            <ImageCropper origin={imageSrc} />,
        );
        wrapper.find('.nio-cropper__image').at(1).simulate('load');
        expect(handleImageLoadedFake).toHaveBeenCalledTimes(1);
        expect(setTransformFake).toHaveBeenCalledTimes(1);
        expect(showFake).toHaveBeenCalledTimes(1);
    });
});

describe('ImageCropper Unit Test', () => {
    it('should support basic touch', () => {
        const handleTouchMoveFake = jest.spyOn(ImageCropper.prototype, 'handleTouchMove');
        const setTranslateFake = jest.spyOn(ImageCropper.prototype, 'setTranslate');
        const setScaleFake = jest.spyOn(ImageCropper.prototype, 'setScale');
        const handleTouchEndFake = jest.spyOn(ImageCropper.prototype, 'handleTouchEnd');
        const wrapper = mount(
            <ImageCropper
                origin={imageSrc}
            />,
        );
        const dom = wrapper.find('.nio-cropper').at(0);
        const point1 = createMoveTouchEventObject({ x: 100, y: 0 });
        dom.simulate('touchMove', point1);
        expect(setScaleFake).not.toHaveBeenCalled();
        expect(handleTouchMoveFake).toHaveBeenCalled();
        expect(setTranslateFake).toHaveBeenCalledWith(point1.touches[0]);
        const point2 = createMoveTouchEventObject({ x: 100, y: 200 }, 2);
        dom.simulate('touchMove', point2);
        expect(setScaleFake).toHaveBeenCalledWith(point2.touches[0], point2.touches[1]);
        expect(setTranslateFake).toHaveBeenLastCalledWith({ clientX: 0, clientY: 0 });
        const point3 = createEndTouchEventObject({ x: 100, y: 200 }, 2);
        dom.simulate('touchEnd', point3);
        expect(handleTouchEndFake).toHaveBeenCalled();
    });

    it('should support save', () => {
        const handleSaveFake = jest.spyOn(ImageCropper.prototype, 'handleSave');
        const saveImageFake = jest.spyOn(ImageCropper.prototype, 'saveImage');
        const hideFake = jest.spyOn(ImageCropper.prototype, 'hide');
        const onSave = jest.fn();
        const wrapper = mount(
            <ImageCropper
                origin={imageSrc}
                encode="base64"
                type="png"
                onSave={onSave}
            />,
        );
        const button = wrapper.find('.nio-button').at(0);
        button.simulate('click');
        expect(handleSaveFake).toHaveBeenCalled();
        // expect(canvas.toDataURL).toHaveBeenCalledWith('image/png', 1);
        expect(saveImageFake).toHaveBeenCalled();
        setTimeout(() => expect(onSave).toHaveBeenCalled(), 500);
        expect(hideFake).toHaveBeenCalled();
        wrapper.setProps({ encode: 'errorinput' });
        button.simulate('click');
        expect(saveImageFake).toHaveBeenCalledTimes(2);
        wrapper.setProps({ encode: 'file' });
        button.simulate('click');
        setTimeout(() => expect(saveImageFake).toHaveBeenCalledTimes(3), 500);
    });

    it('should support close', () => {
        const handleCancelFake = jest.spyOn(ImageCropper.prototype, 'handleCancel');
        const hideFake = jest.spyOn(ImageCropper.prototype, 'hide');
        const onCancel = jest.fn();
        const wrapper = mount(
            <ImageCropper
                origin={imageSrc}
                encode="base64"
                type="png"
                onCancel={onCancel}
            />,
        );
        const close = wrapper.find('.nio-cropper__back-button').at(0);
        close.simulate('click');
        expect(handleCancelFake).toHaveBeenCalled();
        expect(hideFake).toHaveBeenCalled();
        expect(onCancel).toHaveBeenCalled();
    });
});
