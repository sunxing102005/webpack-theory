import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import Icon from '../Icon';
import Button from '../Button';

import './index.scss';

export default class ImageCropper extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            imgStyle: {},
            containerStyle: {},
        };
        // 缩放比例
        this.scale = 1;
        // 原始缩放比例
        this.originScale = 0;
        // 原图宽
        this.originWidth = 0;
        // 原图高
        this.originHeight = 0;
        // 最小高度
        this.minHeight = 0;
        // 最小宽度
        this.minWidth = 0;
        // 旋转角度
        this.rotate = 0;
        this.translateX = 0;
        this.translateY = 0;
        this.moveX = null;
        this.moveY = null;
        this.distance = null;

        this.handleTouchMove = this.handleTouchMove.bind(this);
        this.handleTouchEnd = this.handleTouchEnd.bind(this);
        this.handleImageLoaded = this.handleImageLoaded.bind(this);
        this.handleSave = this.handleSave.bind(this);
        this.handleCancel = this.handleCancel.bind(this);

        this.img = React.createRef();
    }

    async componentDidMount() {
        // 禁止双指缩放
        document.addEventListener('touchstart', (event) => {
            if (event.touches.length > 1) {
                event.preventDefault();
            }
        }, {
            passive: false, // 关闭被动监听
        });
    }

    setScale(touches1, touches2) {
        const x = Math.abs(touches1.clientX - touches2.clientX);
        const y = Math.abs(touches1.clientY - touches2.clientY);
        const s = Math.sqrt(x * x + y * y);
        if (this.distance) {
            const newScale = (s - this.distance) / this.originWidth;
            if (this.scale + newScale < this.originScale) {
                this.scale = this.originScale;
            } else {
                this.scale += newScale;
            }
            this.setTransform();
        }
        this.distance = s;
    }

    setTranslate(touches) {
        const x = touches.clientX;
        const y = touches.clientY;
        if (this.moveX) {
            this.translateX = this.calcLimit(x - this.moveX, true);
        }
        if (this.moveY) {
            this.translateY = this.calcLimit(y - this.moveY);
        }
        this.moveX = x;
        this.moveY = y;
        this.setTransform();
    }

    setTransform(style = {}) {
        const transform = `translate(${this.translateX}px, ${this.translateY}px) scale(${this.scale}) rotate(${this.rotate}deg)`;
        this.setState({
            imgStyle: {
                transform,
                ...style,
            },
        });
    }

    calcLimit(val, isX) {
        const { width, height } = this.props;
        const maxX = 0 - (this.originWidth - this.originWidth * this.scale) / 2;
        const minX = -(this.originWidth - width) + (this.originWidth - this.originWidth * this.scale) / 2;
        const maxY = 0 - (this.originHeight - this.originHeight * this.scale) / 2;
        const minY = -(this.originHeight - height) + (this.originHeight - this.originHeight * this.scale) / 2;
        let limt = 0;
        if (isX) {
            const mx = this.translateX + val;
            if (mx < minX) return minX;
            if (mx > maxX) return maxX;
            limt = mx;
        } else {
            const my = this.translateY + val;
            if (my < minY) return minY;
            if (my > maxY) return maxY;
            limt = my;
        }
        return limt;
    }

    handleTouchMove(e) {
        if (e.touches.length > 1) {
            e.preventDefault();
            this.setScale(e.touches[0], e.touches[1]);
            this.setTranslate({
                clientX: (e.touches[1].clientX - e.touches[0].clientX) / 2,
                clientY: (e.touches[1].clientY - e.touches[0].clientY) / 2,
            });
            return;
        }
        this.setTranslate(e.touches[0]);
    }

    handleTouchEnd() {
        this.distance = null;
        this.moveX = null;
        this.moveY = null;
    }

    handleImageLoaded() {
        const { width, height } = this.props;
        this.originWidth = this.img.current.clientWidth;
        this.originHeight = this.img.current.clientHeight;
        const wScale = width / this.originWidth;
        const hScale = height / this.originHeight;

        // 初始化原点偏移，使之居中
        this.translateX = (width - this.originWidth) / 2;
        this.translateY = (height - this.originHeight) / 2;

        if (wScale > hScale) {
            // 垂直长图
            this.originScale = wScale;
        } else {
            // 水平长图
            this.originScale = hScale;
        }
        this.scale = this.originScale;
        this.setTransform();
        this.show();
    }

    async handleSave() {
        const {
            width,
            height,
            encode,
            quality,
            type,
            name,
        } = this.props;
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const devRatio = window.devicePixelRatio || 1; // 获取设备像素比
        // ctx的像素比
        const backingStore = ctx.backingStorePixelRatio
                || ctx.webkitBackingStorePixelRatio
                || ctx.mozBackingStorePixelRatio
                || ctx.msBackingStorePixelRatio
                || ctx.oBackingStorePixelRatio
                || ctx.backingStorePixelRatio || 1;
        const paintScale = devRatio / backingStore;
        canvas.width = width * paintScale;
        canvas.height = height * paintScale;
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        // 获取图片中心点
        const point = { x: this.originWidth * paintScale / 2, y: this.originHeight * paintScale / 2 };
        // 偏移容器
        ctx.translate(this.translateX * paintScale, this.translateY * paintScale);
        // 移至中心点进行缩放
        ctx.translate(point.x, point.y);
        ctx.scale(this.scale, this.scale);
        // 返回起始点绘制
        ctx.translate(-point.x, -point.y);
        ctx.drawImage(this.img.current, 0, 0, this.originWidth * paintScale, this.originHeight * paintScale);
        switch (encode) {
        case 'base64':
            this.saveImage(canvas.toDataURL(`image/${type}`, quality));
            break;
        case 'blob':
            canvas.toBlob(blob => this.saveImage(blob), `image/${type}`);
            break;
        case 'file':
            canvas.toBlob((blob) => {
                const file = new window.File([blob], name, { type: `image/${type}` });
                this.saveImage(file);
            }, `image/${type}`);
            break;
        default:
            this.saveImage(canvas.toDataURL(`image/${type}`, quality));
            break;
        }
    }

    saveImage(data) {
        const { onSave } = this.props;
        if (onSave) {
            setTimeout(() => {
                onSave(data);
            }, 300);
        }
        this.hide();
    }

    hide() {
        this.setState({
            containerStyle: {
                transform: 'translateY(100%)',
            },
        });
    }

    show() {
        this.setState({
            containerStyle: {
                transform: 'translateY(0)',
            },
        });
    }

    handleCancel() {
        this.hide();
        this.props.onCancel && this.props.onCancel();
    }

    render() {
        const {
            origin,
            width,
            height,
            top,
            saveButtonProps,
        } = this.props;
        const { imgStyle, containerStyle } = this.state;

        const frameStyle = {
            top: `${top}px`,
            width: `${width}px`,
            height: `${height}px`,
        };

        return (
            <div
                className="nio-cropper"
                onTouchMove={this.handleTouchMove}
                onTouchEnd={this.handleTouchEnd}
                style={containerStyle}
            >
                <Icon
                    className="nio-cropper__back-button"
                    name="icon-right-arrow"
                    onClick={this.handleCancel}
                />
                <div className="nio-cropper__frame" style={frameStyle}>
                    <img
                        alt=""
                        className="nio-cropper__image"
                        src={origin}
                        style={imgStyle}
                    />
                </div>
                <div className="nio-cropper__layer" />
                <div
                    className="nio-cropper__frame nio-cropper__frame--show"
                    style={frameStyle}
                >
                    <img
                        alt=""
                        className="nio-cropper__image"
                        ref={this.img}
                        crossOrigin="Anonymous"
                        src={origin}
                        style={imgStyle}
                        onLoad={this.handleImageLoaded}
                    />
                </div>
                <div className="nio-cropper__operation-bar">
                    <Button
                        onClick={this.handleSave}
                        {...saveButtonProps}
                    >
                        确认添加
                    </Button>
                </div>
            </div>
        );
    }
}

ImageCropper.propTypes = {
    /** 图片src */
    origin: PropTypes.string,
    /** 剪裁宽度 */
    width: PropTypes.number,
    /** 剪裁高度 */
    height: PropTypes.number,
    /** 剪裁窗口顶部距离 */
    top: PropTypes.number,
    /** 导出格式，支持 base64|blob|file */
    encode: PropTypes.string,
    /** 剪裁后图片类型，仅支持jpeg/png两种 */
    type: PropTypes.string,
    /** 如果导出格式位file, 则可以填写图片名 */
    name: PropTypes.string,
    /** 压缩质量 */
    quality: PropTypes.number,
    /** 取消回调 */
    onCancel: PropTypes.func,
    /** 确认回调 */
    onSave: PropTypes.func,
    /** 按钮样式 */
    saveButtonProps: PropTypes.object,
};

ImageCropper.defaultProps = {
    origin: '',
    width: 300,
    height: 300,
    encode: 'base64',
    type: 'jpeg',
    name: 'default_name',
    quality: 1,
    top: 200,
    saveButtonProps: {
        style: {
            width: '120px',
            marginBottom: '60px',
        },
    },
    onCancel: null,
    onSave: null,
};
