import React from 'react';
import Progress from './index';

describe('Progress', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <div>
                <Progress key={1} className="test" />
                <Progress key={2} valueBarCls="test-value-bar" />
                <Progress key={3} value={40} />
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });

    it('calls component setValueBarWidth', () => {
        const spyFunction = jest.spyOn(Progress.prototype, 'setValueBarWidth');
        const wrapper = mount(
            <Progress
                value={10}
            />,
        );
        expect(spyFunction).toHaveBeenCalledTimes(1);
        wrapper.setProps({
            value: 20,
        });
        expect(spyFunction).toHaveBeenCalledTimes(2);
        spyFunction.mockClear();
    });
});

describe('Progress Default Props', () => {
    const wrapper = mount(
        <Progress />,
    );
    expect(wrapper.prop('value')).toBe(0);
    expect(wrapper.prop('valueBarCls')).toBe('');
});
