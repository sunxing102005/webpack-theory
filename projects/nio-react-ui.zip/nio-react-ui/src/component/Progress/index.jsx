import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

import './index.scss';

class Progress extends PureComponent {
    constructor(props) {
        super(props);
        this.progressBar = React.createRef();
        this.state = {
            valueBarWidth: 0,
        };
    }

    componentDidMount() {
        this.setValueBarWidth();
    }

    componentDidUpdate(prevProps) {
        const { value } = this.props;
        if (value !== prevProps.value) {
            this.setValueBarWidth();
        }
    }

    setValueBarWidth() {
        if (!this.progressBar || !this.progressBar.current) {
            return;
        }
        const {
            value,
        } = this.props;
        this.setState({
            valueBarWidth: value / 100 * this.progressBar.current.clientWidth,
        });
    }

    render() {
        const { valueBarCls } = this.props;
        const { valueBarWidth } = this.state;
        return (
            <div className={this.className('nio-progress-bar')} ref={this.progressBar} style={this.style()}>
                <div
                    className={PureComponent.classNames('nio-progress-value-bar', valueBarCls)}
                    style={{ width: `${valueBarWidth}px` }}
                />
            </div>
        );
    }
}

Progress.propTypes = {
    /** 进度条value bar自定义className */
    valueBarCls: PropTypes.string,
    /** 进度条value百分比的值 e.g. 50 */
    value: PropTypes.number,
};

Progress.defaultProps = {
    valueBarCls: '',
    value: 0,
};

export default Progress;
