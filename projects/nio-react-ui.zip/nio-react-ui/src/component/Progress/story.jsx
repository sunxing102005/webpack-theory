import React from 'react';
import registerStory from '~storybook';
import Index from './index';

const style = {
    wrapperStyle: {
        height: 100,
    },
};
// register story
const {
    stories,
    knobs,
} = registerStory('Progress', style);

const {
    text,
    number,
} = knobs;

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为进度条UI组件
        `,
        },
    })
    .add('base usage', () => {
        const className = text('className', '');
        const valueBarCls = text('valueBarCls', '');
        const value = number('value', 50);

        return (
            <Index
                className={className}
                valueBarCls={valueBarCls}
                value={value}
            />
        );
    });
