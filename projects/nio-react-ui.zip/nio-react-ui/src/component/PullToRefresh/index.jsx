import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

import Icon from '../Icon';
import { getDirection } from '~utils/direction';
import { formatDate2 } from '~utils/format';

import './index.scss';

const REFRESH_STATUS = [
    {
        status: 'unReachDistanceToRefresh',
        text: '下拉可以刷新',
    },
    {
        status: 'hasReachDistanceToRefresh',
        text: '松开可以刷新',
    },
    {
        status: 'isRefreshing',
        text: '正在刷新数据中...',
    },
];

export default class PullToRefresh extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            statusCode: 0,
            updateTime: new Date().getTime(),
        };
        this.pullToRefresh = React.createRef();
        this.startx; // 触摸起始点x轴坐标
        this.starty; // 触摸起始点y轴坐标
        this.canPull = false; // 是否页面到达最顶点，可以下拉了
        this.isPulling = false; // 是否在下拉中
        this.isRefreshing = false; // 是否在刷新中 由于setState为异步，所以不用this.state.statusCode判断
        this.translate = 0; // 当前位移
    }

    // 接触屏幕
    touchStart(e) {
        this.canPull = false; // 触摸开始时，canPull默认为false
        const scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
        if (scrollTop <= 5) {
            this.canPull = true; // 到达最顶点，可以下拉了
            this.startx = e.touches[0].pageX;
            this.starty = e.touches[0].pageY;
        }
    }

    touchMove(e) {
        if (!this.canPull) return;
        e.persist();
        const result = getDirection(this.startx, this.starty, e.changedTouches[0].pageX, e.changedTouches[0].pageY);
        if (result === 2) { // 下拉
            this.isPulling = true;
            const translate = (e.changedTouches[0].pageY - this.starty) ** 0.85;
            const { distanceToRefresh } = this.props;
            if (!this.isRefreshing) { // 不在刷新中，更新状态
                this.setState({
                    statusCode: translate <= distanceToRefresh ? 0 : 1,
                });
            }
            this.transformScroller(0, translate);
        } else if (result === 1 && !this.isRefreshing) { // 上拉还原
            this.transformScroller(0, 0);
        }
    }

    // 离开屏幕（[e.changedTouches][2]）
    touchEnd() {
        if (!this.isPulling) return;
        this.isPulling = false;
        const { distanceToRefresh } = this.props;
        if (this.translate < distanceToRefresh) { // 没有到可刷新距离时归位
            this.transformScroller(0.3, 0);
        } else {
            if (!this.isRefreshing) { // 不是正在刷新中更新状态为正在刷新
                this.isRefreshing = true;
                this.setState({ statusCode: 2 }); // 设置在下拉刷新加载中
                this.handleRefresh().finally(() => this.dragLoadingDone());
            }
            this.transformScroller(0.1, distanceToRefresh);
        }
    }

    /**
     * 利用 transition 和transform  改变位移
     * @param time duration
     * @param translate  距离
     */
    transformScroller(time, translate) {
        if (this.translate === translate) return;
        this.translate = translate;
        const elStyle = this.pullToRefresh.current.style || {};
        elStyle.transition = `all ${time}s ease-in-out`;
        elStyle.transform = `translate3d(0, ${translate - 60}px, 0)`;
    }

    /**
     * 处理refresh
     */
    handleRefresh() {
        return new Promise((resolve) => {
            this.props.onRefresh(resolve);
        });
    }

    /**
     * 下拉刷新完毕
     */
    dragLoadingDone() {
        // 还原刷新状态
        this.isRefreshing = false;
        this.setState({
            statusCode: 0,
            updateTime: new Date().getTime(),
        });
        this.transformScroller(0.1, 0);
    }

    render() {
        const {
            children,
            disabled,
            distanceToRefresh,
            onRefresh,
            ...rest
        } = this.props;

        if (disabled) {
            return (
                <div {...rest}>
                    {children}
                </div>
            );
        }

        const { statusCode, updateTime } = this.state;

        const { text } = REFRESH_STATUS[statusCode];
        const iconClassString = PureComponent.classNames('refresh-icon', {
            'icon-down-arrow': statusCode !== 2,
            up: statusCode === 1,
            'icon-loading': statusCode === 2,
        });

        return (
            <div
                className="pull-to-refresh"
                ref={this.pullToRefresh}
                onTouchStart={(e) => {
                    this.touchStart(e);
                }}
                onTouchMove={(e) => {
                    this.touchMove(e);
                }}
                onTouchEnd={(e) => {
                    this.touchEnd(e);
                }}
                {...rest}
            >
                <div className="pull-to-refresh__layer">
                    <Icon className={iconClassString} roll={statusCode === 2} />
                    <div className="pull-to-refresh__content">
                        <p className="pull-to-refresh__text">{text}</p>
                        <p className="pull-to-refresh__time">{`最后更新：${formatDate2(Math.floor(updateTime / 1000))}`}</p>
                    </div>
                </div>
                { children }
            </div>
        );
    }
}

PullToRefresh.defaultProps = {
    disabled: false,
    distanceToRefresh: 60,
    onRefresh: () => {},
    children: null,
};

PullToRefresh.propTypes = {
    /** 是否禁用下拉刷新 */
    disabled: PropTypes.bool,
    /** 下拉刷新位移距离，默认60 */
    distanceToRefresh: PropTypes.number,
    /** 下拉刷新钩子方法 */
    onRefresh: PropTypes.func,
    /** 内部子组件,只能是单个元素 */
    children: PropTypes.node,
};
