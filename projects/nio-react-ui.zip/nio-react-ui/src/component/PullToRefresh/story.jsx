import React from 'react';
import registerStory from '~storybook/index';

import PullToRefresh from './index';

const {
    stories,
    knobs,
} = registerStory('PullToRefresh');

const {
    boolean,
    number,
} = knobs;

const handleRefresh = (resolve) => {
    console.log('onRefresh had been called, callback param is: ', resolve);
    setTimeout(() => {
        resolve();
    }, 2000);
};

const wrapperStyle = {
    width: '375px',
    height: '600px',
    border: '1px solid #CCC',
    overflow: 'hidden',
};

const contentStyle = {
    height: '700px',
    padding: '50px',
    textAlign: 'center',
    lineHeight: '40px',
};

stories
    .addParameters({
        info: {
            text: `
              ## Notes
              - 该组件为下拉刷新组件
              - 提供disabled属性控制组件是否可下拉
              - distanceToRefresh属性为触发下拉操作的距离，默认为60px
              - onRefresh为下拉触发的回调，参数为resolve，调用resolve即可重置下拉状态
            `,
        },
    })
    .add('base usage', () => {
        const disabled = boolean('disabled', false);
        const distanceToRefresh = number('distanceToRefresh', 60);
        return (
            <div style={wrapperStyle}>
                <PullToRefresh
                    disabled={disabled}
                    distanceToRefresh={distanceToRefresh}
                    onRefresh={handleRefresh}
                >
                    <div style={contentStyle}>
                        <p>Pull To Refresh</p>
                        <p>请切换至移动端模拟器查看效果</p>
                    </div>
                </PullToRefresh>
            </div>
        );
    });
