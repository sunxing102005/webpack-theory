import React from 'react';
import PullToRefresh from './index';
import {
    createStartTouchEventObject,
    createMoveTouchEventObject,
} from '~utils/test/EventHelpers';

describe('PullToRefresh', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <PullToRefresh>
                <p>PullToRefresh children</p>
            </PullToRefresh>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

describe('PullToRefresh Event Test', () => {
    const onRefresh = jest.fn();
    const wrapper = mount(
        <PullToRefresh onRefresh={onRefresh} />,
        { attachTo: document.body },
    );
    const container = wrapper
        .find('.pull-to-refresh')
        .at(0);

    it('should call onTouch method', () => {
        const transformScrollerFake = jest.spyOn(PullToRefresh.prototype, 'transformScroller');
        const handleRefreshFake = jest.spyOn(PullToRefresh.prototype, 'handleRefresh');
        const dragLoadingDoneFake = jest.spyOn(PullToRefresh.prototype, 'dragLoadingDone');
        const pointStart = createStartTouchEventObject({ x: 0, y: 50 });
        const pointMove1 = createMoveTouchEventObject({ x: 0, y: 10 });
        const pointMove = createMoveTouchEventObject({ x: 100, y: 50 });
        const pointMove2 = createMoveTouchEventObject({ x: 0, y: 150 });
        const pointMove3 = createMoveTouchEventObject({ x: 0, y: 200 });
        container.simulate('touchStart', pointStart);
        // 上拉还原
        container.simulate('touchMove', pointMove1);
        expect(transformScrollerFake).toHaveBeenCalledWith(0, 0);
        // 上拉方向不对
        container.simulate('touchMove', pointMove);
        expect(transformScrollerFake).toHaveBeenCalledTimes(1);
        // 下拉不到位
        container.simulate('touchMove', pointMove2);
        expect(wrapper.state().statusCode).toBe(0);
        expect(transformScrollerFake).toHaveBeenLastCalledWith(0, 50.11872336272722);
        container.simulate('touchEnd');
        expect(transformScrollerFake).toHaveBeenLastCalledWith(0.3, 0);

        // 下拉到位
        container.simulate('touchMove', pointMove3);
        expect(wrapper.state().statusCode).toBe(1);
        expect(transformScrollerFake).toHaveBeenLastCalledWith(0, 70.7420384876757);
        container.simulate('touchEnd');
        expect(transformScrollerFake).toHaveBeenLastCalledWith(0.1, 60);
        expect(handleRefreshFake).toHaveBeenCalled();
        setTimeout(() => {
            expect(onRefresh).toHaveBeenCalled();
            expect(dragLoadingDoneFake).toHaveBeenCalled();
            expect(transformScrollerFake).toHaveBeenLastCalledWith(0.1, 0);
        });
    });
});

describe('PullToRefresh Default Props', () => {
    const wrapper = mount(
        <PullToRefresh />,
    );
    expect(wrapper.prop('disabled')).toBe(false);
    expect(wrapper.prop('distanceToRefresh')).toBe(60);
    expect(wrapper.prop('children')).toBeNull();
});
