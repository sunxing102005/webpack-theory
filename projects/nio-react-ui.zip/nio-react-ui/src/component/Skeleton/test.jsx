import React from 'react';
import { render } from 'enzyme';
import Skeleton from './index';
import skeletonJson from './test_style_config';

describe('Skeleton Snapshot', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <div>
                {skeletonJson.map((item, index) => {
                    const key = `${index}`;
                    return (
                        <Skeleton key={key} {...item} />
                    );
                })}
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});

// 默认参数检查
describe('Skeleton Default Props', () => {
    it('default props', () => {
        const wrapper = mount(
            <Skeleton />,
        );
        expect(wrapper.prop('subChild')).toEqual([]);
    });
});
