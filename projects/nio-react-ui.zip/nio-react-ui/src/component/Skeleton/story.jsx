import React from 'react';
import registerStory from '~storybook';
import Skeleton from './index';
import skeletonJson from './test_style_config';

// register story
const {
    stories,
} = registerStory('Skeleton');

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为骨架层组件
          - ** 注意 **在props : 传入骨架层item样式
          - ** 注意 **在props : ** subChild **为嵌套子骨架层item的样式数组
        `,
        },
    })
    .add('base usage', () => (
        <div style={{ width: 500 }}>
            {skeletonJson.map((item, index) => {
                const key = `${index}`;
                return (
                    <Skeleton key={key} {...item} />
                );
            })}
        </div>
    ));
