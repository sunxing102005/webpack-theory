const skeletonJson = [
    {
        height: '36px',
        marginTop: '20px',
    },
    {
        marginBottom: '30px',
        subChild: [{
            height: '20px',
            width: '68px',
        }, {
            height: '20px',
            width: '90px',
        }],
    },
    {
        marginBottom: '30px',
        subChild: [
            {
                height: '40px',
                flex: '1',
                justifyContent: 'flex-start',
                alignItems: 'stretch',
                margin: 0,
                subChild: [
                    {
                        height: '40px',
                        width: '40px',
                        marginRight: '10px',
                    },
                    {
                        flexDirection: 'column',
                        alignItems: 'flex-start',
                        margin: 0,
                        subChild: [
                            {
                                width: '70px',
                                height: '20px',
                                margin: 0,
                            }, {
                                width: '90px',
                                height: '10px',
                                margin: 0,
                            }],
                    },
                ],
            }, {
                width: '65px',
                height: '30px',
            },
        ],
    },
    {
        height: '20px',
    },
    {
        height: '20px',
        width: '70%',
    },
    {
        height: '20px',
        width: '50%',
    },
];

export default skeletonJson;
