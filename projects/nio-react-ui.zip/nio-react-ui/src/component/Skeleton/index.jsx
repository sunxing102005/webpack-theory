import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

import './index.scss';

class Skeleton extends PureComponent {
    getStyle() {
        const { ...rest } = this.props;
        const style = {
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            ...rest,
        };
        delete style.subChild;
        return style;
    }

    renderChild() {
        const { subChild } = this.props;
        return subChild.map((child, index) => {
            const key = `${index}`;
            return (
                <Skeleton
                    key={key}
                    className="animated-background"
                    {...child}
                />
            );
        });
    }

    render() {
        const { subChild } = this.props;
        const style = this.getStyle();
        return (
            subChild.length
                // 存在subchild时，递归渲染骨架层
                ? <div style={style}>{this.renderChild()}</div>
                // 否则渲染wrapper
                : <div className={this.className('animated-background')} style={style} />
        );
    }
}

Skeleton.propTypes = {
    /** 内部嵌套骨架层样式数组 */
    subChild: PropTypes.arrayOf(PropTypes.object),
};

Skeleton.defaultProps = {
    subChild: [],
};

export default Skeleton;
