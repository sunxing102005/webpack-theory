/*
 * 网易易盾校验组件
 *
 * props:
 * showNECaptcha [boolean] 控制显隐
 * onError [function] 失败回调
 * onSuccess [function] 成功回调
 * onRepeatedlyFail [function] 多次校验失败回调
 */
import React from 'react';
import Dialog from 'rc-dialog';
import PropTypes from 'prop-types';

import { loadScript } from '~utils/utils';

import './index.scss';

const CAPTCHA_ID = '7dbe434c7764491daa9aea89c26f4836';

export default class NECaptcha extends React.Component {
    componentDidMount() {
        const { visible } = this.props;
        if (visible) {
            this.init();
        }
    }

    componentDidUpdate() {
        const { visible } = this.props;
        if (visible) {
            this.init();
        }
    }

    async init() {
        if (!window.initNECaptcha) {
            await loadScript('//cstaticdun.126.net/load.min.js')
                .catch(err => console.log(err));
        }
        const {
            onError,
            onSuccess,
            onRepeatedlyFail,
        } = this.props;
        let actCount = 0;
        /* eslint-disable no-undef */
        initNECaptcha({
            // config对象，参数配置
            captchaId: CAPTCHA_ID,
            element: '#nio_uiCaptcha',
            mode: 'embed',
            width: 'auto',
            onVerify: (err, data) => {
                actCount++;
                if (actCount > 5) {
                    onRepeatedlyFail && onRepeatedlyFail(err);
                    return;
                }
                if (data) {
                    onSuccess && onSuccess(data);
                }
            },
            onError: (err) => {
                onError && onError(err);
            },
        },
        () => {
            console.log('init NECaptcha success!');
            // 初始化成功后得到验证实例instance，可以调用实例的方法
        },
        (err) => {
            alert(JSON.stringify(err));
            // 初始化失败后触发该函数，err对象描述当前错误信息
        });
    }

    render() {
        const { visible } = this.props;
        return (
            <Dialog
                closable={false}
                wrapClassName="center"
                className="nio-ne-captcha"
                animation="zoom"
                maskAnimation="fade"
                bodyStyle={{ padding: 0 }}
                visible={visible}
            >
                <div className="ne-captcha-wrap" id="nio_uiCaptcha" />
            </Dialog>
        );
    }
}

NECaptcha.defaultProps = {
    visible: false,
    onError: null,
    onSuccess: null,
    onRepeatedlyFail: null,
};

NECaptcha.propTypes = {
    /** 滑块是否显示 */
    visible: PropTypes.bool,
    /** 滑块操作失败回调 */
    onError: PropTypes.func,
    /** 滑块操作成功回调 */
    onSuccess: PropTypes.func,
    /** 滑块重复次数过多回调 */
    onRepeatedlyFail: PropTypes.func,
};
