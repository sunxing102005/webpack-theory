import React from 'react';
import registerStory from '~storybook/index';
import NECaptcha from './index';

const style = {
    wrapperStyle: {
        height: 100,
    },
};
// register story
const {
    state,
    stories,
} = registerStory('NECaptcha', style);

const {
    State,
    Store,
} = state;

const NECaptchaStore = new Store({
    visible: false,
});

const showNECaptcha = () => {
    NECaptchaStore.set({
        visible: true,
    });
};

const hideNECaptcha = () => {
    NECaptchaStore.set({
        visible: false,
    });
};

const onError = (err) => {
    hideNECaptcha();
    console.log('NECaptcha error', err);
};

const onSuccess = (data) => {
    hideNECaptcha();
    console.log('NECaptcha verify success', data);
};

const onRepeatedlyFail = (err) => {
    hideNECaptcha();
    console.log('NECaptcha Repeatedly fail', err);
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为滑块验证组件
          - ** 注意 **在props : ** visible **控制滑块组件是否展示，并且需要在手动设置visible为false关闭组件
        `,
        },
    })
    .add('base usage', () => (
        <div>
            <button
                type="button"
                onClick={() => showNECaptcha()}
            >
    点我测试
            </button>
            <State store={NECaptchaStore}>
                <NECaptcha
                    visible={NECaptchaStore.get('visible')}
                    onError={onError}
                    onSuccess={onSuccess}
                    onRepeatedlyFail={onRepeatedlyFail}
                />
            </State>
        </div>
    ));
