import React from 'react';
import registerStory from '~storybook';
import BottomModal from './index';
import MultiRoller from '../MultiRoller';
import Button from '../Button';

// register story
const {
    stories,
    state,
    knobs,
} = registerStory('BottomModal');

const {
    text,
    boolean,
} = knobs;

const {
    State,
    Store,
} = state;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为完全受控组件，需要通过设置props中visible控制显示和消失
          - ** 注意 **在props : ** title **为空与props : ** showClose **为false同时出现时不显示头部
        `,
        },
    });

const confirmStore = new Store({
    visible: false,
});

const closeClick = (e) => {
    console.log('handle click', e, 'value: close');
    confirmStore.set({
        visible: !confirmStore.get('visible'),
    });
};


const showModal = () => {
    confirmStore.set({
        visible: true,
    });
};

story.add('base usage', () => {
    const title = text('title', '我是标题');
    const content = text('content', '我是confirm内容');
    const showClose = boolean('showClose', true);
    return (
        <div>
            <button
                type="button"
                onClick={() => showModal()}
            >
点我测试
            </button>
            <State store={confirmStore}>
                <BottomModal
                    title={title}
                    showClose={showClose}
                    content={content}
                    visible={confirmStore.get('visible')}
                    onClose={closeClick}
                />
            </State>
        </div>
    );
}).add('custom style', () => {
    const columns = [{
        id: 'column1',
        value: '2',
        data: [{
            value: '1',
            label: '选项一',
        }, {
            value: '2',
            label: '选项二',
        }, {
            value: '3',
            label: '选项三',
        }, {
            value: '4',
            label: '选项四',
        }, {
            value: '5',
            label: (<span>use react element as label</span>),
        }],
        numberToShow: 3,
    }, {
        id: 'column2',
        value: '3',
        data: [{
            value: '1',
            label: '选项一',
        }, {
            value: '2',
            label: '选项二',
        }, {
            value: '3',
            label: '选项三',
        }, {
            value: '4',
            label: '选项四',
        }, {
            value: '5',
            label: (<span>use react element as label</span>),
        }],
        numberToShow: 3,
    }, {
        id: 'column3',
        value: '4',
        data: [{
            value: '1',
            label: '选项一',
        }, {
            value: '2',
            label: '选项二',
        }, {
            value: '3',
            label: '选项三',
        }, {
            value: '4',
            label: '选项四',
        }, {
            value: '5',
            label: (<span>use react element as label</span>),
        }],
        numberToShow: 3,
    }];

    return (
        <div>
            <button
                type="button"
                onClick={() => showModal()}
            >
点我测试
            </button>
            <State store={confirmStore}>
                <BottomModal
                    visible={confirmStore.get('visible')}
                    showClose={false}
                >
                    <div>
                        <MultiRoller
                            columns={columns}
                        />
                        <Button
                            style={{ margin: '15px 0' }}
                            onClick={closeClick}
                        >
                            确定
                        </Button>
                    </div>
                </BottomModal>
            </State>
        </div>
    );
});
