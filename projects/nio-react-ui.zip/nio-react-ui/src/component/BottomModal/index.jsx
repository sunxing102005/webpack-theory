import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import RcDialog from 'rc-dialog';
import Icon from '../Icon';


import './index.scss';

export default function BottomModal(props) {
    const {
        title = '',
        showClose = true,
        visible = false,
        onClose,
        children,
        className,
    } = props;

    return (
        <RcDialog
            closable={false}
            wrapClassName="bottom"
            className="nio-bottom-modal"
            animation="slide-fade"
            maskAnimation="fade"
            bodyStyle={{ padding: 0 }}
            maskStyle={{ position: 'fixed', height: '100vh' }}
            visible={visible}
        >
            <div className={classnames('nio-bottom-modal__content', className)}>
                {
                    (title || showClose)
                        && (
                            <header className="modal__header">
                                {title && <h2 className="modal__title">{title}</h2>}
                                {showClose && <Icon className="icon-close modal__close" onClick={onClose} />}
                            </header>
                        )
                }
                <div className="modal__content">{children}</div>
            </div>
        </RcDialog>
    );
}

BottomModal.propTypes = {
    /** 类名 */
    className: PropTypes.string,
    /** 显示与隐藏 */
    visible: PropTypes.bool,
    /** @type {bool} 是否显示关闭按钮 */
    showClose: PropTypes.bool,
    /** 弹框内容 */
    children: PropTypes.node,
    /** 弹框标题 */
    title: PropTypes.string,
    /** 关闭回调 */
    onClose: PropTypes.func,
};

BottomModal.defaultProps = {
    className: '',
    /** 显示与隐藏 */
    visible: false,
    showClose: true,
    /** 弹框内容 */
    children: '',
    /** 弹框标题 */
    title: '',
    /** 关闭回调 */
    onClose: () => {},
};
