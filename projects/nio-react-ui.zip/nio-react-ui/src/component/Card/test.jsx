import React from 'react';
import { render } from 'enzyme';
import Card from './index';

describe('Card', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <div>
                <Card>
                    <h1>title</h1>
                    <p>content</p>
                    <footer>footer</footer>
                </Card>
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});
