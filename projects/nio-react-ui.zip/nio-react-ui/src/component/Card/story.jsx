import React from 'react';
import registerStory from '~storybook/index';
import Card from './index';

const style = {
    wrapperStyle: {
        height: 300,
        width: 300,
    },
};

// register story
const {
    stories,
    knobs,
} = registerStory('Card', style);

const {
    text,
} = knobs;

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为卡片样式组件
        `,
        },
    })
    .add('base usage', () => {
        const className = text('className', 'normal-card');
        return (
            <Card className={className}>
                <h1>title</h1>
                <p>content </p>
                <footer>footer</footer>
            </Card>
        );
    });
