import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

import './index.scss';

function Card(props) {
    const { children, className, onClick } = props;
    return (
        <div className={classnames(className, { 'nio-card': true })} onClick={onClick}>
            { children }
        </div>
    );
}

Card.defaultProps = {
    /** Card 内部自组件 */
    children: null,
    onClick: null,
    className: '',
};

Card.propTypes = {
    /** Card 内部自组件 */
    children: PropTypes.node,
    onClick: PropTypes.func,
    /** 自定义样式class */
    className: PropTypes.string,
};

export default Card;
