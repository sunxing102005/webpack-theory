import React from 'react';
import registerStory from '~storybook';
import CountDown from './index';
import { getDateAdd } from '~utils/date';
import './story.scss';

const style = {
    wrapperStyle: {
        width: 500,
        height: 200,
        textAlign: 'center',
    },
};
// register story
const { stories, knobs } = registerStory('CountDown', style);

const { text, date } = knobs;
function myDateKnob(name, defaultValue) {
    const stringTimestamp = date(name, defaultValue);
    return new Date(stringTimestamp);
}
function endCallback() {
    console.log('endCallback');
}
const fiveDaysLater = getDateAdd('d', 5, new Date());
stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 倒计时组件，显示距目标时间的时分秒
          - 该组件提供count,deadline等属性设置是否倒计时，截止时间等
        `,
        },
    })
    .add('base usage', () => {
        const title = text('title', '距五天后还有');
        const deadline = myDateKnob('deadline', fiveDaysLater);
        return (
            <CountDown
                title={title}
                className="test-wrap-class"
                deadline={deadline}
                endCallback={endCallback}
            />
        );
    });
