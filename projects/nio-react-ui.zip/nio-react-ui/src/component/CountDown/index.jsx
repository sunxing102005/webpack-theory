import React from 'react';
import PropTypes from 'prop-types';
import CountDownUtil from '~utils/count-down';
import { PureComponent } from '~lib';
import './index.scss';

class CountDown extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            mini: '00',
            sec: '00',
            hour: '00',
        };
        this.cd = null; // 存放CountDownUtil实例
    }


    componentDidMount() {
        this.startCountDown();
    }

    /**
     * 当 count 更新时，开始或停止计时
     */
    componentDidUpdate(prevProps) {
        const { deadline } = this.props;
        if (prevProps.deadline !== deadline) {
            // 倒计时截止时间更新，重新计时
            this.cd && this.cd.stop();
            this.startCountDown();
        }
    }

    componentWillUnmount() {
        (this.cd && this.cd.stop) && this.cd.stop();
    }

    /**
     * 开始计时方法
     */
    startCountDown = () => {
        const { deadline, endCallback } = this.props;
        if (!deadline || !(deadline instanceof Date)) return;
        const cd = new CountDownUtil(deadline, this.changeTime, endCallback);
        this.cd = cd;
        cd.start(); // 开始倒计时
    };

    /**
     * 每次计算时间调用的callback
     */
    changeTime = ({ mini, sec, hour }) => {
        const newState = { mini, sec, hour };
        this.setState(newState);
    };


    render() {
        const {
            mini,
            sec,
            hour,
        } = this.state;
        const { title } = this.props;
        const containerClassName = this.className('nio-cout-down');
        return (
            <React.Fragment>
                <React.Fragment>
                    {title}
                    <div className={containerClassName}>
                        <div className="nio-cout-down__time-item">
                            {hour}
                            <p className="nio-cout-down__time-des">hours</p>
                        </div>
                        <span className="nio-cout-down__separator">:</span>
                        <div className="nio-cout-down__time-item">
                            {mini}
                            <p className="nio-cout-down__time-des">minutes</p>
                        </div>
                        <span className="nio-cout-down__separator">:</span>
                        <div className="nio-cout-down__time-item">
                            {sec}
                            <p className="nio-cout-down__time-des">seconds</p>
                        </div>
                    </div>
                </React.Fragment>
            </React.Fragment>
        );
    }
}
CountDown.propTypes = {
    /** 计时截止时间，北京时间 */
    deadline: PropTypes.object,
    /** 最外层dom类名 */
    // eslint-disable-next-line react/no-unused-prop-types
    className: PropTypes.string,
    /** 计时停止回调函数 */
    endCallback: PropTypes.func,
    /** 倒计时的标题 */
    title: PropTypes.node,
};
CountDown.defaultProps = {
    deadline: null,
    className: '',
    endCallback: null,
    title: '',
};
export default CountDown;
