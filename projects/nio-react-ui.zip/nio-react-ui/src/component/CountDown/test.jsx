import React from 'react';
import CountDown from './index';
import { getDateAdd } from '~utils/date';

describe('CountDown', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <CountDown
                className="test-wrap-class"
                deadline={new Date('2021-10-01')}
                title="距XX还有"
            >
                <p>this is content</p>
            </CountDown>,
        );
        const wrapperNoDeadline = render(
            <CountDown
                className="test-wrap-class"
            >
                <p>this is content</p>
            </CountDown>,
        );
        expect(wrapper).toMatchSnapshot();
        expect(wrapperNoDeadline).toMatchSnapshot();
    });
});

describe('CountDown Time Test', () => {
    it('should have correct date', () => {
        const title = <p id="test-title">testTitle</p>;
        const dateFiveLater = getDateAdd('d', 5, new Date()); // 五天以后
        const wrapper = mount(<CountDown title={title} deadline={dateFiveLater} />);
        const hour = wrapper
            .find('.nio-cout-down__time-item').at(0).text();
        const min = wrapper
            .find('.nio-cout-down__time-item').at(1).text();
        const sec = wrapper
            .find('.nio-cout-down__time-item').at(2).text();
        expect(hour).toBe('120hours');
        expect(min).toBe('00minutes');
        expect(sec).toBe('00seconds');
    });
});
describe('CountDown Time Update', () => {
    const wrapper = mount(
        <CountDown
            className="test-wrap-class"
            deadline={new Date('2021-10-01')}
            title="距XX还有"
        >
            <p>this is content</p>
        </CountDown>,
    );
    const instance = wrapper.instance();
    const spy = jest.spyOn(instance, 'startCountDown');
    wrapper.setProps({ deadline: new Date('2022-10-01') });
    expect(spy).toHaveBeenCalledTimes(1);
});
describe('CountDown  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<CountDown />);
        expect(wrapper.prop('deadline')).toBeNull();
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('endCallback')).toBeNull();
        expect(wrapper.prop('title')).toBe('');
    });
});
