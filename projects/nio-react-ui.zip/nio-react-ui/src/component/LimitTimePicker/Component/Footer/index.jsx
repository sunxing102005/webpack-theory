import React from 'react';
import PropType from 'prop-types';
import Button from '../../../Button';

export default function Footer(props) {
    const { confirmText, onClick } = props;
    return (
        <div className="nio-limit-time-picker__footer">
            <Button
                onClick={onClick}
            >
                {confirmText}
            </Button>
        </div>
    );
}

Footer.defaultProps = {
    onClick: null,
    confirmText: '确认',
};

Footer.propTypes = {
    onClick: PropType.func,
    confirmText: PropType.string,
};
