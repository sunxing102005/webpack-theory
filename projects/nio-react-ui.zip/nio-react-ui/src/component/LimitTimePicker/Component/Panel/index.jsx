import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import MultiRoller from '../../../MultiRoller';
import { getDateDetail } from '~utils/date';
import { formatDate } from '~utils/format';

const LEVEL_MAP = {
    y: {
        DETAIL_NAME: 'year',
        PRIORITY: 0,
        METHOD: 'getFullYear',
    },
    M: {
        DETAIL_NAME: 'month',
        PRIORITY: 1,
        METHOD: 'getMonth',
    },
    d: {
        DETAIL_NAME: 'date',
        PRIORITY: 2,
        METHOD: 'getDate',
    },
    h: {
        DETAIL_NAME: 'hour',
        PRIORITY: 3,
        METHOD: 'getHours',
    },
    m: {
        DETAIL_NAME: 'minute',
        PRIORITY: 4,
        METHOD: 'getMinute',
    },
    s: {
        DETAIL_NAME: 'second',
        PRIORITY: 5,
        METHOD: 'getSeconds',
    },
};

const getLabel = (formatOption, dateObj) => {
    const { label, pattern } = formatOption;
    if (label) {
        return typeof label === 'function' ? label(dateObj) : label;
    }
    return formatDate(dateObj, pattern);
};

const getStringFromLevel = (date, level) => {
    const dateDetail = getDateDetail(date);
    return level.split('-').map((char) => {
        let v = dateDetail[LEVEL_MAP[char].DETAIL_NAME];
        if (char === 'M') {
            v -= 1;
        }
        return v;
    }).join('-');
};

const buildMap = (dates, formats) => {
    const build = (map, param, label, id) => {
        if (!map[param]) {
            /* eslint-disable no-param-reassign */
            map[param] = {
                label,
                id,
            };
        }
        return map[param];
    };
    const map = {};
    dates.forEach((d) => {
        const dateDetail = getDateDetail(d);
        const arr = formats.map((formatOption) => {
            const { level } = formatOption;
            const tmp = [];
            level.split('-').forEach((char) => {
                let v = dateDetail[LEVEL_MAP[char].DETAIL_NAME];
                if (char === 'M') {
                    v--;
                }
                tmp.push(v);
            });
            return {
                value: tmp.join('-'),
                label: getLabel(formatOption, d),
                id: formatOption.id,
            };
        });
        let curM = map;
        arr.forEach((p) => {
            curM = build(curM, p.value, p.label, p.id);
        });
    });
    return map;
};

const buildColumns = (arr, formats, selectedDate) => {
    const selectedArr = formats.map(formatOption => getStringFromLevel(selectedDate, formatOption.level));
    const columns = [{
        value: selectedArr[0],
        data: arr,
        id: arr[0].id,
    }];
    let curArr = arr;
    for (let i = 1; i < selectedArr.length; i++) {
        let parentArr = curArr.find(v => v.value === selectedArr[i - 1]);
        if (!parentArr) {
            [parentArr] = curArr;
        }
        curArr = parentArr.children;
        columns.push({
            value: selectedArr[i],
            data: parentArr.children,
            id: parentArr.children[0].id,
        });
    }
    return columns;
};

export default class Panel extends PureComponent {
    constructor(props) {
        super(props);
        const { data, formats, value } = props;
        this.arr = this.convertDataToArray(data, formats);
        const columns = buildColumns(this.arr, formats, value);
        this.state = { columns };
        this.handleChange = this.handleChange.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        if (this.props.data !== nextProps.data || this.props.formats !== nextProps.formats) {
            this.arr = this.convertDataToArray(nextProps.data, nextProps.formats);
        }
        this.setState({ columns: buildColumns(this.arr, nextProps.formats, nextProps.value) });
    }

    convertDataToArray(data, formats) {
        return this.buildArr(buildMap(data, formats));
    }

    buildArr(map, arr = []) {
        const build = (re, value, label, id) => {
            const children = [];
            re.push({
                value, label, children, id,
            });
            return children;
        };
        const res = arr;

        const keys = Object.keys(map);
        keys.forEach((k) => {
            if (k !== 'label' && k !== 'id') {
                const curArr = build(res, k, map[k].label, map[k].id);
                this.buildArr(map[k], curArr);
            }
        });
        return res;
    }

    handleChange(data) {
        const { columnIndex, value } = data;
        const column = this.state.columns[columnIndex];
        column.value = value;
        this.props.onChange(new Date(...this.state.columns.map(c => c.value).join('-').split('-')));
    }

    render() {
        const show = true;
        return <MultiRoller show={show} columns={this.state.columns} onChange={this.handleChange} />;
    }
}


Panel.defaultProps = {
    onChange: null,
    formats: [],
};

Panel.propTypes = {
    /*  如果设置了 onChange, 则组件内的状态不会自动更新
        需在onChange回调内，更新props.value
        回调参数为 当前选中的 Date对象 */
    onChange: PropTypes.func,
    /* 带选择数据 */
    data: PropTypes.arrayOf(PropTypes.object).isRequired,
    /* value 值 */
    value: PropTypes.oneOfType([
        PropTypes.string, // 只能为空字符串，表示默认值为空
        PropTypes.object,
    ]).isRequired,
    //  formats示例
    //
    //  const formats = [
    //     {
    //         id: 'column1',
    //         level: 'y-M-d',
    //         label: (date) => <div>{date.getMonth() + 1}月{date.getDate()}号 <span
    //             style={{fontSize: 10}}>{formatFunc(date)}</span></div>,
    //     }, {
    //         id: 'column2',
    //         pattern: 'hh:mm',
    //         level: 'h-m',
    //     }
    //  ];
    /* 展示的列数，每一列的形式 */
    formats: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        level: PropTypes.string.isRequired,
        pattern: PropTypes.string,
        label: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.element,
            PropTypes.func,
        ]),
    })),
};
