import React from 'react';
import PropTypes from 'prop-types';

import { Component } from '~lib';

import Panel from './Component/Panel';
import Footer from './Component/Footer';
import BottomModal from '../BottomModal';
import './index.scss';

export default class LimitDateRollerPicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedValue: props.value || props.data[0],
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleConfirm = this.handleConfirm.bind(this);
        this.handleClose = this.handleClose.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ selectedValue: nextProps.value || nextProps.data[0] });
    }

    shouldComponentUpdate(np, ns) {
        return this.props.show !== np.show || (
            this.props.show && (
                this.state.selectedValue !== ns.selectedValue
                || this.props.title !== np.title
                || this.props.data !== np.data
                || this.props.value !== np.value
                || this.props.formats !== np.formats
            )
        );
    }

    handleChange(date) {
        if (this.props.onChange) {
            this.props.onChange(date);
            return;
        }
        this.setState({ selectedValue: date });
    }

    handleConfirm() {
        this.props.onConfirm && this.props.onConfirm(this.state.selectedValue);
    }

    handleClose() {
        this.props.onClose && this.props.onClose(this.state.selectedValue);
    }

    render() {
        const {
            show, title, data, formats,
        } = this.props;
        return (
            <BottomModal
                className="nio-limit-time-picker"
                title={title}
                visible={show}
                onClose={this.handleClose}
            >
                <Panel
                    data={data}
                    value={this.state.selectedValue}
                    formats={formats}
                    onChange={this.handleChange}
                />
                <Footer
                    onClick={this.handleConfirm}
                />
            </BottomModal>
        );
    }
}

LimitDateRollerPicker.defaultProps = {
    onChange: null,
    onConfirm: null,
    onClose: null,
    formats: [],
    title: '请选择',
    value: null,
};

LimitDateRollerPicker.propTypes = {
    /** 如果设置了 onChange, 则组件内的状态不会自动更新
        需在onChange回调内，更新props.value
        回调参数为 当前选中的 Date对象 */
    onChange: PropTypes.func,
    /** 回调参数为 当前选中的 Date对象 */
    onConfirm: PropTypes.func,
    /** 组件关闭时回调，参数为 当前选中的 Date对象 */
    onClose: PropTypes.func,
    /** 带选择数据 */
    data: PropTypes.arrayOf(PropTypes.object).isRequired,
    /** value 值 */
    value: PropTypes.oneOfType([
        PropTypes.string, // 只能为空字符串，表示默认值为空
        PropTypes.object,
    ]),
    //  formats示例
    //
    //  const formats = [
    //     {
    //         id: 'column1',
    //         level: 'y-M-d',
    //         label: (date) => <div>{date.getMonth() + 1}月{date.getDate()}号 <span
    //             style={{fontSize: 10}}>{formatFunc(date)}</span></div>,
    //     }, {
    //         id: 'column2',
    //         pattern: 'hh:mm',
    //         level: 'h-m',
    //     }
    //  ];
    /** 展示的列数，每一列的形式 */
    formats: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        level: PropTypes.string.isRequired,
        pattern: PropTypes.string,
        label: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.element,
            PropTypes.func,
        ]),
    })),
    /** 是否展示 */
    show: PropTypes.bool.isRequired,
    /** 标题 */
    title: PropTypes.string,
};
