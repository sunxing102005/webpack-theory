import React from 'react';
import registerStory from '~storybook';
import LimitDateRollerPicker from './index';
import { getWeek } from '~utils/date';

// register story
const storybook = registerStory('LimitDateRollerPicker');

const {
    knobs,
    state,
    stories,
} = storybook;

const {
    array,
} = knobs;

const {
    State,
    Store,
} = state;

const dataArray = [
    new Date(2020, 7, 20, 9, 0),
    new Date(2020, 7, 20, 10, 0),
    new Date(2020, 7, 21, 9, 0),
    new Date(2020, 7, 21, 10, 0),
    new Date(2020, 7, 22, 9, 0),
    new Date(2020, 7, 22, 10, 0),
];

const baseUsageStore = new Store({
    value: dataArray[0],
    show: false,
});

const showModal = () => {
    baseUsageStore.set({
        show: true,
    });
};

// 回调函数中通过store.set更新state
const changeHandler = (v) => {
    baseUsageStore.set({ value: v });
    console.log(`receive value by props 'onChange' : ${v} `);
};
const closeHandler = (v) => {
    baseUsageStore.set({
        value: v,
        show: false,
    });
    console.log(`receive value by props 'onClose' : ${v} `);
};

stories
// 该故事集下所有场景通用的Notes
// 支持Markdown语法或者普通文本
    .addParameters({
        info: {
            text: `
          ## Notes
          - 只适用于** 移动端 **
        `,
        },
    })
    // 添加场景'base usage'
    // State组件为 addon-state 提供，用来模拟外部state变化
    // text,boolean等函数为 addon-knobs提供，提供在 knobs panel中改变props的能力
    .add('base usage', () => {
        const formats = [
            {
                id: 'column1',
                level: 'y-M-d',
                /* eslint-disable */
                label: (date) => <div>{date.getMonth() + 1}月{date.getDate()}号 <span
                    style={{fontSize: 10}}>{getWeek(new Date(), date)}</span></div>,
            }, {
                id: 'column2',
                pattern: 'hh:mm',
                level: 'h-m',
            }
        ];
        const data = array('data', dataArray);
        return (
            <div>
                <button
                    key={1}
                    type="button"
                    onClick={() => showModal()}
                >
    点我测试
                </button>
                <State store={baseUsageStore}>
                    <LimitDateRollerPicker
                        key={2}
                        data={data}
                        show={baseUsageStore.get('show')}
                        value={baseUsageStore.get('value')}
                        formats={formats}
                        onChange={v => changeHandler(v)}
                        onClose={v => closeHandler(v)}
                        onConfirm={v => closeHandler(v)}
                    />
                </State>
            </div>
        );
    });
