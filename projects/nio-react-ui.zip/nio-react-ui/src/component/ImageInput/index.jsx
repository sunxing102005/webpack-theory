import React from 'react';
import PropTypes from 'prop-types';
import loadImage from 'blueimp-load-image';
import Toast from '../Toast';

import './index.scss';

function ImageInput(props) {
    const imageLoad = async (e) => {
        const { accept, maxSize, onChange } = props;
        const input = e.target;
        const { files } = input;
        const {
            type,
            size,
        } = files[0];
        if (!accept.includes(type)) {
            Toast.show('该文件格式不支持');
            return;
        }
        if (size > maxSize) {
            Toast.show('该文件过大');
            return;
        }
        const options = {
            maxWidth: screen.width,
            canvas: true,
            meta: true,
            orientation: true,
            pixelRatio: window.devicePixelRatio,
        };
        const data = await loadImage(files[0], options);
        const image = data.image.toDataURL();
        input.value = '';
        onChange(image);
    };

    const {
        className = '',
        inputTip,
        onInputClick,
        style,
    } = props;

    return (
        <section
            className={`${className} nio-image-input`}
            style={style}
        >
            <input
                type="file"
                onClick={onInputClick}
                onChange={imageLoad}
            />
            <div className="nio-image-input__edit">
                <div className="nio-image-input__icon" />
                <p className="nio-image-input__tip">{inputTip}</p>
            </div>
        </section>
    );
}
ImageInput.propTypes = {
    className: PropTypes.string,
    /** 图片选择样式 */
    style: PropTypes.object,
    /** 图片选择文案 */
    inputTip: PropTypes.string,
    /** 图片格式列表 */
    accept: PropTypes.array,
    /** 图片size大小 */
    maxSize: PropTypes.number,
    /** 图片选择回调 */
    onChange: PropTypes.func,
    /** 图片上传点击操作 */
    onInputClick: PropTypes.func,
};

ImageInput.defaultProps = {
    className: '',
    style: {},
    inputTip: '',
    accept: ['image/jpg', 'image/png', 'image/jpeg', 'image/bmp'],
    maxSize: 15728640,
    onChange: () => {},
    onInputClick: () => {},
};

export default ImageInput;
