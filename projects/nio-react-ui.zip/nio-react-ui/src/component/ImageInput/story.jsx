import React from 'react';
import registerStory from '~storybook/index';
import ImageInput from './index';

const style = {
    wrapperStyle: {
        width: 500,
    },
};
// register story
const {
    stories,
    state,
    knobs,
} = registerStory('ImageInput', style);

const {
    text,
    number,
    array,
} = knobs;

const {
    State,
    Store,
} = state;

const onInputClick = () => {
    console.log('input click');
};

const inputStore = new Store({
    src: '',
});

const onChange = (data) => {
    inputStore.set({
        src: data,
    });
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为图片选择组件
          - ** 注意 **在安卓webview中需要通过设置props : ** onInputClick **方法来调用客户端提供的方法选择图片
        `,
        },
    })
    .add('base usage', () => {
        const inputTip = text('inputTip', '选一张喜欢的照片');
        const maxSize = number('maxSize', 15728640);
        const label = 'accept';
        const defaultValue = ['image/jpg', 'image/png', 'image/jpeg', 'image/bmp'];
        const accept = array(label, defaultValue);
        return (
            <State store={inputStore}>
                <ImageInput
                    key={1}
                    inputTip={inputTip}
                    maxSize={maxSize}
                    accept={accept}
                    onInputClick={onInputClick}
                    onChange={onChange}
                />
                <img
                    key={2}
                    style={{
                        marginTop: 20,
                        height: 200,
                        width: 200,
                        objectFit: 'contain',
                    }}
                    src={inputStore.get('src')}
                    alt=""
                />
            </State>
        );
    });
