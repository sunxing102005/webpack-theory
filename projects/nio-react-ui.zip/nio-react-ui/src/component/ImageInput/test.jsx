import React from 'react';
import loadImage from 'blueimp-load-image';
import ImageInput from './index';
import Toast from '../Toast';

jest.mock('../Toast');
jest.mock('blueimp-load-image');

describe('ImageInput', () => {
    it('should render correctly', () => {
        const wrapper = render(<ImageInput />);
        expect(wrapper).toMatchSnapshot();
    });

    it('should support basic usage', () => {
        const onClick = jest.fn();
        const wrapper = mount(
            <ImageInput
                inputTip="选一张喜欢的照片"
                onInputClick={onClick}
            />,
        );

        wrapper.find('input').at(0).simulate('click');
        expect(onClick).toHaveBeenCalled();

        expect(wrapper.find('.nio-image-input__tip').text()).toEqual('选一张喜欢的照片');
    });
});

describe('ImageInput Default Props', () => {
    it('default props', () => {
        const wrapper = mount(
            <ImageInput />,
        );
        expect(wrapper.find('input').length).toBe(1);
    });
});

describe('ImageInput Unit Test', () => {
    const onChange = jest.fn();
    const componentWrapper = mount(
        <ImageInput
            onChange={onChange}
            maxSize={14}
        />,
    );
    const fileContents = 'file contents';
    Toast.show.mockImplementation(value => value);
    loadImage.mockImplementation(() => Promise.resolve({
        image: {
            toDataURL: jest.fn(() => fileContents),
        },
    }));
    it('should load right type image', () => {
        const file = new Blob([fileContents], { type: 'text/plain' });
        componentWrapper.find('input').simulate('change', { target: { files: [file] } });
        expect(Toast.show).toHaveBeenCalledWith('该文件格式不支持');
    });

    it('should load right size image', () => {
        componentWrapper.setProps({ maxSize: 12 });
        const image = new Blob([fileContents], { type: 'image/png' });
        componentWrapper.find('input').simulate('change', { target: { files: [image] } });
        expect(Toast.show).toHaveBeenLastCalledWith('该文件过大');
    });

    it('call onChange event', () => {
        componentWrapper.setProps({ maxSize: 16 });
        const rightImage = new Blob([fileContents], { type: 'image/png' });
        componentWrapper.find('input').simulate('change', { target: { files: [rightImage] } });
        expect(loadImage).toHaveBeenCalled();
        setTimeout(() => {
            expect(onChange).toHaveBeenCalledWith(fileContents);
        });
    });
});
