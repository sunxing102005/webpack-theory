import React from 'react';
import { render } from 'enzyme';
import Bubble from './index';

describe('Bubble', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <div>
                <Bubble trianglePosition="bottom">
                    <h1>title</h1>
                    <p>content</p>
                    <footer>footer</footer>
                </Bubble>
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });
});
