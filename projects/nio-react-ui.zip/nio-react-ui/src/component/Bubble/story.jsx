import React from 'react';
import registerStory from '~storybook/index';
import Buuble from './index';

const style = {
    wrapperStyle: {
        height: 300,
        width: 300,
    },
};

// register story
const {
    stories,
    knobs,
} = registerStory('Bubble', style);

const {
    text,
} = knobs;

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为气泡样式组件
        `,
        },
    })
    .add('base usage', () => {
        const className = text('className', 'normal-bubble');
        const trianglePosition = text('trianglePosition', 'top');
        return (
            <Buuble className={className} trianglePosition={trianglePosition}>
                <h1>title</h1>
                <p>content </p>
                <footer>footer</footer>
            </Buuble>
        );
    });
