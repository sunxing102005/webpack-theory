import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

import './index.scss';

export default function Bubble(props) {
    const {
        trianglePosition,
        className,
        children,
    } = props;

    return (
        <div className={classnames('nio-bubble', className, trianglePosition)}>
            {children}
        </div>
    );
}

Bubble.defaultProps = {
    children: null,
    className: '',
    trianglePosition: 'top',
};

Bubble.propTypes = {
    /** bubble 组件类名 */
    className: PropTypes.string,
    /** bubble 内部子组件 */
    children: PropTypes.node,
    /** bubble 箭头位置 top | bottom */
    trianglePosition: PropTypes.oneOf([
        'top',
        'bottom',
    ]),
};
