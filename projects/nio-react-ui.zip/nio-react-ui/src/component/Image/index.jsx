import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';

import './index.scss';

class Image extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            error: false,
        };
        this.image = null;
        this.saveImg = this.saveImg.bind(this);
        this.handleLoad = this.handleLoad.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.handleError = this.handleError.bind(this);
    }

    componentDidUpdate(prevProps) {
        const { src } = this.props;
        if (src !== prevProps.src) {
            this.reset();
        }
    }

    reset() {
        this.setState({
            loading: true,
            error: false,
        });
    }

    handleLoad(e) {
        const { onLoad } = this.props;
        this.setState({
            loading: !this.image.complete,
        });
        if (onLoad) {
            onLoad(e);
        }
    }

    handleClick(e) {
        const { onClick } = this.props;
        if (onClick) {
            onClick(e);
        }
    }

    handleError(e) {
        const { onError } = this.props;
        this.setState({
            error: true,
            loading: false,
        });
        if (onError) {
            onError(e);
        }
    }

    saveImg(node) {
        this.image = node;
    }

    render() {
        const {
            imageClassName,
            loadingStyle,
            src,
        } = this.props;
        const { loading, error } = this.state;
        const wrapperClass = this.className(
            'nio-image',
            {
                'nio-image--loading': loading,
                'nio-image--error': error,
            },
        );
        const imageClass = PureComponent.classNames('nio-image__img', imageClassName);
        const style = loading ? this.style(loadingStyle) : this.style();
        return (
            <div
                className={wrapperClass}
                style={style}
            >
                <img
                    alt=""
                    ref={this.saveImg}
                    className={imageClass}
                    src={src}
                    onClick={this.handleClick}
                    onError={this.handleError}
                    onLoad={this.handleLoad}
                />
            </div>
        );
    }
}

Image.defaultProps = {
    imageClassName: '',
    loadingStyle: {},
    src: '',
    onLoad: null,
    onClick: null,
    onError: null,
};

Image.propTypes = {
    /** 该组件内部图片类名 */
    imageClassName: PropTypes.string,
    /* eslint-disable react/forbid-prop-types */
    /** 图片加载中定制样式 */
    loadingStyle: PropTypes.object,
    /** 图片url */
    src: PropTypes.string,
    /** onLoad handler */
    onLoad: PropTypes.func,
    /** onClick handler */
    onClick: PropTypes.func,
    /** onError handler */
    onError: PropTypes.func,
};

export default Image;
