import React from 'react';
import Image from './index';

describe('Image', () => {
    it('should render correctly', () => {
        const wrapper = render(<Image src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png" />);
        expect(wrapper).toMatchSnapshot();
    });

    it('should support basic usage', () => {
        const onLoad = jest.fn();
        const wrapper = mount(
            <Image
                src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png"
                onLoad={onLoad}
            />,
        );
        wrapper.find('img').props().onLoad();
        expect(onLoad).toHaveBeenCalled();

        wrapper.setState({ loading: true });
        expect(wrapper.find('.nio-image--loading').exists()).toEqual(true);
    });
});

describe('Image Default Props', () => {
    it('default props', () => {
        const wrapper = mount(
            <Image />,
        );
        expect(wrapper.prop('imageClassName')).toBe('');
        expect(wrapper.prop('loadingStyle')).toEqual({});
        expect(wrapper.prop('src')).toBe('');
        expect(wrapper.prop('onLoad')).toBeNull();
        expect(wrapper.prop('onClick')).toBeNull();
        expect(wrapper.prop('onError')).toBeNull();
    });
});

describe('Image Unit Test', () => {
    const onLoadMock = jest.fn();
    const onClickMock = jest.fn();
    const onErrorMock = jest.fn();
    const wrapper = mount(
        <Image
            src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png"
            onError={onErrorMock}
            onLoad={onLoadMock}
            onClick={onClickMock}
        />,
    );

    it('click event handlers', () => {
        const img = wrapper.find('img').at(0);
        img.simulate('click');
        expect(onClickMock).toHaveBeenCalledTimes(1);
    });

    it('load event handlers', () => {
        wrapper.find('img').simulate('load');
        expect(onLoadMock).toHaveBeenCalledTimes(1);
    });

    it('call reset event', () => {
        const instance = wrapper.instance();
        const spy = jest.spyOn(instance, 'reset');
        wrapper.setProps({ src: 'https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png' });
        expect(spy).toHaveBeenCalledTimes(0);
        wrapper.setProps({ src: 'XXXXXXXXXX' });
        expect(spy).toHaveBeenCalledTimes(1);
        expect(wrapper.state('loading')).toEqual(true);
        expect(wrapper.state('error')).toEqual(false);
    });

    it('error event handlers', () => {
        wrapper.setProps({ src: 'YYYYYYYY' });
        wrapper.find('img').simulate('error');
        expect(onErrorMock).toHaveBeenCalledTimes(1);
    });
});
