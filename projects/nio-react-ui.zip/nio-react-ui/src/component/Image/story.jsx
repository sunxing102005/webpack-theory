import React from 'react';
import registerStory from '~storybook/index';
import Image from './index';

const style = {
    wrapperStyle: {
        width: 500,
    },
};
// register story
const {
    stories,
    knobs,
} = registerStory('Image', style);

const {
    text,
    object,
} = knobs;


stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为图片UI组件
          - 该组件提供图片load时默认展示，可通过设置props : ** loadingStyle **定制样式
        `,
        },
    })
    .add('base usage', () => {
        const src = text('src', 'https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png');
        return <Image style={{ height: 100, width: 100 }} src={src} />;
    })
    .add('custom style', () => {
        const src = text('src', 'https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png');
        const loadingStyle = object('loadingStyle', {
            backgroundColor: 'red',
        });
        return <Image style={{ height: 100, width: 100 }} src={src} loadingStyle={loadingStyle} />;
    });
