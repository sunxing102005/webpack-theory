import React from 'react';
import registerStory from '~storybook/index';
import Select from './index';

const style = {
    wrapperStyle: {
        height: 100,
    },
};
// register story
const {
    stories,
    state,
    knobs,
} = registerStory('Select', style);

const {
    text,
    boolean,
    object,
} = knobs;

const {
    State,
    Store,
} = state;

const selectStore = new Store({
    value: {},
});

const clickHandler = () => {
    console.log('select 被点击啦啦啦啦～');
};

const selectHandler = (option) => {
    selectStore.set({
        value: option,
    });
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为SelectUI组件
          - ** 注意 **在props : ** chirdren **不为空时设置content、iconName无效
          - ** 注意 **在props : ** loading **为true时，效果等同于disabled
        `,
        },
    })
    .add('base usage', () => {
        const disable = boolean('disable', false);
        const placeholder = text('placeholder', '请选择');
        const options = object('options', [{
            text: 'trwe',
        }, {
            text: 'trew',
            disable: true,
        }, {
            text: 'retret',
            selected: true,
        }]);
        const SelectStyle = object('style', {
            width: 100,
        });

        return (
            <State store={selectStore}>
                <Select
                    disable={disable}
                    placeholder={placeholder}
                    value={selectStore.get('value')}
                    options={options}
                    style={SelectStyle}
                    onSelect={selectHandler}
                    onClick={clickHandler}
                />
            </State>
        );
    });
