import React from 'react';
import PropTypes from 'prop-types';
import { Component } from '~lib';
import Bubble from '../Bubble';

import './index.scss';

export default class Select extends Component {
    constructor(props) {
        super(props);
        this.state = {
            expan: false,
        };
    }

    handleClick(e) {
        const { onClick, disable } = this.props;
        if (!disable) {
            this.setState(prevState => ({
                expan: !prevState.expan,
            }));
            onClick(e);
        }
    }

    select(option = {}) {
        if (option.disable) return;
        const { onSelect } = this.props;
        this.setState(prevState => ({
            expan: !prevState.expan,
        }));
        onSelect(option);
    }

    render() {
        const {
            style,
            options,
            disable,
            placeholder,
            value,
        } = this.props;

        const {
            expan,
        } = this.state;

        const classString = this.className(
            'nio-select',
            {
                'nio-select--disable': disable,
                'nio-select--expan': expan,
            },
        );

        const optionsClassString = Component.classNames(
            'nio-select__options-list',
            {
                'nio-select__options-list--expan': expan,
            },
        );

        /* eslint-disable no-shadow */
        const optionClassString = (disable, selected) => Component.classNames(
            'nio-select__option',
            {
                'nio-select__option--disable': disable,
                'nio-select__option--selected': selected,
            },
        );

        const text = value.text || placeholder;

        return (
            <div className={classString} style={style}>
                <span
                    className="nio-select__picked"
                    onClick={e => this.handleClick(e)}
                >
                    {text}
                </span>
                <Bubble className={optionsClassString}>
                    {
                        options.map(option => (
                            <p
                                className={optionClassString(option.disable, option.selected)}
                                key={option.text}
                                onClick={() => this.select(option)}
                            >
                                {option.text}
                            </p>
                        ))
                    }
                </Bubble>
            </div>
        );
    }
}

Select.propTypes = {
    disable: PropTypes.bool,
    placeholder: PropTypes.string,
    value: PropTypes.shape({
        text: PropTypes.string,
    }),
    onClick: PropTypes.func,
    onSelect: PropTypes.func,
    options: PropTypes.arrayOf(PropTypes.shape({
        text: PropTypes.string,
        disable: PropTypes.bool,
        selected: PropTypes.bool,
    })),
    /* eslint-disable react/forbid-prop-types */
    style: PropTypes.any,
};

Select.defaultProps = {
    disable: false,
    placeholder: '请选择',
    value: {},
    options: [],
    onClick: () => {},
    onSelect: () => {},
    style: {},
};
