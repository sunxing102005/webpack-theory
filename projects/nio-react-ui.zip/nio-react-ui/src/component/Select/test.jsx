import React from 'react';
import Select from './index';

describe('Select', () => {
    it('should render correctly', () => {
        const wrapper = render(<Select
            placeholder="请选择"
            options={[{ text: 'options1' }]}
        />);
        expect(wrapper).toMatchSnapshot();
    });
});


describe('Input Unit Test', () => {
    const onClickMock = jest.fn();
    const onSelectMock = jest.fn();
    const wrapper = mount(
        <Select
            placeholder="请选择"
            onSelect={onSelectMock}
            onClick={onClickMock}
        />,
    );

    it('event handlers', () => {
        const picked = wrapper.find('.nio-select__picked').at(0);
        expect(picked.text()).toEqual('请选择');

        wrapper.setProps({ value: { text: 'options1' } });
        expect(picked.text()).toEqual('options1');

        wrapper.setProps({ disable: true });
        picked.simulate('click');
        expect(onClickMock).toHaveBeenCalledTimes(0);

        wrapper.setProps({ disable: false });
        picked.simulate('click');
        expect(onClickMock).toHaveBeenCalledTimes(1);
        expect(wrapper.state('expan')).toBe(true);
        picked.simulate('click');
        expect(wrapper.state('expan')).toBe(false);

        wrapper.setProps({
            options: [
                {
                    text: 'options1',
                },
                {
                    text: 'options2',
                    disable: true,
                },
                {
                    text: 'options3',
                }],
        });
        const option = wrapper.find('.nio-select__option').at(1);
        option.simulate('click');
        expect(onSelectMock).toHaveBeenCalledTimes(0);
        wrapper.find('.nio-select__option').at(2).simulate('click');
        expect(onSelectMock).toHaveBeenCalledWith({ text: 'options3' });
    });
});
