import React from 'react';
import ImageWithEleList from './index';

const data = [
    {
        url:
      'https://cdn-app.nio.com/user/2019/11/27/df1e3a64-a80a-44ca-8f98-afc57fca3a9f.png?imageView2/2/w/1024',
        title: '2019 NIO Day用户顾问团名单公布',
        key: 1,
    },
    {
        url:
      'https://cdn-app.nio.com/user/2019/11/27/9fcced16-bb7a-42c7-b50c-df38ad7c6b80.jpg?imageView2/2/w/1024',
        title: '2019 NIO Day用户顾问团名单公布',
        key: 2,
    },
    {
        url:
      'https://cdn-app.nio.com/user/2019/11/27/df1e3a64-a80a-44ca-8f98-afc57fca3a9f.png?imageView2/2/w/1024',
        title: '2019 NIO Day用户顾问团名单公布',
        key: 3,
    },
];
describe('ImageWithEleList', () => {
    it('should render correctly', () => {
        const renderItem = item => <div>{item.title}</div>;
        const wrapper = render(
            <ImageWithEleList
                imgHeight="150px"
                imgWidth="150px"
                className="img-list-test"
                itemClassName="img-item-test"
                data={data}
                renderItem={renderItem}
                cols={2}
            />,
        );
        expect(wrapper).toMatchSnapshot();
    });
});
describe('ImageWithEle Event Test', () => {
    it('should call onLoad method', () => {
        const onClick = jest.fn();
        const wrapper = mount(
            <ImageWithEleList
                itemClassName="img-item-test"
                onClickItem={onClick}
                data={data}
            />,
        );
        wrapper
            .find('.img-item-test')
            .at(0)
            .simulate('click');
        expect(onClick).toHaveBeenCalled();
    });
});
describe('ImageWithEleList  Default Props', () => {
    it('default props', () => {
        const wrapper = mount(<ImageWithEleList />);
        expect(wrapper.prop('className')).toBe('');
        expect(wrapper.prop('imgHeight')).toBe('110px');
        expect(wrapper.prop('imgWidth')).toBe('');
        expect(wrapper.prop('data')).toEqual([]);
        expect(wrapper.prop('itemClassName')).toBe('');
        expect(wrapper.prop('onClickItem')).toBeNull();
    });
});
