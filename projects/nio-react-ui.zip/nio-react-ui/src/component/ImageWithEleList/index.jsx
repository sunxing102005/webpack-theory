import React from 'react';
import PropTypes from 'prop-types';
import ImageWithEle from '../ImageWithEle';
import GridLayout from '../GridLayout';
/**
 * 多个带标题图片的表格排列组件
 */
function ImageWithEleList(props) {
    const {
        cols,
        className,
        data,
        onClickItem,
        imgWidth,
        imgHeight,
        renderItem,
        itemClassName,
    } = props;
    return (
        <GridLayout cols={cols} className={className}>
            {data && data.map((item, index) => (
                <ImageWithEle
                    imgHeight={imgHeight}
                    imgWidth={imgWidth}
                    src={item.url}
                    key={index}
                    className={itemClassName}
                    onClick={e => onClickItem(e, item)}
                >
                    {renderItem(item)}
                </ImageWithEle>
            ))}
        </GridLayout>
    );
}
ImageWithEleList.propTypes = {
    /** 表格的列数 */
    cols: PropTypes.number,
    /** 表格的样式类名 */
    className: PropTypes.string,
    /** 表格数据源 */
    data: PropTypes.arrayOf(PropTypes.shape({
        url: PropTypes.string.isRequired,
        title: PropTypes.string,
        key: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.number,
        ]),
    })),
    /** 内层图片宽度 */
    imgWidth: PropTypes.string,
    /** 内层图片高度 */
    imgHeight: PropTypes.string,
    /** 子元素class name */
    itemClassName: PropTypes.string,
    /** 单个图文块，除了图片外元素的render方法 */
    renderItem: PropTypes.func,
    /** 点击单个item事件处理方法 */
    onClickItem: PropTypes.func,
};
ImageWithEleList.defaultProps = {
    cols: 2,
    className: '',
    data: [],
    imgWidth: '',
    imgHeight: '110px',
    itemClassName: '',
    onClickItem: null,
    renderItem: () => {},
};
export default ImageWithEleList;
