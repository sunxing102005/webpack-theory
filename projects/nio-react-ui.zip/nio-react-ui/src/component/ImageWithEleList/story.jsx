import React from 'react';
import registerStory from '~storybook/index';
import ImageWithEleList from './index';

const dataArray = [
    {
        url:
      'https://cdn-app.nio.com/user/2019/11/27/df1e3a64-a80a-44ca-8f98-afc57fca3a9f.png?imageView2/2/w/1024',
        title: '2019 NIO Day用户顾问团名单公布',
        key: 1,
    },
    {
        url:
      'https://cdn-app.nio.com/user/2019/11/27/9fcced16-bb7a-42c7-b50c-df38ad7c6b80.jpg?imageView2/2/w/1024',
        title: '2019 NIO Day用户顾问团名单公布',
        key: 2,
    },
    {
        url:
      'https://cdn-app.nio.com/user/2019/11/27/df1e3a64-a80a-44ca-8f98-afc57fca3a9f.png?imageView2/2/w/1024',
        title: '2019 NIO Day用户顾问团名单公布',
        key: 3,
    },
];
const style = {
    wrapperStyle: {
        width: 500,
    },
};
// register story
const {
    stories,
    knobs,
} = registerStory('ImageWithEleList', style);

const {
    text,
    object,
    number,
} = knobs;

function onClickItem(e, item) {
    console.log('call onclick method', item);
}

const renderItem = item => <div>{item.title}</div>;

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件显示一个文字等元素环绕图片的组件list
          - props : ** cols **设置布局展示列数，** data **接受数组作为数据源
          - props : ** imgHeight **，** imgWidth **设置图片的宽高
          - props : ** renderItem **提供图片外元素的渲染方法
        `,
        },
    })
    .add('base usage', () => {
        const height = text('imgHeight', '245px');
        const width = text('imgWidth', '100%');
        const cols = number('cols', 2);
        const data = object('data', dataArray);

        return (
            <ImageWithEleList
                cols={cols}
                data={data}
                imgHeight={height}
                imgWidth={width}
                renderItem={renderItem}
                onClickItem={onClickItem}
            />
        );
    });
