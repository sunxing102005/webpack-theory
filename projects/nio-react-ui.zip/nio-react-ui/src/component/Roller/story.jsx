import React from 'react';
import registerStory from '~storybook';
import Index from './index';

// register story
const storybook = registerStory('Roller', {
    wrapperStyle: {
        width: '50%',
        height: 500,
        margin: '0 auto',
    },
});

const {
    knobs,
    state,
    stories,
} = storybook;

const {
    text,
    object,
    boolean,
    number,
} = knobs;

const {
    State,
    Store,
} = state;

const baseUsageStore = new Store({
    value: '2',
    data: [{
        value: '1',
        label: '选项一',
    }, {
        value: '2',
        label: '选项二',
    }, {
        value: '3',
        label: '选项三',
    }, {
        value: '4',
        label: '选项四',
    }, {
        value: '5',
        label: (<span>use react element as label</span>),
    }],
});

const customStyleStore = new Store({
    value: '1',
});

// 回调函数中通过store.set更新state
const changeHandler = (value, store) => {
    store.set({ value });
    console.log(`receive value by props 'onChange' : ${value} \n please update props 'value' here to make selected option change actually`);
};
const closeHandler = (value, store) => {
    store.set({ value });
    console.log(`receive value by props 'onClose' : ${value} \n this value is actually the selected one when closing Roller`);
};

stories
// 该故事集下所有场景通用的Notes
// 支持Markdown语法或者普通文本
    .addParameters({
        info: {
            text: `
          ## Notes
          - 只适用于** 移动端 **
          - 必须更新props : ** value **的值，来改变组件选中选项的状态
          - wrapper height必须大于 numberToShow * optionSize (default as 180px)
          - 请在场景**base usage**下，使用devtool中的**device mode**查看组件使用效果
        `,
        },
    })
    // 添加场景'base usage'
    // State组件为 addon-state 提供，用来模拟外部state变化
    // text,boolean等函数为 addon-knobs提供，提供在 knobs panel中改变props的能力
    .add('base usage', () => {
        const title = text('title', '');
        const show = boolean('show', true);
        return (
            <State store={baseUsageStore}>
                <Index
                    data={baseUsageStore.get('data')}
                    // 通过store.get获取state
                    value={baseUsageStore.get('value')}
                    title={title}
                    show={show}
                    onChange={(v) => {
                        changeHandler(v, baseUsageStore);
                    }}
                    onClose={(v) => {
                        closeHandler(v, baseUsageStore);
                    }}
                />
            </State>
        );
    })
    .add('custom style', () => {
        const options = [{
            value: '1',
            label: '选项一',
        }, {
            value: '2',
            label: '选项二',
        }, {
            value: '3',
            label: '选项三',
        }, {
            value: '4',
            label: '选项四',
        }, {
            value: '5',
            label: '选项五',
        }, {
            value: '6',
            label: '选项六',
        }, {
            value: '7',
            label: '选项七',
        }];
        const numberToShow = number('numberToShow', 5);
        const headerHeight = number('headerHeight', 45);
        const optionSize = number('optionSize', 50);
        const wrapperStyle = object('wrapperStyle', {
            background: 'grey',
        });
        const wrapperClass = text('wrapperClass', 'my-wrapper-class');
        const optionStyle = object('optionStyle', {
            color: 'red',
        });
        const optionSelectedStyle = object('optionSelectedStyle', {
            color: 'blue',
        });
        const optionClass = text('optionClass', 'my-option-class');
        return (
            <State store={customStyleStore}>
                <Index
                    show
                    title="title"
                    data={options}
                    value={customStyleStore.get('value')}
                    headerHeight={headerHeight}
                    optionSize={optionSize}
                    numberToShow={numberToShow}
                    wrapperClass={wrapperClass}
                    wrapperStyle={wrapperStyle}
                    optionClass={optionClass}
                    optionStyle={optionStyle}
                    optionSelectedStyle={optionSelectedStyle}
                    onChange={(v) => {
                        changeHandler(v, customStyleStore);
                    }}
                    onClose={(v) => {
                        closeHandler(v, customStyleStore);
                    }}
                />
            </State>
        );
    });
