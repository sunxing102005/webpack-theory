import React from 'react';
import PropTypes from 'prop-types';
import BScroll from 'better-scroll';
import { Component } from '~lib';

import './index.scss';

const middle = (n, a, b) => {
    const max = Math.max(a, b);
    const min = Math.min(a, b);
    return Math.min(Math.max(n, min), max);
};

const ignoreKey = {
    onChange: true,
    onClose: true,
};

/**
 * 判断是否需要重新渲染
 * @param cur{object} current props
 * @param next{object} next props
 * @return {boolean}
 */
const shouldUpdate = (cur, next) => {
    const curKeys = Object.keys(cur);
    const nextKeys = Object.keys(next);
    if (curKeys.length !== nextKeys.length) {
        return true;
    }
    let k = null;
    for (let i = 0; i < nextKeys.length; i += 1) {
        // current key
        k = nextKeys[i];
        if (!ignoreKey[k] && cur[k] !== next[k]) {
            return true;
        }
    }
    return true;
};

/**
 * 判断是否需要re-render Better Scroll实例
 * @param cur{object} current props
 * @param next{object} next props
 * @return {boolean}
 */
const shouldRenderBScroll = (cur, next) => {
    const keys = [
        'numberToShow',
        'headerHeight',
        'optionSize',
        'data',
    ];
    for (let i = 0; i < keys.length; i += 1) {
        if (cur[keys[i]] !== next[keys[i]]) {
            return true;
        }
    }
    return false;
};

const CHANGE_EVENT_TYPE = {
    VALUE_NOT_FOUNT: 'VALUE_NOT_FOUNT',
    SCROLL_END: 'SCROLL_END',
    SCROLL_CANCEL: 'SCROLL_CANCEL',
};

class Roller extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedIndex: this.calIndexByValue(props.data, props.value),
        };

        this.curY = null;
        this.needRefresh = false;

        this.initDom = this.initDom.bind(this);
        this.updateSelectedIndex = this.updateSelectedIndex.bind(this);
        this.calIndexByPosition = this.calIndexByPosition.bind(this);
        this.calIndexByValue = this.calIndexByValue.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        const { value, data, show } = this.props;
        let index;

        // 隐藏时调用
        if (nextProps.show === false && show === true) {
            if (this.scroll.isInTransition || this.scroll.isAnimating) {
                this.scroll.stop();
            }
            index = this.calIndexByPosition(this.curY);
            if (nextProps.data && nextProps.data[index] && nextProps.data[index].value !== undefined) {
                this.handleClose(nextProps.data[index].value, index);
            }
        }

        if (nextProps.value === value && nextProps.data === data) {
            return;
        }

        // if style or data has changed, need to re-render BScroll instance
        this.needRefresh = shouldRenderBScroll(this.props, nextProps);

        index = this.calIndexByValue(nextProps.data, nextProps.value);
        this.updateSelectedIndex(index);
    }

    shouldComponentUpdate(nextProps) {
        const { show } = this.props;
        return show !== nextProps.show || (nextProps.show && shouldUpdate(this.props, nextProps));
    }

    componentDidUpdate() {
        if (this.needRefresh) {
            this.scroll.refresh();
            this.needRefresh = false;
        }
    }

    getRollerStyle() {
        const { optionSize, numberToShow, show } = this.props;
        return {
            height: optionSize * numberToShow,
            overflow: 'hidden',
            display: show ? 'block' : 'none',
        };
    }

    /**
     * 获取滚动区域样式
     * @return {{marginTop: number} & Index.props.wrapperStyle}
     */
    getWheelWrapperStyle() {
        const { numberToShow, optionSize, wrapperStyle } = this.props;
        return Object.assign({
            marginTop: (numberToShow - 1) / 2 * optionSize,
        }, wrapperStyle);
    }

    /**
     * 获取滚动选项样式
     * @param isSelected 是否被选中
     * @return {*}
     */
    getWheelOptionStyle(isSelected = false) {
        const { optionStyle = {}, optionSelectedStyle = {}, optionSize } = this.props;
        const combinedOptionStyle = isSelected ? Object.assign({}, optionStyle, optionSelectedStyle) : optionStyle;
        return Object.assign({}, combinedOptionStyle, { height: optionSize });
    }

    /**
     * 获取遮罩层样式
     * @return {{top: number, height: Index.props.optionSize}}
     */
    getMaskStyle() {
        const { numberToShow, optionSize } = this.props;
        return {
            top: (numberToShow - 1) / 2 * optionSize,
            height: optionSize,
        };
    }

    getHeaderStyle() {
        const {
            headerHeight,
            optionSize,
        } = this.props;
        const h = headerHeight || optionSize;
        return {
            textAlign: 'center',
            lineHeight: `${h}px`,
            height: h,
            width: '100%',
        };
    }

    handleClose(value, index) {
        const { onClose } = this.props;
        if (onClose && typeof onClose === 'function') {
            onClose(value, index);
        }
    }

    handleChange(type, value, index) {
        const { value: curValue, onChange } = this.props;
        if (curValue !== value && onChange && typeof onChange === 'function') {
            onChange(value, index);
        }
    }

    updateSelectedIndex(index) {
        this.scroll.wheelTo(index);
        this.setState({ selectedIndex: index });
    }

    calIndexByPosition(y) {
        const { optionSize, data = [] } = this.props;
        return middle(Math.round(Math.abs(Number(y)) / Number(optionSize)), data.length - 1, 0);
    }

    calIndexByValue(data, value) {
        const index = data.findIndex(item => item.value === value);
        if (index === -1) {
            this.handleChange(CHANGE_EVENT_TYPE.VALUE_NOT_FOUNT, (data[0] || { value: '' }).value, 0);
            return 0;
        }
        return index;
    }

    initDom(dom) {
        this.dom = dom;

        // 组件隐藏时
        if (dom === null) {
            return;
        }
        const { selectedIndex } = this.state;

        this.scroll = new BScroll(dom, {
            scrollY: true,
            probeType: 3,
            wheel: {
                selectedIndex,
                rotate: 0,
                adjustTime: 10,
                wheelWrapperClass: 'nio-roller__wrapper',
                wheelItemClass: 'nio-roller__option',
            },
        });
        this.scroll.on('scrollEnd', () => {
            const { data } = this.props;
            const index = this.scroll.getSelectedIndex();
            this.handleChange(CHANGE_EVENT_TYPE.SCROLL_END, data[index].value, index);
        });

        this.scroll.on('scrollCancel', () => {
            const index = this.calIndexByPosition(this.curY);
            const { data } = this.props;

            // 防止data为空时报错
            if (data[index] && data[index].value !== undefined) {
                this.handleChange(CHANGE_EVENT_TYPE.SCROLL_CANCEL, data[index].value, index);
            }
        });

        this.scroll.on('scroll', (pos) => {
            this.curY = pos.y;
        });
    }

    render() {
        const {
            title,
            optionClass,
            wrapperClass,
            data,
        } = this.props;
        const { selectedIndex } = this.state;
        const wrapperClassStr = Component.classNames('nio-wheel__wrapper', wrapperClass);
        const optionBaseClassStr = Component.classNames('nio-wheel__option', optionClass);
        return (
            <div className="nio-roller__container" style={{ position: 'relative' }}>
                {title && (
                    <div className="nio-roller__header" style={this.getHeaderStyle()}>{title}</div>
                )}
                <div ref={this.initDom} className="nio-roller" style={this.getRollerStyle()}>
                    <div className={wrapperClassStr} style={this.getWheelWrapperStyle()}>
                        {data.map((option, index) => {
                            const { label, value } = option;
                            const isSelected = index === selectedIndex;
                            const optionClassStr = Component.classNames(optionBaseClassStr, { 'nio-wheel__option--selected': isSelected });
                            return (
                                <div
                                    className={optionClassStr}
                                    key={`${value}`}
                                    style={this.getWheelOptionStyle(isSelected)}
                                >
                                    {label}
                                </div>
                            );
                        })}
                    </div>
                    <div className="nio-roller__mask" style={this.getMaskStyle()} />
                </div>
            </div>
        );
    }
}

Roller.defaultProps = {
    data: [],
    onChange: null,
    onClose: null,
    numberToShow: 3,
    title: '',
    headerHeight: 60,
    optionSize: 60,
    show: true,
    optionClass: '',
    optionStyle: {},
    optionSelectedStyle: {},
    wrapperClass: '',
    wrapperStyle: {},
};

Roller.propTypes = {
    data: PropTypes.arrayOf(
        PropTypes.shape({
            value: PropTypes.any.isRequired,
            label: PropTypes.oneOfType([
                PropTypes.string,
                PropTypes.element,
            ]).isRequired,
        }),
    ),
    /** current value which is selected */
    /* eslint-disable react/forbid-prop-types */
    value: PropTypes.any.isRequired,
    /** callback with parameter **value** */
    onChange: PropTypes.func,
    /** callback with parameter **value** */
    onClose: PropTypes.func,
    /** indicating how many option should be render into view */
    numberToShow: PropTypes.number,
    /** title for this roller */
    title: PropTypes.string,
    /** height for title area */
    headerHeight: PropTypes.number,
    /** height for each option */
    optionSize: PropTypes.number,
    /** indicating whether Roller should render or not */
    show: PropTypes.bool,
    /** class name for option */
    optionClass: PropTypes.string,
    /** inline style for option */
    /* eslint-disable react/forbid-prop-types */
    optionStyle: PropTypes.object,
    /** inline style for selected option */
    /* eslint-disable react/forbid-prop-types */
    optionSelectedStyle: PropTypes.object,
    /** class name for wrapper */
    wrapperClass: PropTypes.string,
    /** inline style for wrapper */
    /* eslint-disable react/forbid-prop-types */
    wrapperStyle: PropTypes.any,
};

export default Roller;
