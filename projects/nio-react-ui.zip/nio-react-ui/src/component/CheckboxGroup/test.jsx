import React from 'react';
import CheckboxGroup from './index';
import Checkbox from '../Checkbox';

describe('CheckboxGroup Snapshot', () => {
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
    ];

    it('render correctly', () => {
        // Toast should not be rendered
        const wrapper = render(
            <CheckboxGroup
                items={items}
            />,
        );
        expect(wrapper).toMatchSnapshot();

        // Toast should be rendered
        const wrapperWithToast = render(
            <CheckboxGroup
                autoToast
                items={items}
            />,
        );
        expect(wrapperWithToast).toMatchSnapshot();
    });
});

describe('CheckboxGroup Default Props', () => {
    const wrapper = mount(
        <CheckboxGroup />,
    );
    expect(wrapper.prop('items')).toEqual([]);
    expect(wrapper.prop('values')).toEqual([]);
    expect(wrapper.prop('onChange')).toBeNull();
    expect(wrapper.prop('roundIcon')).toBe(false);
    expect(wrapper.prop('disabled')).toBe(false);
    expect(wrapper.prop('autoToast')).toBe(false);
    expect(wrapper.prop('iconClass')).toBe('');
    expect(wrapper.prop('checkboxClass')).toBe('');
    expect(wrapper.prop('maxSelect')).toBe(1);
});

describe('CheckboxGroup Unit Test', () => {
    // do not modify these test data
    // To push new items is allowed
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
        {
            value: 3,
            disabled: false,
            content: 'item 3',
        },
    ];

    const onChangeMock = jest.fn();
    const wrapper = mount(
        <CheckboxGroup
            values={[1]}
            maxSelect={1}
            items={items}
            disabled={false}
            autoToast={false}
            onChange={onChangeMock}
        />,
    );

    const checkbox0 = wrapper.find(Checkbox).at(0);
    const checkbox1 = wrapper.find(Checkbox).at(1);
    const checkbox2 = wrapper.find(Checkbox).at(2);

    it('handle correctly', () => {
        expect(checkbox0.props().checked).toBe(true);
        expect(checkbox0.props().disabled).toBe(false);
        expect(checkbox1.props().checked).toBe(false);
        expect(checkbox1.props().disabled).toBe(true);
        expect(checkbox2.props().checked).toBe(false);
        expect(checkbox2.props().disabled).toBe(false);

        // onChange shouldn't be called when selecting new value with values.length === maxSelect
        checkbox2.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(0);
        wrapper.setProps({ autoToast: true });
        checkbox2.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(0);

        // select item in disabled mode shouldn't fire onChange
        wrapper.setProps({ disabled: true });
        checkbox0.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(0);
        wrapper.setProps({ disabled: false });
        // cancel select
        checkbox0.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(1);
        expect(onChangeMock).toHaveBeenCalledWith([]);

        wrapper.setProps({ values: [] });

        // disable item shouldn't not fire onChange
        checkbox1.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(1);

        // select item
        checkbox2.simulate('click');
        expect(onChangeMock).toHaveBeenCalledTimes(2);
        expect(onChangeMock).toHaveBeenCalledWith([3]);
    });

    it('toast correctly', (done) => {
        wrapper.setProps({
            maxSelect: 1,
            values: [1],
            autoToast: false,
        });
        checkbox2.simulate('click');
        wrapper.setProps({ autoToast: true });
        checkbox2.simulate('click');
        setTimeout(() => {
            done();
        }, 2000);
    });
});
