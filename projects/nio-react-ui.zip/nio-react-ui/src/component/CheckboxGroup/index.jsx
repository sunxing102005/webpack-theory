import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import Checkbox from '../Checkbox';
import Toast from '../Toast';

class CheckboxGroup extends PureComponent {
    constructor(props) {
        super(props);
        this.renderChild = this.renderChild.bind(this);
        this.onSelect = this.onSelect.bind(this);
    }

    onSelect(value) {
        const {
            onChange,
            values,
            maxSelect,
            autoToast,
        } = this.props;
        if (!onChange) {
            return;
        }
        const valueIndex = values.findIndex(v => v === value);
        const hasSelected = valueIndex > -1;

        if (!hasSelected && values.length >= maxSelect) {
            // 达到选中数量限制且尝试选中新项
            if (autoToast) {
                Toast.show(`最多只能选${maxSelect}项！`);
            }
            return;
        }

        const newValues = [...values];
        if (hasSelected) {
            // 取消选中
            newValues.splice(valueIndex, 1);
        } else {
            // 选中
            newValues.push(value);
        }
        onChange(newValues);
    }

    renderChild(items) {
        const {
            values,
            checkboxClass,
            iconClass,
            roundIcon,
            disabled: globalDisabled,
        } = this.props;
        return items.map((radioItem) => {
            const { value, content, disabled: itemDisabled } = radioItem;
            const checked = !!values.find(v => value === v);
            return (
                <Checkbox
                    roundIcon={roundIcon}
                    className={checkboxClass}
                    iconClass={iconClass}
                    key={String(value)}
                    value={value}
                    checked={checked}
                    disabled={globalDisabled || itemDisabled}
                    onClick={(e, v) => {
                        this.onSelect(v);
                    }}
                >
                    {content}
                </Checkbox>
            );
        });
    }

    render() {
        const { items } = this.props;
        const cls = this.className('nio-checkbox-group');

        return (
            <div className={cls}>
                {this.renderChild(items)}
            </div>
        );
    }
}

CheckboxGroup.defaultProps = {
    values: [],
    onChange: null,
    roundIcon: false,
    items: [],
    disabled: false,
    checkboxClass: '',
    iconClass: '',
    maxSelect: 1,
    autoToast: false,
};

CheckboxGroup.propTypes = {
    /** 内部checkbox class */
    checkboxClass: PropTypes.string,
    /** 内部checkbox icon class */
    iconClass: PropTypes.string,
    /** 是否使用圆角icon */
    roundIcon: PropTypes.bool,
    /** 当前组件选中值 */
    values: PropTypes.arrayOf(
        PropTypes
            .oneOfType([
                PropTypes.string,
                PropTypes.number,
            ]),
    ),
    /** 选中值变化回调 onChange(newValues) */
    onChange: PropTypes.func,
    /** 待渲染item */
    items: PropTypes.arrayOf(
        PropTypes.shape({
            value: PropTypes
                .oneOfType([
                    PropTypes.string,
                    PropTypes.number,
                ])
                .isRequired,
            disabled: PropTypes.bool,
            iconClass: PropTypes.string,
        }),
    ),
    /** 为true时禁用所有checkbox */
    disabled: PropTypes.bool,
    /** 最多选中数量 */
    maxSelect: PropTypes.number,
    /** 超过最多数目时是否需要自动提示 */
    autoToast: PropTypes.bool,
};

export default CheckboxGroup;
