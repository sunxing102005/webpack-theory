import React from 'react';
import registerStory from '~storybook';
import CheckboxGroup from './index';
import Image from '../Image';

// register story
const {
    stories,
    state,
    knobs,
} = registerStory('CheckboxGroup');

const {
    boolean,
    number,
} = knobs;

const {
    State,
    Store,
} = state;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 传入Item数组，快速渲染checkbox列表
          - 提供参数控制列表行为
          - item.value 不能重复
        `,
        },
    });

const store = new Store({
    values: [1],
});

const onChange = (values) => {
    console.log('new values:', values);
    store.set({ values });
};

story.add('base usage', () => {
    const roundIcon = boolean('roundIcon', true);
    const autoToast = boolean('autoToast', false);
    const disabled = boolean('disabled', false);
    const maxSelect = number('maxSelect', 1);
    const items = [
        {
            value: 1,
            disabled: false,
            content: 'item 1',
        },
        {
            value: 2,
            disabled: true,
            content: 'item 2',
        },
        {
            value: 3,
            disabled: false,
            content: 'item 3',
        },
        {
            value: 4,
            disabled: false,
            content: <Image src="https://cdn-app.nio.com/user/2019/4/10/30467070-7bfc-4399-950c-8c5b0c624d46.jpg" />,
        },
    ];
    return (
        <State store={store}>
            <CheckboxGroup
                disabled={disabled}
                maxSelect={maxSelect}
                autoToast={autoToast}
                items={items}
                roundIcon={roundIcon}
                onChange={onChange}
            />
        </State>
    );
});
