import React from 'react';
import {
    render,
    shallow,
} from 'enzyme';
import Button from './index';
import Icon from '../Icon';

describe('Button', () => {
    it('should render correctly', () => {
        const wrapper = render(
            <div>
                <Button iconName="icon-text">button</Button>
                <Button iconName="icon-text"><span>button</span></Button>
                <Button iconName="icon-text" disable />
                <Button iconName="icon-text" loading />
            </div>,
        );
        expect(wrapper).toMatchSnapshot();
    });

    it('render children', () => {
        const wrapper = shallow((
            <Button iconName="icon-collect">
                <span className="children-span">555</span>
            </Button>
        ));
        expect(wrapper.exists(Icon)).toEqual(true);
        expect(wrapper.exists('span.nio-button-text')).toEqual(false);
        expect(wrapper.exists('span.children-span')).toEqual(true);
        // const wrapperError = shallow((
        //     <Button iconName="icon-collect">
        //         <span className="children-span">555</span>
        //         <span>23</span>
        //     </Button>
        // ));
    });

    it('simulates click events', () => {
        const onClick = jest.fn();
        const wrapper = shallow(
            <Button onClick={onClick} />,
        );
        wrapper.find('.nio-button').simulate('click');
        expect(onClick).toHaveBeenCalled();

        wrapper.setProps({ disable: true });
        wrapper.find('.nio-button').simulate('click');
        expect(onClick).toHaveBeenCalledTimes(1);

        wrapper.setProps({ loading: true });
        wrapper.find('.nio-button').simulate('click');
        expect(onClick).toHaveBeenCalledTimes(1);
    });
});
