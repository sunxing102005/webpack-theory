import React from 'react';
import PropTypes from 'prop-types';
import { PureComponent } from '~lib';
import Icon from '../Icon';

import './index.scss';

class Button extends PureComponent {
    handleClick(e) {
        const { onClick, disable, loading } = this.props;
        if (onClick && !disable && !loading) {
            onClick(e);
        }
    }

    render() {
        const {
            roundedCorner,
            loading,
            disable,
            iconPosition,
            size,
            skin,
            iconName,
            children,
            loadingText,
        } = this.props;

        const classString = this.className(
            'nio-button',
            {
                'nio-button--disable': disable,
                'nio-button--loading': loading,
                'nio-button--rounded-corner': roundedCorner,
                [`nio-button--${skin}`]: !!skin,
                [`nio-button--size-${size}`]: !!size,
                [`nio-button--${iconPosition}`]: !!iconPosition,
            },
        );

        const iconClass = loading ? 'icon-loading' : iconName;

        if (React.Children.count(children) > 1) {
            throw new Error('Button:length of children should be less than 1');
        }

        return (
            <button
                type="button"
                style={this.style()}
                className={classString}
                onClick={e => this.handleClick(e)}
            >
                <React.Fragment>
                    {iconClass ? (
                        <Icon
                            className="nio-button__icon"
                            name={iconClass}
                            roll={loading}
                        />
                    ) : null}
                    {loading && loadingText ? loadingText : children}
                </React.Fragment>
            </button>
        );
    }
}

Button.propTypes = {
    /** 按钮大小选择 可选 normal middle small */
    size: PropTypes.oneOf(['normal', 'middle', 'small']),
    /** 是否加载中 */
    loading: PropTypes.bool,
    /** 加载中文字 */
    loadingText: PropTypes.string,
    /** 按钮类型控制 */
    skin: PropTypes.oneOf([
        'bg-nio-blue',
        'bg-nio-white',
        'bg-nio-light-blue',
        'bg-nio-alert',
        'border-nio-blue',
        'border-nio-grey']),
    /** 按钮是否圆角 */
    roundedCorner: PropTypes.bool,
    /** 按钮是否禁用 */
    disable: PropTypes.bool,
    /** 按钮点击事件 */
    onClick: PropTypes.func,
    /** 按钮Icon名称，参考Icon组件 */
    iconName: PropTypes.string,
    /** 按钮位置，可选icon-before、icon-behind、icon-top、icon-bottom */
    iconPosition: PropTypes.oneOf([
        'icon-before',
        'icon-behind',
        'icon-top',
        'icon-bottom',
    ]),
    /** 内部子组件,只能是单个元素 */
    children: PropTypes.node,
};

Button.defaultProps = {
    /** 按钮大小选择 */
    size: 'normal',
    /** 是否加载中 */
    loading: false,
    /** 加载中文字 */
    loadingText: '',
    /** 按钮样式类型 */
    skin: 'bg-nio-blue',
    /** 按钮是否圆角 */
    roundedCorner: true,
    /** 按钮是否禁用 */
    disable: false,
    /** 按钮点击事件 */
    onClick: null,
    /** 按钮Icon名称，参考Icon组件 */
    iconName: '',
    /** 按钮Icon位置 */
    iconPosition: 'icon-before',
    children: null,
};

export default Button;
