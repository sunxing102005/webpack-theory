import React from 'react';
import registerStory from '~storybook/index';
import Button from './index';

const style = {
    wrapperStyle: {
        height: 100,
    },
};
// register story
const {
    stories,
    knobs,
} = registerStory('Button', style);

const {
    text,
    boolean,
    object,
    select,
} = knobs;

const clickHandler = () => {
    console.log('button 被点击啦啦啦啦～');
};

stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为按钮UI组件
          - ** 注意 **在props : ** chirdren **不为空时设置content、iconName无效
          - ** 注意 **在props : ** loading **为true时，效果等同于disabled
        `,
        },
    })
    .add('base usage', () => {
        const sizeOptions = {
            normal: 'normal',
            middle: 'middle',
            small: 'small',
        };
        const size = select('size', sizeOptions, 'normal');
        const skinOptions = {
            blue: 'bg-nio-blue',
            white: 'bg-nio-white',
            lightBlue: 'bg-nio-light-blue',
            alert: 'bg-nio-alert',
            borderBlue: 'border-nio-blue',
            borderGrey: 'border-nio-grey',
        };
        const skin = select('skin', skinOptions, 'bg-nio-blue');
        const disable = boolean('disable', false);
        const roundedCorner = boolean('roundedCorner', true);
        const loading = boolean('loading', false);
        const content = text('content', 'button');
        const loadingText = text('loadingText', 'loading');
        const iconName = text('iconName', 'icon-arrow');
        const iconPositionOptions = {
            before: 'icon-before',
            behind: 'icon-behind',
            top: 'icon-top',
            bottom: 'icon-bottom',
        };
        const iconPosition = select('iconPosition', iconPositionOptions, 'icon-behind');
        const buttonStyle = object('style', {
            width: 100,
        });
        return (
            <Button
                size={size}
                skin={skin}
                disable={disable}
                roundedCorner={roundedCorner}
                loading={loading}
                loadingText={loadingText}
                iconName={iconName}
                iconPosition={iconPosition}
                style={buttonStyle}
                onClick={clickHandler}
            >
                <span>{content}</span>
            </Button>
        );
    });
