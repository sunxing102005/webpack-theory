import React from 'react';
import PropTypes from 'prop-types';
import RcDialog from 'rc-dialog';

import './index.scss';

/**
 *
 * @property{boolean} visible, 显示/隐藏
 * @property{element} content,(optional) 内容
 * @property{string} title,(optional) 标题
 * @property{object} confirmButton,(optional) 确认按钮 props: text , handleClick
 * @property{object} cancelButton,(optional) 取消按钮 props: text , handleClick
 */
export default function Confirm(props) {
    const {
        content = '',
        title = '',
        visible = false,
        confirmButton,
        cancelButton,
    } = props;

    return (
        <RcDialog
            closable={false}
            wrapClassName="center"
            className="nio-dialog"
            animation="zoom"
            maskAnimation="fade"
            bodyStyle={{ padding: 0 }}
            maskStyle={{ position: 'fixed', height: '100vh' }}
            visible={visible}
        >
            <div className="nio-dialog__content">
                {title && <h2 className="confirm__title">{title}</h2>}
                <div className="confirm__content"><p>{content}</p></div>
                <div className="confirm__button">
                    { cancelButton
                        && (
                            <button
                                type="button"
                                className="confirm__button--cancel"
                                style={cancelButton.style || {}}
                                onClick={e => cancelButton.handleClick(e)}
                            >
                                {cancelButton.text}
                            </button>
                        )
                    }
                    { confirmButton && (
                        <button
                            className="confirm__button--confirm"
                            type="button"
                            style={confirmButton.style || {}}
                            onClick={e => confirmButton.handleClick(e)}
                        >
                            {confirmButton.text}
                        </button>
                    ) }
                </div>
            </div>
        </RcDialog>
    );
}

Confirm.propTypes = {
    /** 显示与隐藏 */
    visible: PropTypes.bool,
    /** 弹框内容 */
    content: PropTypes.oneOfType([
        PropTypes.element,
        PropTypes.string,
    ]),
    /** 弹框标题 */
    title: PropTypes.string,
    /** 确认按钮 */
    confirmButton: PropTypes.shape({
        style: PropTypes.any,
        handleClick: PropTypes.func,
        text: PropTypes.string,
    }),
    /** 取消按钮 */
    cancelButton: PropTypes.shape({
        style: PropTypes.any,
        handleClick: PropTypes.func,
        text: PropTypes.string,
    }),
};

Confirm.defaultProps = {
    /** 显示与隐藏 */
    visible: false,
    /** 弹框内容 */
    content: '',
    /** 弹框标题 */
    title: '',
    confirmButton: {
        text: '确认',
        style: {},
        handleClick: () => {},
    },
    cancelButton: {
        text: '取消',
        style: {},
        handleClick: () => {},
    },
};
