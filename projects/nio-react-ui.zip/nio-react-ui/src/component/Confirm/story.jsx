import React from 'react';
import registerStory from '~storybook';
import Confirm from './index';
import Image from '../Image';

// register story
const {
    stories,
    state,
    knobs,
} = registerStory('Confirm');

const {
    text,
    object,
} = knobs;

const {
    State,
    Store,
} = state;

const story = stories
    .addParameters({
        info: {
            text: `
          ## Notes
          - 该组件为完全受控组件，需要通过设置props中visible控制显示和消失
          - 底部button不需要显示时需要显示设置props对应项为null
        `,
        },
    });

const confirmStore = new Store({
    visible: false,
});

const confirmClick = (e) => {
    console.log('handle click', e, 'value: cancel');
    confirmStore.set({
        visible: !confirmStore.get('visible'),
    });
};

const showConfirm = () => {
    confirmStore.set({
        visible: true,
    });
};

story.add('base usage', () => {
    const title = text('title', '我是标题');
    const content = text('content', '我是confirm内容');
    const confirmButton = object('confirmButton', {
        text: '确认',
        handleClick: confirmClick,
    });
    const cancelButton = object('cancelButton', null);
    return (
        <State store={confirmStore}>
            <button
                type="button"
                onClick={() => showConfirm()}
            >
点我测试
            </button>
            <Confirm
                title={title}
                content={content}
                visible={confirmStore.get('visible')}
                confirmButton={confirmButton}
                cancelButton={cancelButton}
            />
        </State>
    );
}).add('custom style', () => {
    const title = text('title', '我是测试标题');
    const image = <Image src="https://www.nio.com/themes/nioweb/images/nio-favicon-zh-hans.png" />;
    const confirmButton = object('confirmButton', {
        text: '确认',
        handleClick: confirmClick,
    });
    const cancelButton = object('cancelButton', {
        text: '取消',
        handleClick: confirmClick,
    });

    return (
        <State store={confirmStore}>
            <button
                type="button"
                onClick={() => showConfirm()}
            >
点我测试
            </button>
            <Confirm
                title={title}
                content={image}
                visible={confirmStore.get('visible')}
                confirmButton={confirmButton}
                cancelButton={cancelButton}
            />
        </State>
    );
});
