import React from 'react';
import Confirm from './index';

describe('Confirm', () => {
    it('should render correctly', () => {
        const wrapper = render(<Confirm
            visible
            content="我是内容"
            title="我是标题"
        />);
        expect(wrapper).toMatchSnapshot();
    });
});


describe('Confirm Unit Test', () => {
    const onCancelMock = jest.fn();
    const onConfirmMock = jest.fn();
    const wrapper = mount(
        <Confirm
            visible
            content="我是内容"
            title="我是标题"
        />,
    );

    it('event handlers', () => {
        const title = wrapper.find('.confirm__title').at(0);
        expect(title.text()).toEqual('我是标题');

        const content = wrapper.find('.confirm__content').at(0);
        expect(content.text()).toEqual('我是内容');

        wrapper.setProps({ title: '' });
        expect(wrapper.exists('.confirm__title')).toBe(false);

        const confirm = wrapper.find('.confirm__button--confirm');
        confirm.simulate('click');
        expect(onConfirmMock).toHaveBeenCalledTimes(0);

        wrapper.setProps({
            confirmButton: {
                text: '确认',
                handleClick: onConfirmMock,
            },
            cancelButton: {
                text: '取消',
                handleClick: onCancelMock,
            },
        });
        confirm.simulate('click');
        expect(onConfirmMock).toHaveBeenCalledTimes(1);

        wrapper.find('.confirm__button--cancel').simulate('click');
        expect(onCancelMock).toHaveBeenCalledTimes(1);

        const wrapper1 = mount(
            <Confirm
                visible
                content="我是内容"
                title="我是标题"
                confirmButton={null}
            />,
        );
        expect(wrapper1.exists('.confirm__button--confirm')).toBe(false);
    });
});
