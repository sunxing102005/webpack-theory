/**
 * xss过滤:使用html转义字符替换特殊字符
 * @param str{string} 待处理字符串
 * @return {string} 替换过滤后的字符串
 */
const xssFilter = (str) => {
    if (!str || typeof str !== 'string') {
        return '';
    }

    const specCharMap = {
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
    };

    return [...str]
        .reduce((res, char) => {
            /* eslint-disable no-param-reassign */
            res += specCharMap[char] ? specCharMap[char] : char;
            return res;
        }, '');
};

// TODO: 加入其它export时，删除eslint-disable
/* eslint-disable import/prefer-default-export */
export {
    xssFilter,
};
