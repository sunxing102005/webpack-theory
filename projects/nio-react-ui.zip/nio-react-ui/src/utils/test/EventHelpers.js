function createClientXY(x, y) {
    return {
        pageX: x,
        pageY: y,
        clientX: x,
        clientY: y,
    };
}

export function createStartTouchEventObject({ x = 0, y = 0 }, fingers = 1) {
    const touches = [];
    for (let i = 0; i < fingers; i++) {
        touches.push(createClientXY(x, y));
    }
    return { changedTouches: touches, touches };
}

export function createMoveTouchEventObject({ x = 0, y = 0 }, fingers = 1) {
    const touches = [];
    for (let i = 0; i < fingers; i++) {
        touches.push(createClientXY(x, y));
    }
    return { preventDefault() {}, changedTouches: touches, touches };
}

export function createEndTouchEventObject({ x = 0, y = 0 }, fingers = 1) {
    const touches = [];
    for (let i = 0; i < fingers; i++) {
        touches.push(createClientXY(x, y));
    }
    return { changedTouches: touches, touches };
}
