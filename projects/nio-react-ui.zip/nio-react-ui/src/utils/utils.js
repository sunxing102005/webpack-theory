import ReactDOMServer from 'react-dom/server';
/**
 * 消除对象里属性为空的属性值
 * @param {object} obj
 */
export function delEmptyKey(obj) {
    const result = { ...obj };
    if (result && typeof result === 'object') {
        for (const [key, value] of Object.entries(result)) {
            if (!value) delete result[key];
        }
        return result;
    }
    return false;
}
/**
 * 将对象转化为为数组
 * 数组元素key为对象键，value为属性值转化的字符串
 * @param {*} obj
 */
export function writeObj(obj) {
    const description = [];
    for (const [key, val] of Object.entries(obj)) {
        let value = val;
        if (val.$$typeof && val.$$typeof.toString() === 'Symbol(react.element)') {
            value = ReactDOMServer.renderToStaticMarkup(val);
        }

        description.push({ key, val: value });
    }
    return description;
}
/**
 * 左侧补全操作
 * 用于给个位时分秒补零
 * @param {*} num 用于补零的数字
 * @param {*} len 返回数字位数
*/
export function leftPadZero(num, len = 2) {
    let str = String(num);
    let length = len;
    const ch = '0';
    let i = -1;
    length -= str.length;
    while (++i < length) {
        str = ch + str;
    }
    return str;
}

/**
 * 加载本地代码
 * @param {string} src script 地址
*/
export function loadScript(src) {
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        script.onerror = reject;
        script.onload = () => {
            resolve();
        };
        document.head.appendChild(script);
    });
}
