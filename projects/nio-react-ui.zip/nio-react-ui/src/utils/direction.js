// 方向判断

/**
 * 触摸点和离开点连线与[x轴角度][3]
 * @param angx
 * @param angy
 * @return {number}
 */
const getAngle = (angx, angy) => Math.atan2(angy, angx) * 180 / Math.PI;

/**
 * 根据接触和离开判断方向 1向上 2向下 3向左 4向右 0未发生滑动（[Math.abs][4]）
 * @param startx{number}
 * @param starty
 * @param endx
 * @param endy
 * @return {number}
 */
const getDirection = (startx, starty, endx, endy) => {
    const angx = endx - startx;
    const angy = endy - starty;
    let result = 0;

    // 如果滑动距离太短
    if (Math.abs(angx) < 2 && Math.abs(angy) < 2) {
        return result;
    }
    const angle = getAngle(angx, angy);
    if (angle >= -135 && angle <= -45) {
        result = 1;
    } else if (angle > 45 && angle < 135) {
        result = 2;
    } else if ((angle >= 135 && angle <= 180) || (angle >= -180 && angle < -135)) {
        result = 3;
    } else if (angle >= -45 && angle <= 45) {
        result = 4;
    }

    return result;
};

export {
    getAngle,
    getDirection,
};
