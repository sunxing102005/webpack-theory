// 相差多少时，重新设置
import { leftPadZero } from './utils';

const MILLS_OFFSET = 15;
/**
 * 倒计时工具类，计算距离截止日期的时分秒
 */
export default class CountDownUtil {
    constructor(targetDate, cbFunc, endCallback) {
        this.targetDate = targetDate; // 计时截止时间
        this.cbFunc = cbFunc; // 每次计算时间后的回调函数
        this.endCallback = endCallback; // 倒计时结束回调
        this.timObj = {
            sec: '00',
            mini: '00',
            hour: '00',
        }; // 倒计时时间对象
        this.first = true;
        this.timer = null; // settimeout返回值
        this.stopFlag = false;
    }

    /**
     * 计算倒计时时间
     * @param {Date} deadline 倒计时截止日期时间(date类型)
     */
    calculate(deadline) {
        const terminal = deadline;
        const now = new Date();
        // 算出倒计时截止日与当前时间的时间差（秒）
        const dur = Math.round((terminal.getTime() - now.getTime()) / 1000);
        if (dur >= 0) {
            // 没到截止时间，计算相差时分秒
            this.timObj.sec = leftPadZero(dur % 60);
            this.timObj.mini = leftPadZero(Math.floor(dur / 60) % 60);
            this.timObj.hour = leftPadZero(Math.floor(dur / 3600));
        } else {
            this.stop();
            this.endCallback && this.endCallback();
        }
        return this.timObj;
    }

    /**
     * 停止计时,清除setTimeout
     */
    stop() {
        this.stopFlag = true;
        this.timer && window.clearTimeout(this.timer);
    }

    /**
     * 开始倒计时方法
     * 倒计时未结束时，循环调用，设置当前剩余时间
     */
    start() {
        const mills = new Date().getMilliseconds();
        const time = this.calculate(this.targetDate);
        this.cbFunc && this.cbFunc(time);
        if (!this.stopFlag) {
            this.timer = setTimeout(
                this.start.bind(this),
                this.first || mills > MILLS_OFFSET ? 1000 - mills : 1000,
            );
        } // 当第一次执行时，等到下一个整数秒再倒计时。
        // 之后执行，如果当前毫秒数（误差）大于15，就等到下一个整秒数继续下一次计时，而不是等1秒
        this.first = false; // 执行一次后，就不是第一次执行了
    }
}
