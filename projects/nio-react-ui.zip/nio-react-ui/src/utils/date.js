const getDateDetail = date => ({
    year: date.getFullYear(),
    month: date.getMonth() + 1,
    date: date.getDate(),
    day: date.getDay(),
    hour: date.getHours(),
    minute: date.getMinutes(),
    second: date.getSeconds(),
});

const getDateNumberOfMonth = (year, month) => new Date(year, month, 0).getDate();


/**
 * @method isSameDay
 * @param{Number|Date}p1 待比较的第一个参数，timestamp或者 Date Object
 * @param{Number|Date}p2 待比较的第二个参数，timestamp或者 Date Object
 * @return{Boolean} 是否为同一天
 */
const isSameDay = (p1, p2) => {
    const isDateObjSameDay = (date1, date2) => date1.getFullYear() === date2.getFullYear()
        && date1.getMonth() === date2.getMonth()
        && date1.getDate() === date2.getDate();

    let param1 = p1;
    let param2 = p2;
    if (typeof p1 === 'number') {
        param1 = new Date(p1);
    }

    if (typeof p2 === 'number') {
        param2 = new Date(p2);
    }
    return isDateObjSameDay(param1, param2);
};

/**
 * @method getDateWithTimeZone
 * @param{Number}timestamp 待转换的时间戳，单位为毫秒
 * @param{Number}targetTimeZone 目标时区，正数代表东，负数代表西
 * @return{Date} 目标时区的Date
 */
const getDateWithTimeZone = (timestamp = new Date().getTime(), targetTimeZone = 8) => {
    const offsetGMT = new Date().getTimezoneOffset();
    return new Date(timestamp + offsetGMT * 60 * 1000 + targetTimeZone * 60 * 60 * 1000);
};
function getDateAdd(interval, number, date) {
    switch (interval.trim()) {
    case 'y': {
        date.setFullYear(date.getFullYear() + number);
        return date;
    }
    case 'q': {
        date.setMonth(date.getMonth() + number * 3);
        return date;
    }
    case 'm': {
        date.setMonth(date.getMonth() + number);
        return date;
    }
    case 'w': {
        date.setDate(date.getDate() + number * 7);
        return date;
    }
    case 'd': {
        date.setDate(date.getDate() + number);
        return date;
    }
    case 'h': {
        date.setHours(date.getHours() + number);
        return date;
    }
    case 'min': {
        date.setMinutes(date.getMinutes() + number);
        return date;
    }
    case 's': {
        date.setSeconds(date.getSeconds() + number);
        return date;
    }
    default: {
        date.setDate(new Date().getDate() + number);
        return date;
    }
    }
}

const getDate = (now, AddDayCount) => {
    const date = new Date();
    date.setDate(now.getDate() + AddDayCount); // 获取AddDayCount天后的日期
    const y = date.getFullYear();
    const m = date.getMonth() + 1;
    const d = date.getDate();
    return {
        y,
        m,
        d,
    };
};

const dayArray = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
const getWeek = (now, date) => {
    const day = date.getDate();
    const {
        d: tomorrow,
    } = getDate(now, 1);
    const {
        d: afterTomorrow,
    } = getDate(now, 2);
    if (day === tomorrow) {
        return '明天';
    }
    if (day === afterTomorrow) {
        return '后天';
    }
    return dayArray[date.getDay()];
};

export {
    getDateDetail,
    getDateNumberOfMonth,
    isSameDay,
    getDateWithTimeZone,
    getDateAdd,
    getWeek,
    getDate,
};
