export const formatDate = (date, format) => {
    if (date === 'Invalid Date' || !date) {
        return '';
    }
    const mapping = {
        'M+': date.getMonth() + 1, // 月份
        'd+': date.getDate(), // 日
        'h+': date.getHours(), // 小时
        'm+': date.getMinutes(), // 分
        's+': date.getSeconds(), // 秒
        'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
        S: date.getMilliseconds(), // 毫秒
    };

    if (/(y+)/.test(format)) {
        /* eslint-disable */
        format = format.replace(RegExp.$1, `${date.getFullYear()}`.substr(4 - RegExp.$1.length));
    }

    for (const key in mapping) {
        if (new RegExp(`(${key})`).test(format)) {
            /* eslint-disable */
            format = format.replace(RegExp.$1, (RegExp.$1.length === 1) ? (mapping[key]) : (`00${mapping[key]}`.substr(`${mapping[key]}`.length)));
        }
    }

    return format;
};

export const formatDate2 = (date) => {
    const second = 1000;
    const minute = 60 * second;
    const hour = 60 * minute;
    const day = 24 * hour;

    if (new Date(date * second) === 'Invalid Date') {
        return '';
    }
    // 底部时间戳
    let preItemTime = new Date().getTime() - date * second;
    if (preItemTime <= minute) {
        preItemTime = '刚刚';
    } else if (preItemTime > minute && preItemTime <= hour) {
        preItemTime = `${parseInt(preItemTime / minute, 10)}分钟前`;
    } else if (preItemTime > hour && preItemTime <= day && new Date(date * second).getDate() === new Date().getDate()) {
        // 未超过24小时，且未隔夜显示小时
        preItemTime = `${parseInt(preItemTime / hour, 10)}小时前`;
    } else if (new Date(date * second).getFullYear() === new Date().getFullYear()) {
        // 一年内
        preItemTime = formatDate(new Date(second * date), 'MM-dd');
    } else {
        // 年限不同
        preItemTime = formatDate(new Date(second * date), 'yyyy-MM-dd');
    }
    return preItemTime;
};
