# nio-react-ui
## usage
1. add `"@uad/nio-react-ui": "http://npm.nevint.com/repository/npm-host/@uad/nio-react-ui/-/nio-react-ui-${ver}
.tgz"` into dependencies in package.json, where ${ver} is the [version](https://git.nevint.com/uad/nio-react-ui/blob/master/package.json#L3) of nio-react-ui.
2. `npm install`
3.
 ```javascript
import {Button} from '@uad/nio-react-ui';
<Button>hello world</Button>  
```

### use in modularization:
a. if `Webpack4+` is available, built-in tree shaking will do it well(NIO React UI already had "sideEffects" configuration)

b. if not, `babel-plugin-import` is required, and in `babel.config.js`:
```javascript
// in plugins
[
    'import',
    {
        libraryName: '@uad/nio-react-ui',
        libraryDirectory: 'es/component',
        camel2DashComponentName: false,
        style(path) {
            return path + '/index.css';
        },
    }
]
```

## dev environment
### requirement
node: 8.9 +

```
// develop component
cd pj_name
npm install // install dependencies
npm run storybook

```
## code style
we use eslint with [Airbnb JavaScript Style Guide](https://github.com/airbnb/javascript) to review code style.

run `npm run eslint` to check the code style.

## test
view [docs](https://git.nevint.com/uad/nio-react-ui/tree/master/jest)

## build & publish
build es&lib: `npm run compile`
build dist: `npm run build`

## storybook
view [docs](https://git.nevint.com/uad/nio-react-ui/tree/master/storybook) for storybook in nio-react-ui
