import React, { lazy, Suspense } from 'react';
import ErrorBoundary from './ErrorBoundary';
import props from './props';
import { writeObj } from '~utils/utils';
import './com-style.scss';

let Com = null;
const original = window.COM_NAME && window.COM_NAME.original;
if (Array.isArray(original) && original.length === 3) {
    const comName = original[2].slice(2);
    Com = lazy(() => import(`../src/component/${comName}/index`));
}
function DebugComponent() {
    return (
        <div className="debug-container">
            <div className="com-wrapper">
                <ErrorBoundary>
                    <Suspense fallback={<div>Loading...</div>}>
                        <Com {...props} />
                    </Suspense>
                </ErrorBoundary>
            </div>
            <div className="props-wrapper">
                <h2>props</h2>
                {writeObj(props).map(item => (
                    <div key={item.key}>
                        <h3>{`${item.key}: `}</h3>
                        <p>{`${item.val}`}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}
export default DebugComponent;
