import React from 'react';
import propTypes from 'prop-types';

class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError() {
    // 更新 state 使下一次渲染能够显示降级后的 UI
        return { hasError: true };
    }

    componentDidCatch(error) {
        console.log(error);
    }

    render() {
        const { hasError } = this.state;
        if (hasError) {
            return <h1>找不到组件或组件加载错误!</h1>;
        }

        return this.props.children;
    }
}
ErrorBoundary.propTypes = {
    children: propTypes.node,
};
ErrorBoundary.defaultProps = {
    children: null,
};
export default ErrorBoundary;
