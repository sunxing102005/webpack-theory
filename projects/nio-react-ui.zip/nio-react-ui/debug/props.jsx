import React from 'react';

// const props = {
//     imgHeight: '200px',
//     imgWidth: '300px',
//     src: 'https://www.nio.com/themes/nioweb/images/XXX.png',
//     element: <p className="ele-style">ssx</p>,
//     className: 'com-container',
//     onImageError: () => {
//         console.log('error');
//     },
// };
// const props = {
//     itemClassName: 'img-item-test',
//     data: [
//         {
//             url:
//         'https://cdn-app.nio.com/user/2019/11/27/df1e3a64-a80a-44ca-8f98-afc57fca3a9f.png?imageView2/2/w/1024',
//             title: '2019 NIO Day用户顾问团名单公布',
//         },
//         {
//             url:
//         'https://cdn-app.nio.com/user/2019/11/27/9fcced16-bb7a-42c7-b50c-df38ad7c6b80.jpg?imageView2/2/w/1024',
//             title: '2019 NIO Day用户顾问团名单公布',
//         },
//         {
//             url:
//         'https://cdn-app.nio.com/user/2019/11/27/df1e3a64-a80a-44ca-8f98-afc57fca3a9f.png?imageView2/2/w/1024',
//             title: '2019 NIO Day用户顾问团名单公布',
//         },
//     ],
//     renderItem: item => <div>{item.title}</div>,
// };
// const itemStyle = { width: '100px', background: 'pink', height: '50px' };
// const props = {
//     children: (
//         <React.Fragment>
//             <div style={itemStyle} className="swiper-slide">
//         item1
//             </div>
//             <div style={itemStyle} className="swiper-slide">
//         item2
//             </div>
//             <div style={itemStyle} className="swiper-slide">
//         item3
//             </div>
//         </React.Fragment>
//     ),
//     requestEventAndroid: (e) => {
//         console.log('requestEventAndroid', e);
//     },
//     environment: 'android',
// };
function onSlideChangeStart() {
    console.log('onSlideChangeStart');
}
const itemStyle = { width: '50px', background: 'pink', height: '50px' };
const props = {
    onSlideChangeStart,
    children: <React.Fragment>
        <div style={itemStyle} className="swiper-slide">
    item1
        </div>
        <div style={itemStyle} className="swiper-slide">
    item2
        </div>
        <div style={itemStyle} className="swiper-slide">
    item3
        </div>

              </React.Fragment>,
    // src:
    // 'https://cdn-app.nio.com/user/2019/10/18/970f1295-0bb9-4b3a-a8c6-5db01f395b0f.jpg?imageView2/2/w/1024',
    // title: '早鸟票开始抢购了',
};
export default props;
