import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
    /* eslint-disable*/
    <h1>you can import your component here</h1>,
    document.getElementById('app'),
);
