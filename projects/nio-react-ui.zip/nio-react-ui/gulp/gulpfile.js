/* eslint-disable */
const gulp = require('gulp');
const path = require('path');
const babel = require('gulp-babel');
const rimraf = require('rimraf');
const through2 = require('through2');
const merge2 = require('merge2');
const sass = require('gulp-sass');
sass.compiler = require('node-sass');
const cleanCSS = require('gulp-clean-css');

const cwd = process.cwd();
const projectDir = path.join(cwd, '../');
const getPath = (...filePath) => path.join(projectDir, ...filePath);

function compile({ isESModule = true } = {}) {
    const esDir = getPath('es');
    const libDir = getPath('lib');
    const outputDir = isESModule ? esDir : libDir;

    console.log('output dir:', outputDir);
    // remove dir
    rimraf.sync(outputDir);

    // transform jsx into js
    const outputDirStr = isESModule ? '../es' : '../lib';
    const js = gulp.src([
        '../src/**/*.jsx',
        '../src/**/*.js',
    ])

    // eslint-disable-next-line
        .pipe(through2.obj(function (file, encoding, cb) {
            if (file.path.match(/(story|test)\.(jsx|js)$/)) {
                return cb();
            }
            return cb(null, file);
        }))
        .pipe(babel({
            presets: [
                [
                    '@babel/preset-env',
                    {
                        modules: isESModule ? false : 'commonjs',
                    },
                ],
                '@babel/preset-react',
            ],
            plugins: [
                ['module-resolver', {
                    root: ['es'],
                    alias: {},
                    resolvePath(sourcePath, currentFile, opts) {
                        if (sourcePath.includes('.scss')) {
                            return sourcePath.replace('.scss', '.css');
                        }

                        switch (sourcePath) {
                            case '~lib': {
                                return path.relative(currentFile.replace(/index\.(js|jsx)$/, ''), getPath('src/lib'));
                            }
                            case '~utils': {
                                return path.relative(currentFile.replace(/index\.(js|jsx)$/, ''), getPath('src/utils'));
                            }
                            default:
                                return null;
                        }
                    },
                    extensions: ['.js', '.jsx', '.mjs'],
                }],
                '@babel/plugin-proposal-class-properties'
            ],
        }))
        .pipe(gulp.dest(outputDirStr));

    const css = gulp.src([
        '../src/**/*.scss',
    ])

        .pipe(sass({
            importer(url, prev, done) {
                const map = {
                    '~@scss/theme/config': getPath('src/lib/style/theme/config.scss'),
                    '~@scss/src/icon': getPath('src/lib/style/src/icon.scss'),
                    '~@scss/src/normalize': getPath('src/lib/style/src/normalize.scss'),
                    '~@scss/src/mixin': getPath('src/lib/style/src/mixin.scss'),
                    '~@scss/src/variable': getPath('src/lib/style/src/variable.scss'),
                };
                const filePath = map[url];
                if (!filePath) {
                    done();
                    return;
                }
                done({
                    file: filePath,
                });
            },
        }).on('error', sass.logError))
        .pipe(gulp.dest(outputDirStr));

    const staticFiles = gulp.src([
        '../src/**/*.eot',
        '../src/**/*.svg',
        '../src/**/*.ttf',
        '../src/**/*.woff',
        '../src/**/*.woff2',
        '../src/**/*.png',
        '../src/**/*.jpg',
        '../src/**/*.jpeg',
    ]).pipe(gulp.dest(outputDir));

    return merge2([
        js,
        css,
        staticFiles,
    ]);
}

gulp.task('compile-es', (done) => {
    console.log('[Parallel] Compile to es...');
    compile({ isESModule: true })
        .on('finish', () => {
            console.log('Compile to es done');
            done();
        });
});

gulp.task('compile-lib', (done) => {
    console.log('[Parallel] Compile to lib...');
    compile({ isESModule: false })
        .on('finish', () => {
            console.log('Compile to lib done');
            done();
        });
});

gulp.task('min-css', done => {
    const dirs = [{
        input: '../es/**/*.css',
        output: '../es',
    }, {
        input: '../lib/**/*.css',
        output: '../lib',
    }];

    dirs.forEach(dir => {
        gulp.src(dir.input)
            .pipe(cleanCSS({ inline: ['none'] }))
            // .pipe(rename(function (path) {
            //     path.basename += '.min';
            // }))
            .pipe(gulp.dest(dir.output));
    });
    done();
});

gulp.task(
    'compile',
    gulp.series(gulp.parallel('compile-es', 'compile-lib'), 'min-css'),
);
