## storybook
every component should have its own story.

### view stories
```
npm run storybook // start at port 9001 as default, u can change it at script in package.json

```

### register stories
please register stories for component by following:

- add ```story.js``` into directory which component belongs to
- make stories:

    ```
	import React from 'react';
	import registerStory from 'path/to/storybook';
	import MyComponent from "path/to/Component";

	// register story
	const storyRegistration = registerStory(COMPONENT_NAME, OPTIONS);
	// then you can get these from storyRegistration
	const {knobs, state, stories} = storyRegistration;
	// see addon-knbos
    const {text, object, boolean, number} = knobs;
    // see addon-state
    const {State, Store} = state;
    // add stories
	stories.add(SCENE_NAME, () => <MyComponent/>);

    ```
- add state for component:

    ```
    // init store
    const store = new Store({
        propName: initialValue,
    });
    // use State component as a container
    <State store={store}>
        <Component/>
    </State>
    // get or set from store
    store.get('propName');
    store.set({propName: value});
    ```
- add knobs to control props

    ```
    // to get all available types : https://www.npmjs.com/package/@storybook/addon-knobs
    const value = text('value', '5');

    ```
- add notes, support normal text or markdown

	```
	stories.addParameters({
		info: {
			text: `
				## Notes
     	     - note1
    	      - note2
    	    `,
   	     	},
   		});

	```
- add prop table by

    set Component.propTypes and Component.defaultProps in Component.jsx,and use comment like this and it will generate prop form automatically:

    ```
    Component.propTypes = {
        /** description for this property */
        prop1: PropTypes.any,
    };

    Component.defaultProps = {
        prop1: '',
    };

    ```

- view console

	use console.log and message is available in ACTION-LOGGER panel

