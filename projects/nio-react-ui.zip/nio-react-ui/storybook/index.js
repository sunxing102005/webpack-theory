/* eslint-disable import/no-extraneous-dependencies */
import React from 'react';
import {
    storiesOf,
} from '@storybook/react';
import * as knobs from '@storybook/addon-knobs';
import * as state from '@sambego/storybook-state';

/**
 *
 * @param storyName{string} component name as usual
 * @param defaultAddons{boolean} should add addons into these stories by default
 * @return {{stories: *, knobs}}
 */
export default (storyName, {
    wrapperStyle = {}
} = {}) => {
    const stories = storiesOf(storyName, module);
    stories.addDecorator(story => <div style={ Object.assign({ height: 500, margin: 20 }, wrapperStyle) }>{story()}</div>)
    return {
        stories,
        knobs, // provide knobs function to registrant
        state,
    };
};