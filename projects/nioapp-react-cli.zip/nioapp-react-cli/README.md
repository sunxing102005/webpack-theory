nio app react 脚手架工程

$ npm install http://npm.nevint.com/repository/npm-host/@uad/nioapp-react-cli/-/nioapp-react-cli-1.0.0.tgz -g

$ nioapp-react create <projectName>